'use client';
import { ExternalLink, ImagePlus, Plus, Save, Store, Trash2 } from 'lucide-react';
import { useEffect, useState } from 'react';
import { Card, ErrorBox, Field, Loading, PageHeader, Spinner, useToast } from '@/components/ui';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { useApi } from '@/lib/hooks';

type Method = { name: string; instructions: string; enabled: boolean };
type Config = { headline: string; description: string; heroImage: string; heroLayout: string; layout: string; fontStyle: string; textAlign: string; cardStyle: string; buttonStyle: string; imageRatio: string; catalogTitle: string; productButtonText: string; announcement: string; showProductDescription: boolean; showSocialLinks: boolean; primaryColor: string; backgroundColor: string; accentColor: string; whatsapp: string; shippingInfo: string; shippingFee: string; freeShippingMinimum: string; paymentMethods: Method[] };
const methods: Method[] = [
  { name: 'Transferencia bancaria', instructions: '', enabled: true },
  { name: 'Nequi', instructions: '', enabled: false },
  { name: 'Daviplata', instructions: '', enabled: false },
  { name: 'Efectivo contra entrega', instructions: '', enabled: false },
  { name: 'Link de pago', instructions: 'Pega aquí el enlace de tu pasarela de pago.', enabled: false },
  { name: 'Tarjeta débito o crédito', instructions: 'Comparte un link seguro de tu pasarela de pago.', enabled: false },
  { name: 'PSE', instructions: 'Comparte un link seguro de tu pasarela de pago.', enabled: false },
];
const defaults: Config = { headline: 'Hecho para ti', description: 'Descubre nuestros productos y encuentra tu favorito.', heroImage: '', heroLayout: 'banner', layout: 'grid', fontStyle: 'modern', textAlign: 'left', cardStyle: 'soft', buttonStyle: 'pill', imageRatio: 'square', catalogTitle: 'Nuestros productos', productButtonText: 'Agregar', announcement: '', showProductDescription: true, showSocialLinks: true, primaryColor: '#171717', backgroundColor: '#FAF8F4', accentColor: '#B69C72', whatsapp: '', shippingInfo: '', shippingFee: '0', freeShippingMinimum: '', paymentMethods: methods };
const toSlug = (s: string) => s.toLocaleLowerCase('es').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 80);

export default function StoreAdminPage() {
  const { current } = useAuth();
  const toast = useToast();
  const { data, loading, error, reload } = useApi<any>('/store/current');
  const [slug, setSlug] = useState('');
  const [enabled, setEnabled] = useState(false);
  const [config, setConfig] = useState<Config>(defaults);
  const [busy, setBusy] = useState(false);
  const [saveError, setSaveError] = useState('');
  const [uploading, setUploading] = useState(false);
  const [wompi, setWompi] = useState({ publicKey: '', privateKey: '', integritySecret: '', eventSecret: '' });
  const [savingWompi, setSavingWompi] = useState(false);
  useEffect(() => {
    if (!data) return;
    setSlug(data.slug || toSlug(current?.tradeName ?? 'mi-tienda'));
    setEnabled(data.enabled);
    setConfig({ ...defaults, ...data.config, paymentMethods: data.config?.paymentMethods?.length ? data.config.paymentMethods : methods });
  }, [data, current?.tradeName]);
  const update = (k: keyof Config, v: string) => setConfig((c) => ({ ...c, [k]: v }));
  const save = async () => {
    setBusy(true); setSaveError('');
    try { await api('/store/current', { method: 'PATCH', body: { slug, enabled, ...config } }); await reload(); toast('Tienda guardada'); }
    catch (e) { setSaveError((e as Error).message); }
    finally { setBusy(false); }
  };
  const uploadCover = async (file?: File) => {
    if (!file) return;
    setUploading(true); setSaveError('');
    try { const form = new FormData(); form.append('file', file); const result = await api<{ url: string }>('/uploads/image', { form }); update('heroImage', result.url); }
    catch (e) { setSaveError((e as Error).message); }
    finally { setUploading(false); }
  };
  const connectWompi = async () => {
    setSavingWompi(true); setSaveError('');
    try { await api('/store/current/wompi', { method: 'PATCH', body: wompi }); setWompi({ publicKey: '', privateKey: '', integritySecret: '', eventSecret: '' }); await reload(); toast('Pasarela Wompi conectada'); }
    catch (e) { setSaveError((e as Error).message); }
    finally { setSavingWompi(false); }
  };
  if (loading && !data) return <Loading />;
  return <>
    <PageHeader title="Mi tienda web" subtitle="Crea una página pública para mostrar tus productos y recibir pedidos."
      actions={<div className="flex gap-2">{enabled && slug && <a className="btn-secondary" href={`/tienda/${slug}`} target="_blank" rel="noreferrer"><ExternalLink className="h-4 w-4" /> Ver tienda</a>}<button className="btn-primary" onClick={save} disabled={busy || !slug}><Save className="h-4 w-4" />{busy && <Spinner />} Guardar cambios</button></div>} />
    {(error || saveError) && <div className="mb-4"><ErrorBox message={saveError || error || 'No se pudo cargar la configuración'} onRetry={reload} /></div>}
    <div className="grid xl:grid-cols-[minmax(0,1fr)_360px] gap-5 items-start">
      <div className="space-y-5">
        <Card title={<span className="flex items-center gap-2"><Store className="h-4 w-4" /> Publicación y enlace</span>}>
          <div className="grid sm:grid-cols-2 gap-4">
            <Field label="Dirección de tu tienda" hint="Usa minúsculas, números y guiones."><div className="flex items-center gap-2"><span className="text-xs text-ink-muted">/tienda/</span><input className="input" value={slug} onChange={(e) => setSlug(toSlug(e.target.value))} placeholder="mi-marca" /></div></Field>
            <label className="flex items-center gap-3 rounded-xl border border-line p-3 self-end"><input type="checkbox" className="accent-ink h-4 w-4" checked={enabled} onChange={(e) => setEnabled(e.target.checked)} /><span><span className="block text-sm font-medium">Publicar tienda</span><span className="text-xs text-ink-muted">Visible para cualquier persona con el enlace</span></span></label>
          </div>
        </Card>
        <Card title="Apariencia y contenido">
          <div className="grid sm:grid-cols-2 gap-4">
            <Field label="Título principal"><input className="input" value={config.headline} onChange={(e) => update('headline', e.target.value)} maxLength={100} /></Field>
            <Field label="Foto de portada"><input className="input" type="url" value={config.heroImage} onChange={(e) => update('heroImage', e.target.value)} placeholder="Pega un enlace de imagen…" /><label className="mt-2 inline-flex btn-secondary btn-sm cursor-pointer">{uploading ? <Spinner /> : <ImagePlus className="h-4 w-4" />} Subir imagen<input type="file" className="sr-only" accept="image/png,image/jpeg,image/webp" onChange={(e) => uploadCover(e.target.files?.[0])} /></label></Field>
            <Field label="Descripción" className="sm:col-span-2"><textarea className="input min-h-24" value={config.description} onChange={(e) => update('description', e.target.value)} maxLength={1000} /></Field>
            <Field label="Estilo de portada"><select className="input" value={config.heroLayout} onChange={(e) => update('heroLayout', e.target.value)}><option value="banner">Banner con imagen</option><option value="split">Imagen y texto lado a lado</option><option value="overlay">Texto sobre la imagen</option><option value="simple">Solo texto</option></select></Field>
            <Field label="Diseño del catálogo"><select className="input" value={config.layout} onChange={(e) => update('layout', e.target.value)}><option value="grid">Cuadrícula</option><option value="editorial">Editorial</option><option value="minimal">Minimalista</option></select></Field>
            <Field label="Tipografía"><select className="input" value={config.fontStyle} onChange={(e) => update('fontStyle', e.target.value)}><option value="modern">Moderna</option><option value="serif">Elegante</option><option value="rounded">Amigable</option></select></Field>
            <Field label="Alineación del texto"><select className="input" value={config.textAlign} onChange={(e) => update('textAlign', e.target.value)}><option value="left">Izquierda</option><option value="center">Centrada</option></select></Field>
            <Field label="Forma de las tarjetas"><select className="input" value={config.cardStyle} onChange={(e) => update('cardStyle', e.target.value)}><option value="soft">Suave y redondeada</option><option value="classic">Clásica</option><option value="outline">Borde marcado</option></select></Field>
            <Field label="Forma de los botones"><select className="input" value={config.buttonStyle} onChange={(e) => update('buttonStyle', e.target.value)}><option value="pill">Pastilla</option><option value="round">Redondeado</option><option value="square">Cuadrado</option></select></Field>
            <Field label="Formato de las fotos"><select className="input" value={config.imageRatio} onChange={(e) => update('imageRatio', e.target.value)}><option value="square">Cuadrado</option><option value="portrait">Vertical</option><option value="wide">Panorámico</option></select></Field>
            <Field label="Título del catálogo"><input className="input" value={config.catalogTitle} onChange={(e) => update('catalogTitle', e.target.value)} maxLength={80} /></Field>
            <Field label="Texto del botón de producto"><input className="input" value={config.productButtonText} onChange={(e) => update('productButtonText', e.target.value)} maxLength={32} /></Field>
            <Field label="Aviso superior" hint="Ej. Envío gratis en compras mayores a $100.000"><input className="input" value={config.announcement} onChange={(e) => update('announcement', e.target.value)} maxLength={100} /></Field>
            <Field label="Información de envíos"><input className="input" value={config.shippingInfo} onChange={(e) => update('shippingInfo', e.target.value)} placeholder="Envíos nacionales en 2 a 5 días…" maxLength={500} /></Field>
            <Field label="Costo base del envío (COP)" hint="Se suma al total y se cobra al confirmar. Usa 0 solo si el negocio asume el costo del envío."><input className="input" inputMode="decimal" value={config.shippingFee} onChange={(e) => update('shippingFee', e.target.value.replace(/[^0-9.]/g, ''))} placeholder="0" /></Field>
            <Field label="Envío gratis desde (COP)" hint="Opcional. Déjalo vacío si no ofreces envío gratis por monto."><input className="input" inputMode="decimal" value={config.freeShippingMinimum} onChange={(e) => update('freeShippingMinimum', e.target.value.replace(/[^0-9.]/g, ''))} placeholder="Sin mínimo" /></Field>
          </div>
          <div className="flex flex-wrap gap-5 mt-4 text-sm"><label className="flex items-center gap-2"><input type="checkbox" className="accent-ink" checked={config.showProductDescription} onChange={(e) => setConfig((c) => ({ ...c, showProductDescription: e.target.checked }))} /> Mostrar descripciones</label><label className="flex items-center gap-2"><input type="checkbox" className="accent-ink" checked={config.showSocialLinks} onChange={(e) => setConfig((c) => ({ ...c, showSocialLinks: e.target.checked }))} /> Mostrar redes del negocio</label></div>
          <div className="grid sm:grid-cols-3 gap-4 mt-4">
            {([['primaryColor', 'Color principal'], ['backgroundColor', 'Fondo'], ['accentColor', 'Color de acento']] as const).map(([key, label]) => <Field key={key} label={label}><div className="flex gap-2"><input type="color" className="h-10 w-12 rounded-lg border border-line p-1" value={config[key]} onChange={(e) => update(key, e.target.value)} /><input className="input font-mono uppercase" value={config[key]} onChange={(e) => update(key, e.target.value)} /></div></Field>)}
          </div>
          <Field label="Portada" className="mt-4"><div className="h-28 rounded-xl border border-dashed border-line flex items-center justify-center overflow-hidden text-xs text-ink-muted">{config.heroImage ? <img src={config.heroImage} alt="Vista previa de portada" className="h-full w-full object-cover" /> : <><ImagePlus className="h-4 w-4 mr-2" /> Agrega una URL de imagen para mostrar aquí</>}</div></Field>
        </Card>
        <Card title="Pedidos y medios de pago">
          <p className="text-xs text-ink-muted mb-4">Transferencia, Nequi y Daviplata funcionan con instrucciones. Para cobrar tarjeta o PSE, conecta la cuenta Wompi de este negocio. Las llaves privadas se guardan cifradas.</p>
          <div className="rounded-xl border border-line bg-sand-50 p-4 mb-4">
            <div className="flex items-center justify-between gap-3"><div><p className="text-sm font-medium">Wompi {data?.paymentGatewayEnabled ? 'conectado' : 'sin configurar'}</p><p className="text-xs text-ink-muted mt-1">Pega las llaves de este comercio desde Wompi. Usa llaves de prueba para ensayar.</p></div><span className={`h-2.5 w-2.5 rounded-full ${data?.paymentGatewayEnabled ? 'bg-emerald-500' : 'bg-ink-faint'}`} /></div>
            <div className="grid sm:grid-cols-2 gap-3 mt-4">
              <Field label="Llave pública"><input className="input" autoComplete="off" value={wompi.publicKey} onChange={(e) => setWompi({ ...wompi, publicKey: e.target.value })} placeholder="pub_test_…" /></Field>
              <Field label="Llave privada"><input className="input" type="password" autoComplete="new-password" value={wompi.privateKey} onChange={(e) => setWompi({ ...wompi, privateKey: e.target.value })} /></Field>
              <Field label="Secreto de integridad"><input className="input" type="password" autoComplete="new-password" value={wompi.integritySecret} onChange={(e) => setWompi({ ...wompi, integritySecret: e.target.value })} /></Field>
              <Field label="Secreto de eventos"><input className="input" type="password" autoComplete="new-password" value={wompi.eventSecret} onChange={(e) => setWompi({ ...wompi, eventSecret: e.target.value })} /></Field>
            </div>
            <button type="button" className="btn-secondary mt-3" disabled={savingWompi || Object.values(wompi).some((v) => !v.trim())} onClick={connectWompi}>{savingWompi ? <Spinner /> : <Save className="h-4 w-4" />} Conectar Wompi</button>
            {data?.paymentGatewayEnabled && <p className="text-[11px] text-emerald-700 mt-2">La cuenta ya está activa. Para cambiar las llaves, vuelve a ingresar las cuatro.</p>}
          </div>
          <div className="grid sm:grid-cols-2 gap-4">
            <Field label="WhatsApp del negocio" hint="Incluye el indicativo del país, por ejemplo 573001234567."><input className="input" inputMode="tel" value={config.whatsapp} onChange={(e) => update('whatsapp', e.target.value.replace(/[^\d+]/g, ''))} placeholder="573001234567" /></Field>
          </div>
          <div className="space-y-3 mt-4">{config.paymentMethods.map((m, i) => <div key={`${m.name}-${i}`} className="grid sm:grid-cols-[24px_200px_1fr_32px] gap-2 items-center rounded-xl border border-line p-3">
            <input type="checkbox" className="accent-ink h-4 w-4" checked={m.enabled} aria-label={`Activar ${m.name}`} onChange={(e) => setConfig((c) => ({ ...c, paymentMethods: c.paymentMethods.map((x, j) => j === i ? { ...x, enabled: e.target.checked } : x) }))} />
            <input className="input" value={m.name} onChange={(e) => setConfig((c) => ({ ...c, paymentMethods: c.paymentMethods.map((x, j) => j === i ? { ...x, name: e.target.value } : x) }))} aria-label="Nombre del medio de pago" />
            <input className="input" value={m.instructions} onChange={(e) => setConfig((c) => ({ ...c, paymentMethods: c.paymentMethods.map((x, j) => j === i ? { ...x, instructions: e.target.value } : x) }))} placeholder="Cuenta, número o instrucciones para pagar" aria-label={`Instrucciones de ${m.name}`} />
            <button type="button" className="btn-ghost !px-2 text-bad" onClick={() => setConfig((c) => ({ ...c, paymentMethods: c.paymentMethods.filter((_, j) => j !== i) }))} aria-label={`Quitar ${m.name}`}><Trash2 className="h-4 w-4" /></button>
          </div>)}</div>
          {config.paymentMethods.length < 8 && <button type="button" className="btn-secondary btn-sm mt-3" onClick={() => setConfig((c) => ({ ...c, paymentMethods: [...c.paymentMethods, { name: 'Otro medio de pago', instructions: '', enabled: false }] }))}><Plus className="h-4 w-4" /> Agregar medio de pago</button>}
        </Card>
      </div>
      <Card title="Vista previa" className="xl:sticky xl:top-20 overflow-hidden !p-0">
        <div style={{ background: config.backgroundColor, color: config.primaryColor, fontFamily: config.fontStyle === 'serif' ? 'Georgia, serif' : config.fontStyle === 'rounded' ? 'Trebuchet MS, sans-serif' : 'Inter, sans-serif' }}>
          {config.announcement && <div className="px-4 py-2 text-center text-xs" style={{ background: config.accentColor, color: '#fff' }}>{config.announcement}</div>}
          {config.heroImage && config.heroLayout !== 'simple' && <img src={config.heroImage} alt="" className="h-36 w-full object-cover" />}
          <div className={`p-5 ${config.textAlign === 'center' ? 'text-center' : ''}`}><p className="text-xs uppercase tracking-widest opacity-60">{current?.tradeName}</p><h2 className="text-2xl font-semibold mt-2">{config.headline}</h2><p className="text-sm mt-2 opacity-75">{config.description}</p><div className="h-24 mt-4 flex items-end p-3" style={{ background: config.accentColor, color: '#fff', borderRadius: config.cardStyle === 'classic' ? 8 : config.cardStyle === 'outline' ? 0 : 20 }}><span className="text-xs font-medium">{config.catalogTitle}</span></div><button className="mt-3 px-4 py-2 text-xs text-white" style={{ background: config.primaryColor, borderRadius: config.buttonStyle === 'square' ? 0 : config.buttonStyle === 'round' ? 10 : 99 }}>{config.productButtonText}</button></div>
        </div>
      </Card>
    </div>
  </>;
}
