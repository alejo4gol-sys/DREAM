'use client';
import { Check, ExternalLink, PackageCheck, Truck, X } from 'lucide-react';
import { useState } from 'react';
import { Badge, Card, Empty, ErrorBox, Loading, PageHeader, useToast } from '@/components/ui';
import { api } from '@/lib/api';
import { money, date } from '@/lib/format';
import { useApi } from '@/lib/hooks';

const LABEL: Record<string, string> = { RECEIVED: 'Recibido', CONFIRMED: 'Confirmado', SHIPPED: 'Enviado', DELIVERED: 'Entregado', CANCELLED: 'Cancelado' };
const TONE: Record<string, 'warn' | 'ok' | 'muted' | 'bad' | 'ink'> = { RECEIVED: 'warn', CONFIRMED: 'ink', SHIPPED: 'muted', DELIVERED: 'ok', CANCELLED: 'bad' };
const NEXT: Record<string, { status: string; label: string; icon: typeof Check }[]> = {
  RECEIVED: [{ status: 'CONFIRMED', label: 'Confirmar y reservar stock', icon: Check }, { status: 'CANCELLED', label: 'Cancelar pedido', icon: X }],
  CONFIRMED: [{ status: 'SHIPPED', label: 'Marcar como enviado', icon: Truck }, { status: 'CANCELLED', label: 'Cancelar y liberar stock', icon: X }],
  SHIPPED: [{ status: 'DELIVERED', label: 'Marcar como entregado', icon: PackageCheck }],
};
const CARRIERS = [
  { id: 'COORDINADORA', name: 'Coordinadora', url: 'https://coordinadora.com/envios/solicitar-recogida/' },
  { id: 'SERVIENTREGA', name: 'Servientrega', url: 'https://www.servientrega.com/' },
  { id: 'INTER_RAPIDISIMO', name: 'Inter Rapidísimo', url: 'https://www3.interrapidisimo.com/enviosenlinea/' },
  { id: 'ENVIA', name: 'envía', url: 'https://envia.co/' },
  { id: 'TCC', name: 'TCC', url: 'https://tcc.com.co/' },
  { id: 'OTRA', name: 'Otra transportadora', url: '' },
];
const WINDOW_OPTIONS = ['8:00 a. m. – 12:00 m.', '12:00 m. – 5:00 p. m.', '8:00 a. m. – 5:00 p. m.'];

export default function StoreOrdersPage() {
  const toast = useToast();
  const [drafts, setDrafts] = useState<Record<string, any>>({});
  const [savingShipping, setSavingShipping] = useState<string | null>(null);
  const { data, loading, error, reload } = useApi<any[]>('/store/orders');
  const change = async (id: string, status: string, label: string) => {
    try { await api(`/store/orders/${id}/status`, { method: 'PATCH', body: { status } }); await reload(); toast(status === 'CONFIRMED' ? 'Pedido confirmado e inventario reservado' : `Pedido ${label.toLowerCase()}`); }
    catch (e) { toast((e as Error).message, 'bad'); }
  };
  const shippingValue = (order: any, key: string) => drafts[order.id]?.[key] ?? (key === 'carrier' ? order.shippingCarrier : key === 'pickupDate' ? order.pickupDate : key === 'pickupWindow' ? order.pickupWindow : key === 'pickupConfirmation' ? order.pickupConfirmation : key === 'trackingNumber' ? order.trackingNumber : key === 'trackingUrl' ? order.trackingUrl : '');
  const updateDraft = (order: any, key: string, value: string) => setDrafts((current) => ({ ...current, [order.id]: { ...(current[order.id] ?? {}), [key]: value } }));
  const saveShipping = async (order: any) => {
    const draft = drafts[order.id] ?? {};
    const body = { carrier: draft.carrier ?? order.shippingCarrier, pickupDate: draft.pickupDate ?? order.pickupDate,
      pickupWindow: draft.pickupWindow ?? order.pickupWindow, pickupConfirmation: draft.pickupConfirmation ?? order.pickupConfirmation ?? '',
      trackingNumber: draft.trackingNumber ?? order.trackingNumber ?? '', trackingUrl: draft.trackingUrl ?? order.trackingUrl ?? '' };
    if (!body.carrier || !body.pickupDate || !body.pickupWindow) { toast('Elige transportadora, fecha y horario de recogida', 'bad'); return; }
    setSavingShipping(order.id);
    try { await api(`/store/orders/${order.id}/shipping`, { method: 'PATCH', body }); await reload(); toast('Datos de envío guardados'); }
    catch (e) { toast((e as Error).message, 'bad'); }
    finally { setSavingShipping(null); }
  };
  return <>
    <PageHeader title="Pedidos y envíos" subtitle="Confirma compras, agenda recogidas con transportadoras y guarda las guías de envío." />
    <Card className="mb-4 border-primary/20 bg-sand-50">
      <div className="flex items-start gap-3"><Truck className="h-5 w-5 text-primary mt-0.5" /><div><p className="text-sm font-semibold">¿Dónde se agenda una recogida?</p><p className="text-xs text-ink-muted mt-1">Confirma primero el pedido. En su tarjeta aparecerá la sección «Envío y recogida»: elige una transportadora, abre su portal para solicitar la recogida y guarda aquí la fecha, confirmación y guía.</p><p className="text-xs text-ink-muted mt-2">Transportadoras disponibles: Coordinadora, Servientrega, Inter Rapidísimo, envía y TCC.</p></div></div>
    </Card>
    {error && <div className="mb-4"><ErrorBox message={error} onRetry={reload} /></div>}
    {loading && !data ? <Loading /> : data?.length === 0 ? <Card><Empty title="Aún no hay pedidos web" description="Cuando un cliente complete una compra desde tu tienda, aparecerá aquí." /></Card> : <div className="space-y-4">
      {data?.map((order) => <Card key={order.id} className="overflow-hidden">
        <div className="flex flex-col lg:flex-row lg:items-start gap-5 justify-between">
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2 flex-wrap"><h2 className="font-semibold">Pedido #{order.id.slice(0, 8)}</h2><Badge tone={TONE[order.status] ?? 'muted'}>{LABEL[order.status] ?? order.status}</Badge>{order.paymentProvider && <Badge tone={order.paymentStatus === 'PAID' ? 'ok' : order.paymentStatus === 'FAILED' ? 'bad' : 'warn'}>{order.paymentStatus === 'PAID' ? 'Pago confirmado' : order.paymentStatus === 'FAILED' ? 'Pago rechazado' : 'Pago pendiente'}</Badge>}<span className="text-xs text-ink-faint">{date(order.createdAt, true)}</span></div>
            <div className="grid sm:grid-cols-2 gap-x-6 gap-y-1 mt-3 text-sm"><p><span className="text-ink-muted">Cliente: </span>{order.customerName}</p><p><span className="text-ink-muted">Teléfono: </span><a className="hover:underline" href={`tel:${order.customerPhone}`}>{order.customerPhone}</a></p><p><span className="text-ink-muted">Entrega: </span>{order.address}, {order.city}</p><p><span className="text-ink-muted">Pago: </span>{order.paymentMethod}</p></div>
            {(order.attributionSource || order.attributionCampaign) && <p className="mt-2 text-xs text-ink-muted">Llegó desde: <span className="font-medium text-ink">{order.attributionSource ?? 'anuncio'}{order.attributionCampaign ? ` · ${order.attributionCampaign}` : ''}</span>{order.attributionMedium ? ` · ${order.attributionMedium}` : ''}</p>}
            <div className="mt-4 rounded-xl bg-sand-50 divide-y divide-line/70">{order.items.map((item: any) => <div key={item.id} className="flex justify-between gap-3 px-3 py-2 text-sm"><span>{item.quantity} × {item.productName}{item.preparationMinutes ? <span className="block text-xs text-ink-muted">Preparación: {item.preparationMinutes} min</span> : null}{item.selectedOptions && Object.entries(item.selectedOptions).map(([key, value]) => <span key={key} className="block text-xs text-ink-muted">{key}: {Array.isArray(value) ? value.join(', ') : String(value)}</span>)}</span><span className="tabular-nums">{money(Number(item.unitPrice) * item.quantity)}</span></div>)}</div>
            <p className="text-right font-semibold mt-3">Envío: {money(order.shippingFee ?? 0)} · Total: {money(order.total)}{Number(order.paymentDue) < Number(order.total) && <span className="block text-xs font-normal text-ink-muted">Anticipo a cobrar: {money(order.paymentDue)} · saldo pendiente: {money(Number(order.total) - Number(order.paymentDue))}</span>}</p>
            {['CONFIRMED', 'SHIPPED', 'DELIVERED'].includes(order.status) && <div className="mt-4 rounded-xl border border-line p-4 space-y-3">
              <div><p className="text-sm font-medium">Envío y recogida</p><p className="text-xs text-ink-muted mt-1">Agenda la recogida en la transportadora y registra aquí la confirmación y la guía para seguir el despacho.</p></div>
              <div className="grid sm:grid-cols-2 gap-3">
                <label className="text-xs text-ink-muted">Transportadora<select className="input mt-1" value={shippingValue(order, 'carrier') || ''} onChange={(e) => updateDraft(order, 'carrier', e.target.value)}><option value="">Selecciona…</option>{CARRIERS.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
                <label className="text-xs text-ink-muted">Fecha de recogida<input className="input mt-1" type="date" min={new Date().toLocaleDateString('en-CA')} value={shippingValue(order, 'pickupDate') || ''} onChange={(e) => updateDraft(order, 'pickupDate', e.target.value)} /></label>
                <label className="text-xs text-ink-muted">Franja horaria<select className="input mt-1" value={shippingValue(order, 'pickupWindow') || ''} onChange={(e) => updateDraft(order, 'pickupWindow', e.target.value)}><option value="">Selecciona…</option>{WINDOW_OPTIONS.map((w) => <option key={w}>{w}</option>)}</select></label>
                <label className="text-xs text-ink-muted">Número de guía<input className="input mt-1" value={shippingValue(order, 'trackingNumber') || ''} onChange={(e) => updateDraft(order, 'trackingNumber', e.target.value)} maxLength={80} placeholder="Lo entrega la transportadora" /></label>
                <label className="text-xs text-ink-muted sm:col-span-2">Enlace de seguimiento<input className="input mt-1" type="url" value={shippingValue(order, 'trackingUrl') || ''} onChange={(e) => updateDraft(order, 'trackingUrl', e.target.value)} placeholder="https://…" /></label>
                <label className="text-xs text-ink-muted sm:col-span-2">Confirmación de recogida<input className="input mt-1" value={shippingValue(order, 'pickupConfirmation') || ''} onChange={(e) => updateDraft(order, 'pickupConfirmation', e.target.value)} maxLength={100} placeholder="Código o referencia de la transportadora" /></label>
              </div>
              <div className="flex flex-wrap gap-2">
                {shippingValue(order, 'carrier') && CARRIERS.find((c) => c.id === shippingValue(order, 'carrier'))?.url && <a className="btn-secondary btn-sm" href={CARRIERS.find((c) => c.id === shippingValue(order, 'carrier'))!.url} target="_blank" rel="noreferrer"><ExternalLink className="h-4 w-4" /> Abrir portal de recogida</a>}
                <button className="btn-primary btn-sm" disabled={savingShipping === order.id} onClick={() => saveShipping(order)}>{savingShipping === order.id ? 'Guardando…' : 'Guardar envío'}</button>
              </div>
              {order.pickupDate && <p className="text-xs text-emerald-700">Recogida registrada: {order.pickupDate} · {order.pickupWindow}{order.pickupConfirmation ? ` · Confirmación ${order.pickupConfirmation}` : ''}{order.trackingNumber ? ` · Guía ${order.trackingNumber}` : ''}</p>}
            </div>}
          </div>
          <div className="flex flex-wrap lg:flex-col gap-2 lg:w-52 shrink-0">{(NEXT[order.status] ?? []).map((action) => <button key={action.status} className={action.status === 'CANCELLED' ? 'btn-ghost text-bad justify-center' : 'btn-secondary justify-center'} onClick={() => change(order.id, action.status, action.label)}><action.icon className="h-4 w-4" />{action.label}</button>)}</div>
        </div>
      </Card>)}
    </div>}
  </>;
}
