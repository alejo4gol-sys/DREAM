'use client';
import { useParams } from 'next/navigation';
import { useEffect, useMemo, useState } from 'react';
import { api } from '@/lib/api';
import { money } from '@/lib/format';
import { ErrorBox, Loading } from '@/components/ui';

type StoreOption = { name: string; type: 'select' | 'multi' | 'text' | 'date' | 'time'; required: boolean; choices?: { label: string; priceDelta?: string }[] };
type Variant = { id: string; sku: string; options: Record<string, string>; stock: number };
type Item = { id: string; name: string; description?: string; salePrice: string; imageUrl?: string; categoryId?: string; categoryName?: string | null; storeOptions?: StoreOption[]; variants?: Variant[]; preparationMinutes?: number | null; depositPercent?: number; appointmentSchedule?: { weekdays: number[]; startTime: string; endTime: string; intervalMinutes: number; durationMinutes: number } | null };
type StoreData = { business: { name: string; logoUrl?: string; phone?: string; email?: string; city?: string; socialLinks?: Record<string,string> }; settings: any; paymentGatewayEnabled?: boolean; products: Item[] };
type Checkout = { url: string; publicKey: string; reference: string; amountInCents: string; currency: string; acceptanceToken: string; signature: string; redirectUrl: string };
type Attribution = { source?: string; medium?: string; campaign?: string; content?: string };
export default function PublicStorePage() {
  const { slug } = useParams<{ slug: string }>();
  const [data, setData] = useState<StoreData | null>(null);
  const [error, setError] = useState('');
  const [cart, setCart] = useState<Record<string, number>>({});
  const [productOptions, setProductOptions] = useState<Record<string, Record<string, string | string[]>>>({});
  const [availableSlots, setAvailableSlots] = useState<Record<string, string[]>>({});
  const [loadingSlots, setLoadingSlots] = useState<Record<string, boolean>>({});
  const [customer, setCustomer] = useState({ name: '', address: '', city: '' });
  const [payment, setPayment] = useState('');
  const [phone, setPhone] = useState('');
  const [category, setCategory] = useState('');
  const [payUrl, setPayUrl] = useState('');
  const [acceptDataUse, setAcceptDataUse] = useState(false);
  const [savingOrder, setSavingOrder] = useState(false);
  const [orderError, setOrderError] = useState('');
  const [whatsappUrl, setWhatsappUrl] = useState('');
  const [orderShortId, setOrderShortId] = useState('');
  const [checkout, setCheckout] = useState<Checkout | null>(null);
  const [attribution, setAttribution] = useState<Attribution>({});
  useEffect(() => {
    if (!slug) return;
    const key = `dream.store-attribution.${slug}`;
    try {
      const params = new URLSearchParams(window.location.search);
      const incoming = { source: params.get('utm_source') ?? '', medium: params.get('utm_medium') ?? '', campaign: params.get('utm_campaign') ?? '', content: params.get('utm_content') ?? '' };
      const stored = JSON.parse(sessionStorage.getItem(key) ?? '{}') as Attribution;
      const next = Object.fromEntries(Object.entries(incoming).map(([k, v]) => [k, v || stored[k as keyof Attribution] || ''])) as Attribution;
      if (Object.values(incoming).some(Boolean)) sessionStorage.setItem(key, JSON.stringify(next));
      setAttribution(next);
    } catch { setAttribution({}); }
    api<StoreData>(`/store/${encodeURIComponent(slug)}`, { timeoutMs: 15000 }).then((d) => { setData(d); setPayment(d.settings.paymentMethods?.find((p: any) => p.enabled)?.name ?? ''); }).catch((e) => setError((e as Error).message));
  }, [slug]);
  const items = data?.products ?? [];
  const categories = [...new Set(items.map((p) => p.categoryName).filter(Boolean))] as string[];
  const visibleItems = category ? items.filter((p) => p.categoryName === category) : items;
  const selected = useMemo(() => items.filter((p) => cart[p.id] > 0), [items, cart]);
  const cartCount = selected.reduce((sum, p) => sum + cart[p.id], 0);
  const optionExtra = (p: Item) => (p.storeOptions ?? []).reduce((sum, group) => {
    const raw = productOptions[p.id]?.[group.name]; const values = Array.isArray(raw) ? raw : raw ? [raw] : [];
    return sum + values.reduce((n, value) => n + Number(group.choices?.find((choice) => choice.label === value)?.priceDelta ?? 0), 0);
  }, 0);
  const s = data?.settings ?? {};
  const total = selected.reduce((sum, p) => sum + (Number(p.salePrice) + optionExtra(p)) * cart[p.id], 0);
  const shippingFee = Number(s.freeShippingMinimum) > 0 && total >= Number(s.freeShippingMinimum) ? 0 : Math.max(0, Number(s.shippingFee) || 0);
  const totalWithShipping = total + shippingFee;
  const variantFor = (p: Item) => (p.variants ?? []).find((variant) => (p.storeOptions ?? []).filter((g) => g.type === 'select').every((g) => productOptions[p.id]?.[g.name] === variant.options[g.name]));
  const amountNow = selected.reduce((sum, p) => sum + (Number(p.salePrice) + optionExtra(p)) * cart[p.id] * ((p.depositPercent ?? 0) > 0 ? Number(p.depositPercent) / 100 : 1), 0) + shippingFee;
  const optionsReady = selected.every((p) => (p.storeOptions ?? []).every((g) => {
    const value = productOptions[p.id]?.[g.name];
    return !g.required || Boolean(value) && (!Array.isArray(value) || value.length > 0);
  }));
  const activePayments = [...(s.paymentMethods ?? []).filter((m: any) => m.enabled), ...(data?.paymentGatewayEnabled ? [{ name: 'Wompi · tarjeta o PSE', instructions: 'Pago seguro con tarjeta débito/crédito o PSE.', enabled: true }] : [])];
  if (error) return <main className="max-w-xl mx-auto p-6 mt-16"><ErrorBox message="No encontramos esta tienda o aún no está publicada." /></main>;
  if (!data) return <Loading label="Cargando tienda…" />;
  const add = (id: string, amount: number) => {
    if (amount > 0 && orderShortId) { setOrderShortId(''); setWhatsappUrl(''); setCheckout(null); }
    setCart((c) => ({ ...c, [id]: Math.max(0, (c[id] ?? 0) + amount) }));
  };
  const setOption = (productId: string, name: string, value: string | string[]) => setProductOptions((current) => ({ ...current, [productId]: { ...(current[productId] ?? {}), [name]: value } }));
  const loadSlots = async (productId: string, group: StoreOption, value: string) => {
    setOption(productId, group.name, value); setOption(productId, (items.find((p) => p.id === productId)?.storeOptions ?? []).find((o) => o.type === 'time')?.name ?? '', '');
    if (!value) { setAvailableSlots((current) => ({ ...current, [productId]: [] })); return; }
    setLoadingSlots((current) => ({ ...current, [productId]: true }));
    try { const result = await api<{ slots: string[] }>(`/store/${encodeURIComponent(slug)}/${productId}/slots?date=${encodeURIComponent(value)}`); setAvailableSlots((current) => ({ ...current, [productId]: result.slots })); }
    catch (e) { setAvailableSlots((current) => ({ ...current, [productId]: [] })); setOrderError((e as Error).message); }
    finally { setLoadingSlots((current) => ({ ...current, [productId]: false })); }
  };
  const order = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selected.length || !payment || savingOrder) return;
    const method = activePayments.find((m: any) => m.name === payment);
    setSavingOrder(true); setOrderError('');
    try {
      const saved = await api<{ id: string; shortId: string; total: string; shippingFee: string; paymentDue: string; checkout?: Checkout; items: { productName: string; quantity: number; unitPrice: string; options: Record<string, string | string[]> }[] }>(`/store/${encodeURIComponent(slug)}/orders`, {
        body: { customerName: customer.name, customerPhone: phone, address: customer.address, city: customer.city,
          paymentMethod: payment, acceptedDataUse: acceptDataUse,
          attributionSource: attribution.source, attributionMedium: attribution.medium, attributionCampaign: attribution.campaign, attributionContent: attribution.content,
          items: selected.map((p) => ({ productId: p.id, variantId: variantFor(p)?.id, quantity: cart[p.id], options: productOptions[p.id] ?? {} })) },
        timeoutMs: 20000,
      });
      const lines = saved.items.map((item) => `• ${item.productName} × ${item.quantity}${Object.entries(item.options).length ? ` (${Object.entries(item.options).map(([k, v]) => `${k}: ${Array.isArray(v) ? v.join(', ') : v}`).join(' · ')})` : ''} — ${money(Number(item.unitPrice) * item.quantity)}`).join('\n');
      const message = `Hola, acabo de registrar en la tienda el pedido #${saved.shortId}:\n\n${lines}\n\nEnvío: ${money(saved.shippingFee)}\nTotal del pedido: ${money(saved.total)}\nA pagar ahora: ${money(saved.paymentDue)}\nMedio de pago: ${payment}${method?.instructions ? ` (${method.instructions})` : ''}\nNombre: ${customer.name}\nTeléfono: ${phone}\nDirección: ${customer.address}, ${customer.city}`;
      setOrderShortId(saved.shortId);
      setCheckout(saved.checkout ?? null);
      setWhatsappUrl(s.whatsapp ? `https://wa.me/${String(s.whatsapp).replace(/\D/g, '')}?text=${encodeURIComponent(message)}` : '');
      setPayUrl(saved.checkout ? '' : /^https?:\/\//i.test(method?.instructions ?? '') ? method.instructions : '');
      setCart({});
    } catch (e) { setOrderError((e as Error).message); }
    finally { setSavingOrder(false); }
  };
  const openCheckout = () => {
    if (!checkout) return;
    const form = document.createElement('form'); form.method = 'GET'; form.action = checkout.url;
    const values: Record<string, string> = { 'public-key': checkout.publicKey, currency: checkout.currency, 'amount-in-cents': checkout.amountInCents,
      reference: checkout.reference, 'signature:integrity': checkout.signature, 'acceptance-token': checkout.acceptanceToken, 'redirect-url': checkout.redirectUrl };
    Object.entries(values).forEach(([name, value]) => { const input = document.createElement('input'); input.type = 'hidden'; input.name = name; input.value = value; form.appendChild(input); });
    document.body.appendChild(form); form.submit(); form.remove();
  };
  const layout = s.layout === 'editorial' ? 'grid-cols-1 sm:grid-cols-2' : s.layout === 'minimal' ? 'grid-cols-2 sm:grid-cols-3 lg:grid-cols-4' : 'grid-cols-2 md:grid-cols-3 lg:grid-cols-4';
  const fontFamily = s.fontStyle === 'serif' ? 'Georgia, "Times New Roman", serif' : s.fontStyle === 'rounded' ? '"Trebuchet MS", Arial, sans-serif' : 'Inter, ui-sans-serif, system-ui, sans-serif';
  const cardRadius = s.cardStyle === 'classic' ? 'rounded-lg' : s.cardStyle === 'outline' ? 'rounded-none border-2' : 'rounded-3xl';
  const buttonRadius = s.buttonStyle === 'square' ? 0 : s.buttonStyle === 'round' ? 10 : 99;
  const imageRatio = s.imageRatio === 'portrait' ? 'aspect-[3/4]' : s.imageRatio === 'wide' ? 'aspect-[16/9]' : 'aspect-square';
  const socialHosts: Record<string, string> = { instagram: 'instagram.com', facebook: 'facebook.com', tiktok: 'tiktok.com', whatsapp: 'wa.me' };
  const socialLinks = Object.entries(data.business.socialLinks ?? {}).flatMap(([network, value]) => {
    const host = socialHosts[network.toLowerCase()];
    if (!host || !value?.trim()) return [];
    const raw = value.trim();
    const href = /^https?:\/\//i.test(raw) ? raw : `https://${host}/${raw.replace(/^@/, '').replace(/^\/+/, '')}`;
    try { return new URL(href).protocol === 'https:' ? [{ network, href }] : []; } catch { return []; }
  });
  const heroCopy = <div className={`max-w-3xl py-8 ${s.textAlign === 'center' ? 'text-center mx-auto' : ''}`}><p className="text-xs uppercase tracking-[0.25em] opacity-60">{data.business.name}</p><h1 className="text-4xl sm:text-6xl font-semibold mt-3">{s.headline || 'Hecho para ti'}</h1><p className="mt-4 text-base sm:text-lg opacity-75 max-w-2xl">{s.description || ''}</p>{s.shippingInfo && <p className="mt-5 inline-flex rounded-full px-4 py-2 text-xs" style={{ background: s.accentColor || '#B69C72', color: '#fff' }}>{s.shippingInfo}</p>}</div>;
  return <main style={{ background: s.backgroundColor || '#FAF8F4', color: s.primaryColor || '#171717', fontFamily }} className="min-h-screen pb-20">
    {s.announcement && <div className="px-4 py-2 text-center text-xs font-medium" style={{ background: s.accentColor || '#B69C72', color: '#fff' }}>{s.announcement}</div>}
    <header className="border-b border-black/10"><div className="max-w-6xl mx-auto px-5 h-16 flex items-center gap-3">{data.business.logoUrl && <img src={data.business.logoUrl} alt="" className="h-10 w-10 rounded-full object-cover" />}<span className="font-semibold tracking-wide">{data.business.name}</span><a href="#catalogo" className="ml-auto text-sm opacity-70">Ver productos</a>{cartCount > 0 && <button type="button" className="ml-3 rounded-full px-4 py-2 text-xs font-semibold text-white" style={{ background: s.primaryColor || '#171717' }} onClick={() => document.getElementById('carrito')?.scrollIntoView({ behavior: 'smooth', block: 'start' })}>Ver carrito · {cartCount} · {money(totalWithShipping)}</button>}</div></header>
    <section className="max-w-6xl mx-auto px-5 pt-8">
      {s.heroLayout === 'overlay' && s.heroImage ? <div className="relative h-72 sm:h-[420px] rounded-3xl overflow-hidden"><img src={s.heroImage} alt="" className="absolute inset-0 w-full h-full object-cover" /><div className="absolute inset-0 bg-black/45" /><div className="relative h-full flex items-center px-6 sm:px-12 text-white">{heroCopy}</div></div>
        : s.heroLayout === 'split' && s.heroImage ? <div className="grid md:grid-cols-2 items-center gap-7"><div className="overflow-hidden rounded-3xl"><img src={s.heroImage} alt="" className="w-full aspect-[4/3] object-cover" /></div>{heroCopy}</div>
          : <>{s.heroImage && s.heroLayout !== 'simple' && <div className="h-56 sm:h-80 rounded-3xl overflow-hidden mb-5"><img src={s.heroImage} alt="" className="w-full h-full object-cover" /></div>}{heroCopy}</>}
    </section>
    <section id="catalogo" className="max-w-6xl mx-auto px-5 py-8">
      <div className={`flex flex-col sm:flex-row sm:items-end sm:justify-between gap-3 mb-5 ${s.textAlign === 'center' ? 'text-center' : ''}`}><div><p className="text-xs uppercase tracking-widest opacity-55">Colección</p><h2 className="text-3xl font-semibold mt-1">{s.catalogTitle || 'Nuestros productos'}</h2></div><span className="text-sm opacity-60">{items.length} productos</span></div>
      {categories.length > 0 && <div className="flex flex-wrap gap-2 mb-5"><button type="button" onClick={() => setCategory('')} className={`rounded-full px-4 py-2 text-xs ${category ? 'bg-white/70' : 'text-white'}`} style={{ background: category ? undefined : s.primaryColor || '#171717' }}>Todos</button>{categories.map((name) => <button type="button" key={name} onClick={() => setCategory(name)} className="rounded-full px-4 py-2 text-xs" style={{ background: category === name ? s.primaryColor || '#171717' : '#ffffffb8', color: category === name ? '#fff' : s.primaryColor || '#171717' }}>{name}</button>)}</div>}
      {visibleItems.length ? <div className={`grid ${layout} gap-4 sm:gap-6`}>{visibleItems.map((p) => <article key={p.id} className={`overflow-hidden border border-black/10 ${cardRadius} ${s.layout === 'editorial' ? 'sm:grid sm:grid-cols-2' : ''}`} style={{ background: '#fff' }}>
        <div className={`${imageRatio} bg-black/5 overflow-hidden`}>{p.imageUrl ? <img src={p.imageUrl} alt={p.name} className="h-full w-full object-cover" /> : <div className="h-full flex items-center justify-center text-sm opacity-40">{p.name}</div>}</div>
        <div className={`p-4 ${s.textAlign === 'center' ? 'text-center' : ''}`}><p className="text-[10px] uppercase tracking-wider opacity-50">{p.categoryName}</p><h3 className="font-medium">{p.name}</h3>{s.showProductDescription !== false && p.description && <p className="text-xs opacity-65 mt-1 line-clamp-2">{p.description}</p>}{p.preparationMinutes ? <p className="text-[11px] opacity-60 mt-2">Preparación aproximada: {p.preparationMinutes} min</p> : null}{(p.depositPercent ?? 0) > 0 && <p className="text-[11px] opacity-60 mt-1">Anticipo para reservar: {p.depositPercent}%</p>}
          {(p.storeOptions ?? []).map((group) => <label key={group.name} className="block text-left mt-3"><span className="text-[11px] opacity-70">{group.name}{group.required ? ' *' : ''}{group.type === 'multi' ? ' · puedes elegir varios' : ''}</span>
            {group.type === 'select' || group.type === 'multi' ? <select multiple={group.type === 'multi'} required={group.required && group.type === 'select'} className="w-full rounded-lg border p-2 mt-1 text-xs min-h-9" value={group.type === 'multi' ? (Array.isArray(productOptions[p.id]?.[group.name]) ? productOptions[p.id][group.name] as string[] : []) : String(productOptions[p.id]?.[group.name] ?? '')} onChange={(e) => setOption(p.id, group.name, group.type === 'multi' ? Array.from(e.target.selectedOptions).map((o) => o.value).filter(Boolean) : e.target.value)}><option value="">{group.type === 'multi' ? 'Elige opciones' : `Selecciona ${group.name.toLocaleLowerCase('es')}`}</option>{(group.choices ?? []).map((choice) => <option key={choice.label} value={choice.label}>{choice.label}{Number(choice.priceDelta) > 0 ? ` (+${money(choice.priceDelta)})` : ''}</option>)}</select>
              : group.type === 'date' && p.appointmentSchedule ? <input required={group.required} type="date" min={new Date().toLocaleDateString('en-CA')} className="w-full rounded-lg border p-2 mt-1 text-xs" value={String(productOptions[p.id]?.[group.name] ?? '')} onChange={(e) => loadSlots(p.id, group, e.target.value)} />
                : group.type === 'time' && p.appointmentSchedule ? <select required={group.required} disabled={!productOptions[p.id]?.[ (p.storeOptions ?? []).find((o) => o.type === 'date')?.name ?? '' ] || loadingSlots[p.id]} className="w-full rounded-lg border p-2 mt-1 text-xs disabled:opacity-50" value={String(productOptions[p.id]?.[group.name] ?? '')} onChange={(e) => setOption(p.id, group.name, e.target.value)}><option value="">{loadingSlots[p.id] ? 'Buscando horarios…' : !productOptions[p.id]?.[(p.storeOptions ?? []).find((o) => o.type === 'date')?.name ?? ''] ? 'Elige primero una fecha' : availableSlots[p.id]?.length ? 'Selecciona un horario disponible' : 'No hay horarios disponibles'}</option>{(availableSlots[p.id] ?? []).map((slot) => <option key={slot} value={slot}>{slot}</option>)}</select>
                  : <input required={group.required} type={group.type === 'date' || group.type === 'time' ? group.type : 'text'} maxLength={120} className="w-full rounded-lg border p-2 mt-1 text-xs" value={String(productOptions[p.id]?.[group.name] ?? '')} onChange={(e) => setOption(p.id, group.name, e.target.value)} placeholder={group.type === 'text' ? `Indica ${group.name.toLocaleLowerCase('es')}` : undefined} />}
          </label>)}
          {variantFor(p) && <p className="text-[11px] opacity-65 mt-2">Disponibles en esta combinación: {variantFor(p)?.stock}</p>}
          <div className={`flex items-center justify-between mt-4 ${s.textAlign === 'center' ? 'flex-col gap-3' : ''}`}><span className="font-semibold">{money(Number(p.salePrice) + optionExtra(p))}</span><button type="button" className="px-4 py-2 text-xs font-medium disabled:opacity-40" disabled={(p.storeOptions ?? []).some((g) => { const v = productOptions[p.id]?.[g.name]; return g.required && (!v || Array.isArray(v) && !v.length); }) || (p.storeOptions ?? []).some((g) => g.type === 'select') && (!variantFor(p) || variantFor(p)!.stock < 1) || Boolean(variantFor(p) && cart[p.id] >= variantFor(p)!.stock)} style={{ background: s.primaryColor || '#171717', color: '#fff', borderRadius: buttonRadius }} onClick={() => add(p.id, 1)}>{variantFor(p)?.stock === 0 ? 'Agotado' : s.productButtonText || 'Agregar'}{cart[p.id] > 0 ? ` · ${cart[p.id]}` : ''}</button></div></div>
      </article>)}</div> : <div className="rounded-2xl border border-dashed border-black/20 p-10 text-center opacity-70">{items.length ? 'No hay productos en esta categoría.' : 'Pronto encontrarás productos aquí.'}</div>}
    </section>
    {selected.length > 0 && <section id="carrito" className="max-w-6xl mx-auto px-5 pb-14 scroll-mt-6"><div className="rounded-3xl bg-white shadow-sm border border-black/10 p-5 sm:p-8 grid lg:grid-cols-[1fr_360px] gap-8">
      <div><p className="text-xs uppercase tracking-widest opacity-55">Tu selección</p><h2 className="font-display text-3xl font-semibold mt-1">Finaliza tu pedido</h2><div className="divide-y divide-black/10 mt-4">{selected.map((p) => <div key={p.id} className="py-3 flex items-center gap-3"><div className="flex-1"><p className="text-sm font-medium">{p.name}</p><p className="text-xs opacity-60">{money(Number(p.salePrice) + optionExtra(p))} c/u</p>{Object.entries(productOptions[p.id] ?? {}).map(([k, v]) => <p key={k} className="text-[11px] opacity-60">{k}: {Array.isArray(v) ? v.join(', ') : v}</p>)}</div><button type="button" onClick={() => add(p.id, -1)} className="h-8 w-8 rounded-full border">−</button><span className="w-5 text-center text-sm">{cart[p.id]}</span><button type="button" onClick={() => add(p.id, 1)} className="h-8 w-8 rounded-full border">+</button><button type="button" className="text-xs opacity-50 ml-2" onClick={() => setCart((c) => ({ ...c, [p.id]: 0 }))}>Quitar</button></div>)}</div><div className="border-t border-black/10 pt-4 mt-2 space-y-1 text-sm"><div className="flex justify-between"><span>Productos</span><span>{money(total)}</span></div><div className="flex justify-between"><span>Envío</span><span>{shippingFee ? money(shippingFee) : 'Gratis'}</span></div>{shippingFee === 0 && Number(s.freeShippingMinimum) > 0 && total >= Number(s.freeShippingMinimum) && <p className="text-xs opacity-60">Envío gratis aplicado.</p>}<div className="flex justify-between font-semibold"><span>Total del pedido</span><span>{money(totalWithShipping)}</span></div><div className="flex justify-between font-semibold"><span>A pagar ahora</span><span>{money(amountNow)}</span></div></div></div>
      <form onSubmit={order} className="space-y-3"><h3 className="font-medium">Datos de entrega y pago</h3><input className="w-full rounded-xl border p-3 text-sm" required placeholder="Tu nombre" value={customer.name} onChange={(e) => setCustomer({ ...customer, name: e.target.value })} /><input className="w-full rounded-xl border p-3 text-sm" required type="tel" inputMode="tel" placeholder="Tu teléfono" value={phone} onChange={(e) => setPhone(e.target.value)} /><input className="w-full rounded-xl border p-3 text-sm" required placeholder="Dirección de entrega" value={customer.address} onChange={(e) => setCustomer({ ...customer, address: e.target.value })} /><input className="w-full rounded-xl border p-3 text-sm" required placeholder="Ciudad" value={customer.city} onChange={(e) => setCustomer({ ...customer, city: e.target.value })} />
        {activePayments.length > 0 ? <label className="block"><span className="text-xs opacity-70">Medio de pago</span><select className="w-full rounded-xl border p-3 text-sm mt-1" required value={payment} onChange={(e) => setPayment(e.target.value)}>{activePayments.map((m: any) => <option key={m.name}>{m.name}</option>)}</select>{activePayments.find((m: any) => m.name === payment)?.instructions && <span className="block mt-2 rounded-xl bg-sand-50 p-3 text-xs">{activePayments.find((m: any) => m.name === payment)?.instructions}</span>}</label> : <p className="text-xs text-amber-800 bg-amber-50 p-3 rounded-xl">Esta tienda aún no configuró sus medios de pago, así que no puede recibir pedidos en línea.</p>}
        <p className="text-[11px] opacity-60">El pedido se guarda en DREAMS. Si no se abre un enlace de pago, coordina el pago con la tienda.</p>
        {orderError && <p role="alert" className="text-xs text-red-700 bg-red-50 rounded-xl p-3">{orderError}</p>}
        {!orderShortId && <label className="flex items-start gap-2 text-xs opacity-75"><input type="checkbox" required checked={acceptDataUse} onChange={(e) => setAcceptDataUse(e.target.checked)} className="mt-0.5" /><span>Autorizo a {data.business.name} a usar estos datos para gestionar y entregar mi pedido.</span></label>}
        {orderShortId ? <div className="space-y-2"><p role="status" className="text-xs text-emerald-700">Pedido #{orderShortId} guardado en DREAMS. La tienda ya puede gestionarlo.</p>{checkout && <button type="button" onClick={openCheckout} className="block w-full text-center rounded-xl p-3 text-sm font-medium" style={{ background: s.accentColor || '#B69C72', color: '#fff' }}>Pagar con Wompi</button>}{payUrl && <a href={payUrl} target="_blank" rel="noreferrer" className="block text-center rounded-xl p-3 text-sm font-medium" style={{ background: s.accentColor || '#B69C72', color: '#fff' }}>Pagar ahora</a>}{whatsappUrl && <a href={whatsappUrl} target="_blank" rel="noreferrer" className="block text-center rounded-xl p-3 text-sm font-medium" style={{ background: s.primaryColor || '#171717', color: '#fff' }}>Continuar por WhatsApp</a>}</div> : <button className="w-full rounded-xl p-3 text-sm font-medium disabled:opacity-40" disabled={!activePayments.length || savingOrder || !optionsReady} style={{ background: s.primaryColor || '#171717', color: '#fff' }}>{savingOrder ? 'Guardando pedido…' : !optionsReady ? 'Completa las opciones del producto' : 'Confirmar pedido'}</button>}
      </form>
    </div></section>}
    {orderShortId && <section className="max-w-3xl mx-auto px-5 pb-14"><div className="rounded-3xl bg-white shadow-sm border border-black/10 p-6 text-center"><p className="font-semibold text-lg">Tu pedido #{orderShortId} ya quedó registrado</p><p className="text-sm opacity-70 mt-2">La tienda puede verlo y gestionarlo desde DREAMS.{!s.whatsapp ? ' El negocio recibirá el pedido en su panel.' : ' Continúa por WhatsApp para conversar con el negocio.'}</p><div className="flex flex-wrap justify-center gap-2">{checkout && <button type="button" onClick={openCheckout} className="inline-flex mt-4 rounded-xl px-5 py-3 text-sm font-medium" style={{ background: s.accentColor || '#B69C72', color: '#fff' }}>Pagar con Wompi</button>}{payUrl && <a href={payUrl} target="_blank" rel="noreferrer" className="inline-flex mt-4 rounded-xl px-5 py-3 text-sm font-medium" style={{ background: s.accentColor || '#B69C72', color: '#fff' }}>Pagar ahora</a>}{whatsappUrl && <a href={whatsappUrl} target="_blank" rel="noreferrer" className="inline-flex mt-4 rounded-xl px-5 py-3 text-sm font-medium" style={{ background: s.primaryColor || '#171717', color: '#fff' }}>Continuar por WhatsApp</a>}</div></div></section>}
    {cartCount > 0 && <div className="fixed z-20 bottom-3 inset-x-3 sm:hidden"><button type="button" className="w-full rounded-2xl py-4 shadow-lg text-sm font-semibold text-white" style={{ background: s.primaryColor || '#171717' }} onClick={() => document.getElementById('carrito')?.scrollIntoView({ behavior: 'smooth', block: 'start' })}>Ver carrito · {cartCount} productos · {money(totalWithShipping)}</button></div>}
    <footer className="border-t border-black/10"><div className="max-w-6xl mx-auto px-5 py-7 flex flex-col sm:flex-row gap-3 justify-between text-xs opacity-70"><span>{data.business.name}{data.business.city ? ` · ${data.business.city}` : ''}</span>{s.showSocialLinks !== false && socialLinks.length > 0 && <nav aria-label="Redes del negocio" className="flex gap-4">{socialLinks.map((link) => <a key={link.network} href={link.href} target="_blank" rel="noreferrer" className="capitalize hover:underline">{link.network}</a>)}</nav>}<span>Pedidos web · DREAMS</span></div></footer>
  </main>;
}
