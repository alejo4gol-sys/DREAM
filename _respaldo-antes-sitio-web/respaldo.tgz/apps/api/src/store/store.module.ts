import {
  BadRequestException, Body, ConflictException, Controller, Get, Injectable, Module, NotFoundException, Param, ParseUUIDPipe, Patch, Post, Query,
} from '@nestjs/common';
import { createHash, timingSafeEqual } from 'node:crypto';
import { Type } from 'class-transformer';
import { ArrayMaxSize, ArrayMinSize, Equals, IsArray, IsBoolean, IsIn, IsInt, IsObject, IsOptional, IsString, IsUUID, Length, Matches, Max, MaxLength, Min, ValidateNested } from 'class-validator';
import { and, desc, eq, inArray, sql } from 'drizzle-orm';
import { Ctx, Public, RequestContext, RequirePermissions } from '../common/auth.guard';
import { isUniqueViolation } from '../common/db-errors';
import { D, m2 } from '../common/money';
import { InventoryModule } from '../inventory/inventory.module';
import { InventoryService } from '../inventory/inventory.service';
import { NotificationsService } from '../notifications/notifications.service';
import { Db, InjectDb } from '../db/db';
import { businesses, categories, customers, productVariants, products, storeOrderItems, storeOrders } from '../db/schema';
import { CryptoService } from '../common/crypto.service';
import { config } from '../config';

const WOMPI_METHOD = 'Wompi · tarjeta o PSE';
const WOMPI_CURRENCY = 'COP';
const sha256 = (value: string) => createHash('sha256').update(value).digest('hex');
const wompiApi = (publicKey: string) => publicKey.startsWith('pub_test_') ? 'https://sandbox.wompi.co/v1' : 'https://production.wompi.co/v1';
class WompiConfigDto {
  @IsString() @Length(8, 120) publicKey: string;
  @IsString() @Length(8, 240) privateKey: string;
  @IsString() @Length(8, 240) integritySecret: string;
  @IsString() @Length(8, 240) eventSecret: string;
}

const HEX = /^#[0-9a-fA-F]{6}$/;
class StorePaymentDto {
  @IsString() @Length(2, 60) name: string;
  @IsOptional() @IsString() @MaxLength(240) instructions?: string;
  @IsBoolean() enabled: boolean;
}
class StoreConfigDto {
  @IsString() @Matches(/^[a-z0-9]+(?:-[a-z0-9]+)*$/, { message: 'Usa letras minúsculas, números y guiones para el enlace' }) @Length(3, 80) slug: string;
  @IsBoolean() enabled: boolean;
  @IsOptional() @IsString() @MaxLength(100) headline?: string;
  @IsOptional() @IsString() @MaxLength(1000) description?: string;
  @IsOptional() @IsString() @MaxLength(500) heroImage?: string;
  @IsOptional() @IsIn(['banner', 'split', 'overlay', 'simple']) heroLayout?: string;
  @IsOptional() @IsIn(['grid', 'editorial', 'minimal']) layout?: string;
  @IsOptional() @IsIn(['modern', 'serif', 'rounded']) fontStyle?: string;
  @IsOptional() @IsIn(['left', 'center']) textAlign?: string;
  @IsOptional() @IsIn(['classic', 'soft', 'outline']) cardStyle?: string;
  @IsOptional() @IsIn(['round', 'square', 'pill']) buttonStyle?: string;
  @IsOptional() @IsIn(['square', 'portrait', 'wide']) imageRatio?: string;
  @IsOptional() @IsString() @MaxLength(80) catalogTitle?: string;
  @IsOptional() @IsString() @MaxLength(32) productButtonText?: string;
  @IsOptional() @IsString() @MaxLength(100) announcement?: string;
  @IsOptional() @IsBoolean() showProductDescription?: boolean;
  @IsOptional() @IsBoolean() showSocialLinks?: boolean;
  @IsOptional() @Matches(HEX) primaryColor?: string;
  @IsOptional() @Matches(HEX) backgroundColor?: string;
  @IsOptional() @Matches(HEX) accentColor?: string;
  @IsOptional() @IsString() @MaxLength(30) whatsapp?: string;
  @IsOptional() @IsString() @MaxLength(500) shippingInfo?: string;
  @IsOptional() @Matches(/^\d{1,12}(?:\.\d{1,2})?$/) shippingFee?: string;
  @IsOptional() @Matches(/^\d{1,12}(?:\.\d{1,2})?$/) freeShippingMinimum?: string;
  @IsArray() @ArrayMinSize(1) @ArrayMaxSize(8) @ValidateNested({ each: true }) @Type(() => StorePaymentDto)
  paymentMethods: StorePaymentDto[];
}
class StoreOrderLineDto {
  @IsUUID() productId: string;
  @IsOptional() @IsUUID() variantId?: string;
  @Type(() => Number) @IsInt() @Min(1) @Max(99) quantity: number;
  @IsOptional() @IsObject() options?: Record<string, string | string[]>;
}
class CreateStoreOrderDto {
  @IsString() @Length(2, 160) customerName: string;
  @IsString() @Length(7, 40) @Matches(/^\+?[0-9\s()-]+$/) customerPhone: string;
  @IsString() @Length(5, 255) address: string;
  @IsString() @Length(2, 120) city: string;
  @IsString() @Length(2, 80) paymentMethod: string;
  @IsBoolean() @Equals(true) acceptedDataUse: boolean;
  @IsOptional() @IsString() @MaxLength(80) attributionSource?: string;
  @IsOptional() @IsString() @MaxLength(80) attributionMedium?: string;
  @IsOptional() @IsString() @MaxLength(160) attributionCampaign?: string;
  @IsOptional() @IsString() @MaxLength(160) attributionContent?: string;
  @IsArray() @ArrayMinSize(1) @ArrayMaxSize(30) @ValidateNested({ each: true }) @Type(() => StoreOrderLineDto)
  items: StoreOrderLineDto[];
}
class StoreOrderStatusDto {
  @IsIn(['CONFIRMED', 'SHIPPED', 'DELIVERED', 'CANCELLED']) status: 'CONFIRMED' | 'SHIPPED' | 'DELIVERED' | 'CANCELLED';
}
const CARRIERS = ['COORDINADORA', 'SERVIENTREGA', 'INTER_RAPIDISIMO', 'ENVIA', 'TCC', 'OTRA'] as const;
class StoreOrderShippingDto {
  @IsIn(CARRIERS) carrier: typeof CARRIERS[number];
  @IsString() @Matches(/^\d{4}-\d{2}-\d{2}$/) pickupDate: string;
  @IsString() @Length(2, 40) pickupWindow: string;
  @IsOptional() @IsString() @MaxLength(100) pickupConfirmation?: string;
  @IsOptional() @IsString() @MaxLength(80) trackingNumber?: string;
  @IsOptional() @IsString() @MaxLength(500) @Matches(/^https:\/\//) trackingUrl?: string;
}

@Injectable()
class StoreService {
  constructor(@InjectDb() private db: Db, private inventory: InventoryService, private notifications: NotificationsService, private crypto: CryptoService) {}
  async publicStore(slug: string) {
    const store = await this.db.query.businesses.findFirst({ where: eq(businesses.storeSlug, slug) });
    if (!store?.storeEnabled) throw new NotFoundException('Esta tienda no está disponible');
    const items = await this.db.select({ id: products.id, name: products.name, description: products.description, storeOptions: products.storeOptions,
      preparationMinutes: products.preparationMinutes, depositPercent: products.depositPercent, appointmentSchedule: products.appointmentSchedule,
      salePrice: products.salePrice, imageUrl: products.imageUrl, categoryId: products.categoryId, categoryName: categories.name })
      .from(products).leftJoin(categories, eq(categories.id, products.categoryId))
      .where(and(eq(products.businessId, store.id), eq(products.isActive, true))).orderBy(products.name);
    const variants = items.length ? await this.db.select().from(productVariants).where(and(eq(productVariants.businessId, store.id), inArray(productVariants.productId, items.map((p) => p.id)), eq(productVariants.isActive, true))) : [];
    const byProduct = new Map<string, typeof variants>();
    for (const variant of variants) byProduct.set(variant.productId, [...(byProduct.get(variant.productId) ?? []), variant]);
    return { business: { name: store.tradeName, logoUrl: store.logoUrl, phone: store.phone, email: store.email,
      city: store.city, socialLinks: store.socialLinks }, settings: store.storeConfig,
      paymentGatewayEnabled: Boolean(store.wompiPublicKey && store.wompiPrivateKeyEnc && store.wompiIntegritySecretEnc && store.wompiEventSecretEnc),
      products: items.map((p) => ({ ...p, variants: byProduct.get(p.id) ?? [] })) };
  }

  async availability(slug: string, productId: string, date: string) {
    const store = await this.db.query.businesses.findFirst({ where: and(eq(businesses.storeSlug, slug), eq(businesses.storeEnabled, true)) });
    const product = store && await this.db.query.products.findFirst({ where: and(eq(products.id, productId), eq(products.businessId, store.id), eq(products.isActive, true)) });
    const schedule = product?.appointmentSchedule;
    if (!store || !schedule || !/^\d{4}-\d{2}-\d{2}$/.test(date)) throw new BadRequestException('No hay agenda configurada para ese servicio');
    const day = new Date(`${date}T12:00:00`).getDay();
    if (!schedule.weekdays.includes(day)) return { slots: [] };
    const dateGroup = (product.storeOptions ?? []).find((o) => o.type === 'date');
    const timeGroup = (product.storeOptions ?? []).find((o) => o.type === 'time');
    if (!dateGroup || !timeGroup) return { slots: [] };
    const booked = await this.db.select({ selectedOptions: storeOrderItems.selectedOptions }).from(storeOrderItems)
      .innerJoin(storeOrders, eq(storeOrders.id, storeOrderItems.orderId))
      .where(and(eq(storeOrders.businessId, store.id), eq(storeOrderItems.productId, productId), inArray(storeOrders.status, ['RECEIVED', 'CONFIRMED']), sql`${storeOrderItems.selectedOptions}->>${dateGroup.name} = ${date}`));
    const occupied = booked.map((b) => String((b.selectedOptions as any)?.[timeGroup.name] ?? '')).filter(Boolean).map((value) => Number(value.slice(0, 2)) * 60 + Number(value.slice(3)));
    const start = Number(schedule.startTime.slice(0, 2)) * 60 + Number(schedule.startTime.slice(3));
    const end = Number(schedule.endTime.slice(0, 2)) * 60 + Number(schedule.endTime.slice(3));
    const slots: string[] = [];
    for (let minute = start; minute + schedule.durationMinutes <= end; minute += schedule.intervalMinutes) {
      const slot = `${String(Math.floor(minute / 60)).padStart(2, '0')}:${String(minute % 60).padStart(2, '0')}`;
      if (!occupied.some((used) => minute < used + schedule.durationMinutes && used < minute + schedule.durationMinutes)) slots.push(slot);
    }
    return { slots };
  }
  async settings(businessId: string) {
    const store = await this.db.query.businesses.findFirst({ where: eq(businesses.id, businessId) });
    if (!store) throw new NotFoundException();
    return { slug: store.storeSlug ?? '', enabled: store.storeEnabled, config: store.storeConfig ?? {},
      paymentGatewayEnabled: Boolean(store.wompiPublicKey && store.wompiPrivateKeyEnc && store.wompiIntegritySecretEnc && store.wompiEventSecretEnc) };
  }
  async saveWompi(businessId: string, dto: WompiConfigDto) {
    await this.db.update(businesses).set({ wompiPublicKey: dto.publicKey.trim(),
      wompiPrivateKeyEnc: this.crypto.encrypt(dto.privateKey.trim()), wompiIntegritySecretEnc: this.crypto.encrypt(dto.integritySecret.trim()),
      wompiEventSecretEnc: this.crypto.encrypt(dto.eventSecret.trim()) }).where(eq(businesses.id, businessId));
    return { configured: true };
  }
  async save(businessId: string, dto: StoreConfigDto) {
    try {
      const [updated] = await this.db.update(businesses).set({ storeSlug: dto.slug, storeEnabled: dto.enabled,
        storeConfig: { headline: dto.headline ?? '', description: dto.description ?? '', heroImage: dto.heroImage ?? '',
          heroLayout: dto.heroLayout ?? 'banner', fontStyle: dto.fontStyle ?? 'modern', textAlign: dto.textAlign ?? 'left',
          cardStyle: dto.cardStyle ?? 'soft', buttonStyle: dto.buttonStyle ?? 'pill', imageRatio: dto.imageRatio ?? 'square', catalogTitle: dto.catalogTitle ?? 'Nuestros productos',
          productButtonText: dto.productButtonText ?? 'Agregar', announcement: dto.announcement ?? '',
          showProductDescription: dto.showProductDescription ?? true, showSocialLinks: dto.showSocialLinks ?? true,
          layout: dto.layout ?? 'grid', primaryColor: dto.primaryColor ?? '#171717', backgroundColor: dto.backgroundColor ?? '#FAF8F4',
          accentColor: dto.accentColor ?? '#B69C72', whatsapp: dto.whatsapp ?? '', shippingInfo: dto.shippingInfo ?? '',
          shippingFee: dto.shippingFee ?? '0', freeShippingMinimum: dto.freeShippingMinimum ?? '',
          paymentMethods: dto.paymentMethods.map((p) => ({ ...p, instructions: p.instructions ?? '' })) } })
        .where(eq(businesses.id, businessId)).returning({ slug: businesses.storeSlug, enabled: businesses.storeEnabled, config: businesses.storeConfig });
      return updated;
    } catch (e) {
      if (isUniqueViolation(e)) throw new ConflictException('Ese enlace ya está siendo usado por otra tienda');
      throw e;
    }
  }

  async createOrder(slug: string, dto: CreateStoreOrderDto) {
    const store = await this.db.query.businesses.findFirst({ where: eq(businesses.storeSlug, slug) });
    if (!store?.storeEnabled) throw new NotFoundException('Esta tienda no está disponible');
    const settings = store.storeConfig as { paymentMethods?: { name: string; enabled: boolean }[]; shippingFee?: string; freeShippingMinimum?: string };
    if (dto.paymentMethod === WOMPI_METHOD) {
      if (!store.wompiPublicKey || !store.wompiPrivateKeyEnc || !store.wompiIntegritySecretEnc || !store.wompiEventSecretEnc) throw new BadRequestException('El pago en línea todavía no está configurado por esta tienda');
    } else if (!settings.paymentMethods?.some((m) => m.enabled && m.name === dto.paymentMethod)) throw new BadRequestException('Selecciona un medio de pago disponible');
    const quantities = new Map<string, number>();
    for (const item of dto.items) quantities.set(item.productId, (quantities.get(item.productId) ?? 0) + item.quantity);
    const ids = [...quantities.keys()];
    const catalog = await this.db.select().from(products).where(and(eq(products.businessId, store.id), inArray(products.id, ids), eq(products.isActive, true)));
    if (catalog.length !== ids.length) throw new BadRequestException('Uno de los productos ya no está disponible');
    const byId = new Map(catalog.map((p) => [p.id, p]));
    const variants = await this.db.select().from(productVariants).where(and(eq(productVariants.businessId, store.id), inArray(productVariants.productId, ids), eq(productVariants.isActive, true)));
    const variantsByProduct = new Map<string, typeof variants>();
    for (const variant of variants) variantsByProduct.set(variant.productId, [...(variantsByProduct.get(variant.productId) ?? []), variant]);
    const selections = new Map<string, Record<string, string | string[]>>();
    const unitPrices = new Map<string, string>();
    const variantByProduct = new Map<string, (typeof variants)[number]>();
    for (const line of dto.items) {
      if (selections.has(line.productId)) throw new BadRequestException('Envía cada producto una sola vez con sus opciones y cantidad');
      const product = byId.get(line.productId)!;
      const requested = line.options ?? {};
      const groups = product.storeOptions ?? [];
      if (Object.keys(requested).some((key) => !groups.some((g) => g.name === key))) throw new BadRequestException(`Opciones no válidas para ${product.name}`);
      const normalized: Record<string, string | string[]> = {};
      let extra = D('0');
      for (const group of groups) {
        const raw = requested[group.name];
        if (raw === undefined || raw === '' || (Array.isArray(raw) && raw.length === 0)) {
          if (group.required) throw new BadRequestException(`Selecciona ${group.name} para ${product.name}`);
          continue;
        }
        if (group.type === 'select' || group.type === 'multi') {
          const picked = Array.isArray(raw) ? raw : [raw];
          if (group.type === 'select' && picked.length !== 1) throw new BadRequestException(`Elige una opción para ${group.name}`);
          if (group.type === 'multi' && !Array.isArray(raw)) throw new BadRequestException(`Selecciona una o más opciones para ${group.name}`);
          for (const choice of picked) {
            if (typeof choice !== 'string' || !group.choices?.some((candidate) => candidate.label === choice)) throw new BadRequestException(`Opción no válida en ${group.name}`);
            const selected = group.choices.find((candidate) => candidate.label === choice)!;
            if (selected.priceDelta) extra = extra.plus(D(selected.priceDelta));
          }
          normalized[group.name] = group.type === 'multi' ? picked as string[] : picked[0] as string;
        } else {
          if (Array.isArray(raw) || typeof raw !== 'string' || raw.length > 120) throw new BadRequestException(`Valor inválido en ${group.name}`);
          if (group.type === 'date' && !/^\d{4}-\d{2}-\d{2}$/.test(raw)) throw new BadRequestException(`Fecha inválida en ${group.name}`);
          if (group.type === 'time' && !/^\d{2}:\d{2}$/.test(raw)) throw new BadRequestException(`Hora inválida en ${group.name}`);
          normalized[group.name] = raw.trim();
        }
      }
      const productVariantsList = variantsByProduct.get(product.id) ?? [];
      if (productVariantsList.length) {
        const variant = productVariantsList.find((v) => v.id === line.variantId);
        if (!variant) throw new BadRequestException(`Selecciona una combinación disponible de ${product.name}`);
        const variantGroups = groups.filter((g) => g.type === 'select');
        if (variantGroups.some((g) => variant.options[g.name] !== normalized[g.name])) throw new BadRequestException(`La combinación seleccionada ya no coincide con ${product.name}`);
        if (variant.stock < line.quantity) throw new BadRequestException(`No quedan suficientes unidades de esa combinación de ${product.name}`);
        variantByProduct.set(product.id, variant);
      } else if (line.variantId) throw new BadRequestException('Esta combinación de producto ya no está disponible');
      if (product.appointmentSchedule) {
        const dateGroup = groups.find((g) => g.type === 'date');
        const timeGroup = groups.find((g) => g.type === 'time');
        if (!dateGroup || !timeGroup) throw new BadRequestException(`La agenda de ${product.name} necesita campos de fecha y hora`);
        const date = String(normalized[dateGroup.name] ?? ''); const time = String(normalized[timeGroup.name] ?? '');
        const scheduledDay = new Date(`${date}T12:00:00`).getDay();
        const start = Number(product.appointmentSchedule.startTime.slice(0, 2)) * 60 + Number(product.appointmentSchedule.startTime.slice(3));
        const end = Number(product.appointmentSchedule.endTime.slice(0, 2)) * 60 + Number(product.appointmentSchedule.endTime.slice(3));
        const selectedMinute = Number(time.slice(0, 2)) * 60 + Number(time.slice(3));
        const now = new Date();
        if (!date || Number.isNaN(scheduledDay) || new Date(`${date}T23:59:59`).getTime() < now.getTime()) throw new BadRequestException('Elige una fecha futura para la cita');
        if (!product.appointmentSchedule.weekdays.includes(scheduledDay) || selectedMinute < start || selectedMinute + product.appointmentSchedule.durationMinutes > end || (selectedMinute - start) % product.appointmentSchedule.intervalMinutes !== 0) {
          throw new BadRequestException('Ese horario no está dentro de la agenda del servicio');
        }
      }
      selections.set(line.productId, normalized);
      unitPrices.set(line.productId, m2(D(product.salePrice).plus(extra)));
    }
    const subtotal = catalog.reduce((sum, p) => sum.plus(D(unitPrices.get(p.id) ?? p.salePrice).mul(quantities.get(p.id)!)), D('0'));
    const configuredShippingFee = Math.max(0, Number(settings.shippingFee ?? 0) || 0);
    const freeMinimum = Math.max(0, Number(settings.freeShippingMinimum ?? 0) || 0);
    const shippingFee = freeMinimum > 0 && subtotal.gte(freeMinimum) ? 0 : configuredShippingFee;
    const total = m2(subtotal.plus(shippingFee));
    const paymentDue = m2(catalog.reduce((sum, p) => {
      const percent = p.depositPercent > 0 ? p.depositPercent : 100;
      return sum.plus(D(unitPrices.get(p.id) ?? p.salePrice).mul(quantities.get(p.id)!).mul(percent).div(100));
    }, D('0')).plus(shippingFee));
    const order = await this.db.transaction(async (tx) => {
      for (const product of catalog.filter((p) => p.appointmentSchedule)) {
        await tx.select({ id: products.id }).from(products).where(eq(products.id, product.id)).for('update');
        const groups = product.storeOptions ?? [];
        const dateGroup = groups.find((g) => g.type === 'date')!; const timeGroup = groups.find((g) => g.type === 'time')!;
        const date = String(selections.get(product.id)?.[dateGroup.name] ?? ''); const time = String(selections.get(product.id)?.[timeGroup.name] ?? '');
        const booked = await tx.select({ selectedOptions: storeOrderItems.selectedOptions }).from(storeOrderItems)
          .innerJoin(storeOrders, eq(storeOrders.id, storeOrderItems.orderId))
          .where(and(eq(storeOrders.businessId, store.id), eq(storeOrderItems.productId, product.id), inArray(storeOrders.status, ['RECEIVED', 'CONFIRMED']),
            sql`${storeOrderItems.selectedOptions}->>${dateGroup.name} = ${date}`));
        const requestedMinute = Number(time.slice(0, 2)) * 60 + Number(time.slice(3));
        const overlap = booked.some((b) => {
          const used = String((b.selectedOptions as any)?.[timeGroup.name] ?? '');
          if (!used) return false;
          const usedMinute = Number(used.slice(0, 2)) * 60 + Number(used.slice(3));
          return requestedMinute < usedMinute + product.appointmentSchedule!.durationMinutes && usedMinute < requestedMinute + product.appointmentSchedule!.durationMinutes;
        });
        if (overlap) throw new ConflictException('Ese horario acaba de ser reservado. Elige otro espacio disponible.');
      }
      const normalizedPhone = dto.customerPhone.replace(/\D/g, '');
      let [customer] = await tx.select().from(customers).where(and(eq(customers.businessId, store.id), sql`regexp_replace(${customers.phone}, '[^0-9]', '', 'g') = ${normalizedPhone}`)).limit(1).for('update');
      if (!customer) [customer] = await tx.insert(customers).values({ businessId: store.id, name: dto.customerName.trim(), phone: dto.customerPhone.trim(), city: dto.city.trim(), channel: 'WEBSITE' }).returning();
      const [created] = await tx.insert(storeOrders).values({
        businessId: store.id, customerId: customer.id, customerName: dto.customerName.trim(), customerPhone: dto.customerPhone.trim(),
        address: dto.address.trim(), city: dto.city.trim(), paymentMethod: dto.paymentMethod,
        attributionSource: dto.attributionSource?.trim() || null, attributionMedium: dto.attributionMedium?.trim() || null,
        attributionCampaign: dto.attributionCampaign?.trim() || null, attributionContent: dto.attributionContent?.trim() || null,
        dataUseAcceptedAt: new Date(), total: m2(total), paymentDue: m2(paymentDue),
        shippingFee: m2(shippingFee),
        paymentProvider: dto.paymentMethod === WOMPI_METHOD ? 'WOMPI' : null,
      }).returning();
      for (const [productId, quantity] of quantities) {
        const product = byId.get(productId)!;
        const variant = variantByProduct.get(productId);
        if (variant) {
          const [lockedVariant] = await tx.select().from(productVariants).where(and(eq(productVariants.id, variant.id), eq(productVariants.businessId, store.id))).for('update');
          if (!lockedVariant || lockedVariant.stock < quantity) throw new BadRequestException(`La combinación de ${product.name} acaba de agotarse`);
          const remaining = await this.inventory.move(tx, { businessId: store.id, productId, delta: -quantity, type: 'ORDER_RESERVE',
            referenceType: 'STORE_ORDER', referenceId: created.id, unitCost: null, note: `Reserva por pedido ${created.id.slice(0, 8)}` });
          await this.inventory.checkLowStock(tx, store.id, productId, remaining, -quantity);
          await tx.update(productVariants).set({ stock: lockedVariant.stock - quantity }).where(eq(productVariants.id, lockedVariant.id));
        }
        await tx.insert(storeOrderItems).values({ orderId: created.id, productId, productName: product.name, quantity,
          unitPrice: unitPrices.get(productId) ?? product.salePrice, selectedOptions: selections.get(productId) ?? {},
          preparationMinutes: product.preparationMinutes, depositPercent: product.depositPercent, variantId: variant?.id ?? null });
      }
      await this.notifications.notify(store.id, 'NEW_STORE_ORDER', 'Nuevo pedido de la tienda',
        `${dto.customerName} · ${m2(total)} COP`, { orderId: created.id }, tx);
      return created;
    });
    let checkout: Record<string, string> | undefined;
    if (dto.paymentMethod === WOMPI_METHOD) {
      const publicKey = store.wompiPublicKey!;
      const apiUrl = wompiApi(publicKey);
      const reference = `DREAM-${order.id}`;
      const amountInCents = D(order.paymentDue).mul(100).toDecimalPlaces(0).toString();
      const integritySecret = this.crypto.decrypt(store.wompiIntegritySecretEnc!);
      const merchantResponse = await fetch(`${apiUrl}/merchants/${encodeURIComponent(publicKey)}`);
      if (!merchantResponse.ok) throw new BadRequestException('No fue posible iniciar el pago. Intenta de nuevo o elige otro medio.');
      const merchant = await merchantResponse.json() as any;
      const acceptanceToken = merchant?.data?.presigned_acceptance?.acceptance_token;
      if (!acceptanceToken) throw new BadRequestException('La pasarela no entregó el token de aceptación requerido.');
      checkout = { url: 'https://checkout.wompi.co/p/', publicKey, reference,
        amountInCents, currency: WOMPI_CURRENCY, acceptanceToken,
        signature: sha256(`${reference}${amountInCents}${WOMPI_CURRENCY}${integritySecret}`),
        redirectUrl: `${config.webOrigin.split(',')[0]}/tienda/${encodeURIComponent(slug)}?pedido=${order.id.slice(0, 8)}` };
    }
    return { id: order.id, shortId: order.id.slice(0, 8), status: order.status, paymentStatus: order.paymentStatus,
      total: order.total, shippingFee: order.shippingFee, paymentDue: order.paymentDue, createdAt: order.createdAt, checkout,
      items: [...quantities].map(([productId, quantity]) => ({ productName: byId.get(productId)!.name, quantity,
        unitPrice: unitPrices.get(productId) ?? byId.get(productId)!.salePrice, options: selections.get(productId) ?? {} })) };
  }

  async handleWompiEvent(payload: any) {
    if (!payload?.signature?.checksum || !Array.isArray(payload.signature.properties) || !payload.timestamp) {
      throw new BadRequestException('Evento de pago inválido');
    }
    const transaction = payload.data?.transaction;
    if (!transaction?.reference?.startsWith('DREAM-') || !transaction?.id) throw new BadRequestException('Referencia de pedido inválida');
    const orderId = transaction.reference.slice('DREAM-'.length);
    const [order] = await this.db.select().from(storeOrders).where(eq(storeOrders.id, orderId)).limit(1);
    if (!order || order.paymentProvider !== 'WOMPI') throw new BadRequestException('Pedido de pago no encontrado');
    const [store] = await this.db.select().from(businesses).where(eq(businesses.id, order.businessId)).limit(1);
    if (!store?.wompiEventSecretEnc || !store.wompiPrivateKeyEnc || !store.wompiPublicKey) throw new BadRequestException('La tienda no tiene la pasarela configurada');
    const eventSecret = this.crypto.decrypt(store.wompiEventSecretEnc);
    const valueAt = (obj: any, path: string) => path.split('.').reduce((value, key) => value?.[key], obj);
    const signed = payload.signature.properties.map((path: string) => valueAt(payload.data, path));
    if (signed.some((value: unknown) => value === undefined || value === null)) throw new BadRequestException('Firma incompleta');
    const expected = sha256(`${signed.join('')}${payload.timestamp}${eventSecret}`).toLowerCase();
    const received = String(payload.signature.checksum).toLowerCase();
    if (!/^[a-f0-9]{64}$/.test(received) || !timingSafeEqual(Buffer.from(expected), Buffer.from(received))) throw new BadRequestException('Firma de evento inválida');
    if (payload.event !== 'transaction.updated') return { received: true };
    const response = await fetch(`${wompiApi(store.wompiPublicKey)}/transactions/${encodeURIComponent(transaction.id)}`, {
      headers: { Authorization: `Bearer ${this.crypto.decrypt(store.wompiPrivateKeyEnc)}` },
    });
    if (!response.ok) throw new BadRequestException('No se pudo verificar el pago con la pasarela');
    const verified = (await response.json() as any)?.data;
    if (verified?.id !== transaction.id || verified?.reference !== transaction.reference) throw new BadRequestException('La transacción no coincide con el pedido');
    if (verified.amount_in_cents !== Number(D(order.paymentDue).mul(100).toDecimalPlaces(0).toString()) || verified.currency !== WOMPI_CURRENCY) {
      throw new BadRequestException('El valor del pago no coincide con el pedido');
    }
    const paymentStatus = verified.status === 'APPROVED' ? 'PAID' : ['DECLINED', 'VOIDED', 'ERROR'].includes(verified.status) ? 'FAILED' : 'PENDING';
    await this.db.transaction(async (tx) => {
      const [locked] = await tx.select().from(storeOrders).where(eq(storeOrders.id, order.id)).for('update');
      if (!locked) return;
      await tx.update(storeOrders).set({ paymentStatus, paymentTransactionId: verified.id, paidAt: paymentStatus === 'PAID' ? new Date() : null })
        .where(and(eq(storeOrders.id, order.id), eq(storeOrders.paymentProvider, 'WOMPI')));
      if (paymentStatus === 'PAID' && locked.customerId && !locked.customerPurchaseCountedAt) {
        await tx.update(customers).set({ purchaseCount: sql`${customers.purchaseCount} + 1`, totalSpent: sql`${customers.totalSpent} + ${locked.total}`,
          firstPurchaseAt: sql`coalesce(${customers.firstPurchaseAt}, now())`, lastPurchaseAt: new Date() }).where(eq(customers.id, locked.customerId));
        await tx.update(storeOrders).set({ customerPurchaseCountedAt: new Date() }).where(eq(storeOrders.id, order.id));
      }
    });
    return { received: true };
  }

  async listOrders(businessId: string) {
    const orders = await this.db.select().from(storeOrders).where(eq(storeOrders.businessId, businessId))
      .orderBy(desc(storeOrders.createdAt)).limit(200);
    if (!orders.length) return [];
    const items = await this.db.select().from(storeOrderItems).where(inArray(storeOrderItems.orderId, orders.map((o) => o.id)));
    const byOrder = new Map<string, typeof items>();
    for (const item of items) byOrder.set(item.orderId, [...(byOrder.get(item.orderId) ?? []), item]);
    return orders.map((o) => ({ ...o, items: byOrder.get(o.id) ?? [] }));
  }

  async updateOrderShipping(businessId: string, id: string, dto: StoreOrderShippingDto) {
    const [order] = await this.db.select().from(storeOrders).where(and(eq(storeOrders.id, id), eq(storeOrders.businessId, businessId))).limit(1);
    if (!order) throw new NotFoundException('Pedido no encontrado');
    if (!['CONFIRMED', 'SHIPPED', 'DELIVERED'].includes(order.status)) throw new BadRequestException('Confirma el pedido antes de gestionar su envío');
    const [updated] = await this.db.update(storeOrders).set({ shippingCarrier: dto.carrier, pickupDate: dto.pickupDate,
      pickupWindow: dto.pickupWindow.trim(), pickupConfirmation: dto.pickupConfirmation?.trim() || null,
      trackingNumber: dto.trackingNumber?.trim() || null, trackingUrl: dto.trackingUrl?.trim() || null }).where(eq(storeOrders.id, id)).returning();
    return updated;
  }

  async updateOrder(businessId: string, userId: string, id: string, next: StoreOrderStatusDto['status']) {
    return this.db.transaction(async (tx) => {
      const [order] = await tx.select().from(storeOrders).where(and(eq(storeOrders.id, id), eq(storeOrders.businessId, businessId))).for('update');
      if (!order) throw new NotFoundException('Pedido no encontrado');
      const items = await tx.select().from(storeOrderItems).where(eq(storeOrderItems.orderId, id));
      const valid = order.status === 'RECEIVED' ? ['CONFIRMED', 'CANCELLED']
        : order.status === 'CONFIRMED' ? ['SHIPPED', 'CANCELLED']
          : order.status === 'SHIPPED' ? ['DELIVERED'] : [];
      if (!valid.includes(next)) throw new BadRequestException(`No se puede pasar un pedido de ${order.status} a ${next}`);
      if (next === 'CANCELLED' && order.paymentStatus === 'PAID') throw new BadRequestException('Este pedido ya está pagado. Gestiona primero la devolución en Wompi.');
      if (next === 'CONFIRMED') {
        for (const item of items) {
          if (item.variantId) continue; // El inventario de variantes quedó reservado al crear el pedido.
          const quantity = await this.inventory.move(tx, { businessId, productId: item.productId, delta: -item.quantity,
            type: 'ORDER_RESERVE', unitCost: null, referenceType: 'STORE_ORDER', referenceId: id, userId,
            note: `Reserva por pedido ${id.slice(0, 8)}` });
          await this.inventory.checkLowStock(tx, businessId, item.productId, quantity, -item.quantity);
        }
      }
      if (next === 'CANCELLED') {
        for (const item of items) {
          if (item.variantId) {
            const [variant] = await tx.select().from(productVariants).where(and(eq(productVariants.id, item.variantId), eq(productVariants.businessId, businessId))).for('update');
            if (variant) await tx.update(productVariants).set({ stock: variant.stock + item.quantity }).where(eq(productVariants.id, variant.id));
            await this.inventory.move(tx, { businessId, productId: item.productId, delta: item.quantity, type: 'ORDER_RELEASE',
              referenceType: 'STORE_ORDER', referenceId: id, userId, note: `Liberación de variante por cancelación de pedido ${id.slice(0, 8)}` });
          } else if (order.status === 'CONFIRMED') {
            await this.inventory.move(tx, { businessId, productId: item.productId, delta: item.quantity, type: 'ORDER_RELEASE',
              referenceType: 'STORE_ORDER', referenceId: id, userId, note: `Liberación por cancelación de pedido ${id.slice(0, 8)}` });
          }
        }
      }
      const dates = next === 'CONFIRMED' ? { confirmedAt: new Date() }
        : next === 'SHIPPED' ? { shippedAt: new Date() }
          : next === 'DELIVERED' ? { deliveredAt: new Date() }
            : { cancelledAt: new Date() };
      const [updated] = await tx.update(storeOrders).set({ status: next, ...dates }).where(eq(storeOrders.id, id)).returning();
      if (next === 'CONFIRMED' && order.customerId && !order.customerPurchaseCountedAt) {
        await tx.update(customers).set({ purchaseCount: sql`${customers.purchaseCount} + 1`, totalSpent: sql`${customers.totalSpent} + ${order.total}`,
          firstPurchaseAt: sql`coalesce(${customers.firstPurchaseAt}, now())`, lastPurchaseAt: new Date() }).where(eq(customers.id, order.customerId));
        await tx.update(storeOrders).set({ customerPurchaseCountedAt: new Date() }).where(eq(storeOrders.id, id));
      }
      return { ...updated, items };
    });
  }
}

@Controller('store')
class StoreController {
  constructor(private service: StoreService) {}
  @RequirePermissions('business:manage') @Get('current') settings(@Ctx() ctx: RequestContext) { return this.service.settings(ctx.businessId); }
  @RequirePermissions('business:manage') @Patch('current') save(@Ctx() ctx: RequestContext, @Body() dto: StoreConfigDto) { return this.service.save(ctx.businessId, dto); }
  @RequirePermissions('business:manage') @Patch('current/wompi') saveWompi(@Ctx() ctx: RequestContext, @Body() dto: WompiConfigDto) { return this.service.saveWompi(ctx.businessId, dto); }
  @RequirePermissions('sales:read') @Get('orders') orders(@Ctx() ctx: RequestContext) { return this.service.listOrders(ctx.businessId); }
  @RequirePermissions('sales:create') @Patch('orders/:id/shipping') shipping(@Ctx() ctx: RequestContext, @Param('id', ParseUUIDPipe) id: string, @Body() dto: StoreOrderShippingDto) {
    return this.service.updateOrderShipping(ctx.businessId, id, dto);
  }
  @RequirePermissions('sales:create') @Patch('orders/:id/status') updateOrder(@Ctx() ctx: RequestContext, @Param('id', ParseUUIDPipe) id: string, @Body() dto: StoreOrderStatusDto) {
    return this.service.updateOrder(ctx.businessId, ctx.userId, id, dto.status);
  }
  @Public() @Post(':slug/orders') createOrder(@Param('slug') slug: string, @Body() dto: CreateStoreOrderDto) { return this.service.createOrder(slug, dto); }
  @Public() @Post('wompi/webhook') wompiWebhook(@Body() body: any) { return this.service.handleWompiEvent(body); }
  @Public() @Get(':slug/:productId/slots') slots(@Param('slug') slug: string, @Param('productId', ParseUUIDPipe) productId: string, @Query('date') date: string) {
    return this.service.availability(slug, productId, date);
  }
  @Public() @Get(':slug') publicStore(@Param('slug') slug: string) { return this.service.publicStore(slug); }
}

@Module({ imports: [InventoryModule], controllers: [StoreController], providers: [StoreService] })
export class StoreModule {}
