import type { Metadata, Viewport } from 'next';
import './globals.css';
import { Providers } from './providers';

export const metadata: Metadata = {
  title: { default: 'DREAMS — Tu negocio en un solo lugar', template: '%s · DREAMS' },
  description: 'Ventas, inventario, clientes, finanzas, bancos y redes sociales para pequeños negocios.',
  icons: { apple: '/icons/apple-touch-icon.png' },
  appleWebApp: { capable: true, title: 'DREAMS', statusBarStyle: 'default' },
  manifest: '/manifest.webmanifest', // Vincula el manifest
};

export const viewport: Viewport = { themeColor: '#111111', width: 'device-width', initialScale: 1 };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es">
      <head>
        {/* Registro del Service Worker (generado por @ducanmade/next-pwa) */}
        <link rel="manifest" href="/manifest.webmanifest" />
        <meta name="theme-color" content="#111111" />
      </head>
      <body className="font-sans min-h-screen">
        <Providers>{children}</Providers>
        {/* Script para registrar el Service Worker y manejar actualizaciones */}
        <RegisterSW />
      </body>
    </html>
  );
}

// Componente cliente que registra el SW
function RegisterSW() {
  return (
    <script
      dangerouslySetInnerHTML={{
        __html: `
          if ('serviceWorker' in navigator) {
            window.addEventListener('load', () => {
              navigator.serviceWorker.register('/sw.js').then(reg => {
                // Forzar registro del nuevo SW si hay uno pendiente
                reg.onupdatefound = () => {
                  const worker = reg.installing;
                  worker?.addEventListener('statechange', () => {
                    if (worker.state === 'installed' && navigator.serviceWorker.controller) {
                      // Hay una nueva versión disponible, recargar silenciosamente o notificar al usuario
                      console.log('[DREAMS-PWA] Nueva versión disponible, recargando...');
                      window.location.reload();
                    }
                  });
                };
              });
            });
          }
        `,
      }}
    />
  );
}
