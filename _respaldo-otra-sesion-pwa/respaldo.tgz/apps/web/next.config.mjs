import { join } from 'path';
import { fileURLToPath } from 'url';
import { version } from './package.json';

// next-pwa
import PWA from '@ducanmade/next-pwa';
// or: import PWA from 'next-pwa';

const __filename = fileURLToPath(import.meta.url);
const __dirname = join(fileURLToPath(import.meta.url), '..');

const API = process.env.API_INTERNAL_URL ?? 'http://localhost:4000';

const securityHeaders = [
  { key: 'X-Content-Type-Options', value: 'nosniff' },
  { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
  { key: 'Permissions-Policy', value: 'camera=(), microphone=(), geolocation=()' },
];

// Configuración para desarrollo y producción
const withPWA = PWA({
  dest: 'public',
  disable: process.env.NODE_ENV === 'development', // Habilita PWA solo en prod
  register: true, // Registra automáticamente el service worker
  runtimeCaching: [
    // Cache estáticos: CSS, JS, imágenes
    {
      matcher: ({ request }): boolean => request.destination === 'script' || request.destination === 'style' || request.destination === 'image' || request.destination === 'font' || request.destination === 'manifest',
      method: 'GET',
      responder: async ({ request, cacheName, response }) => {
        // Intenta responder con la caché primero, luego cae al network (CacheFirst)
        const cached = await caches.match(request);
        if (cached) return cached;
        const networkResp = await fetch(request);
        if (response) await caches.open(cacheName).then((cache) => cache.put(request, networkResp.clone()));
        return networkResp;
      },
    },
    // API Routes (Next.js API)
    {
      matcher: '/api/:path*',
      method: 'GET',
      responder: async ({ request, response, cacheName }) => {
        // NetworkFirst para datos frescos
        try {
          const networkResp = await fetch(request);
          await caches.open(cacheName).then((cache) => cache.put(request, networkResp.clone()));
          return networkResp;
        } catch (error) {
          const cachedResp = await caches.match(request);
          if (cachedResp) return cachedResp;
          return new Response('{"error": "No se pudo completar la solicitud. Inténtalo más tarde."}', { status: 503, headers: { 'Content-Type': 'application/json' } });
        }
      },
    },
    // Páginas (SPA fallback)
    {
      matcher: '/:path*',
      method: 'GET',
      responder: async ({ request, response, cacheName }) => {
        // StaleWhileRevalidate para páginas: sirve desde caché, actualiza en segundo plano
        const cachedResp = await caches.match(request);
        const networkResp = fetch(request).then((res) => {
          if (res.ok || res.type === 'opaqueredirect') caches.open(cacheName).then((cache) => cache.put(request, res.clone()));
          return res;
        });
        // Si hay conexión, sirve el nuevo; si no, sirve el cache
        return cachedResp || networkResp;
      },
    },
  ],
});

/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'standalone',
  reactStrictMode: true,
  poweredByHeader: false,
  // El navegador habla solo con el frontend (mismo origen); Next reenvía /api y /uploads al backend.
  async rewrites() {
    return [
      { source: '/api/:path*', destination: `${API}/api/:path*` },
      { source: '/uploads/:path*', destination: `${API}/uploads/:path*` },
    ];
  },
  async headers() {
    return [
      // Ninguna página puede mostrarse dentro de otro sitio, salvo la vista previa del editor de la página web (mismo origen).
      { source: '/((?!tienda/__vista-previa).*)', headers: [...securityHeaders, { key: 'X-Frame-Options', value: 'DENY' }] },
      { source: '/tienda/__vista-previa', headers: [...securityHeaders, { key: 'X-Frame-Options', value: 'SAMEORIGIN' }] },
    ];
  },
};

// Exporta la configuración envuelta con la PWA
export default withPWA(nextConfig);
