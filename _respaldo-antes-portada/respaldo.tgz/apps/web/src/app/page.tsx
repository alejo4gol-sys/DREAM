import Link from 'next/link';
import { ArrowRight, BarChart3, Boxes, Landmark, MessageCircle, ShieldCheck, Sparkles, Store, Truck, Users } from 'lucide-react';
import { Logo } from '@/components/ui';

const features = [
  { icon: BarChart3, title: 'Ventas y dashboard', text: 'Registra cada venta en segundos y mira cómo va tu negocio hoy, esta semana y este mes.' },
  { icon: Boxes, title: 'Inventario al día', text: 'El stock se descuenta solo al vender y te avisamos antes de que un producto se agote.' },
  { icon: Users, title: 'Clientes que vuelven', text: 'Historial de compras, canal de llegada y segmentos: nuevos, frecuentes, inactivos y de alto valor.' },
  { icon: Landmark, title: 'Finanzas y bancos', text: 'Gastos, utilidad, flujo de caja y conciliación de tus movimientos bancarios con tus ventas.' },
  { icon: MessageCircle, title: 'Centro de redes', text: 'Mide qué canal te vende más: Instagram, WhatsApp, Facebook, TikTok, tienda física o web.' },
  { icon: Store, title: 'Tu tienda, tu marca', text: 'Diseña una tienda web a tu estilo, muestra tus productos y recibe pedidos en línea.' },
  { icon: Truck, title: 'Pedidos y entregas', text: 'Sigue cada pedido desde la confirmación hasta la entrega y ten la información a mano.' },
  { icon: Sparkles, title: 'Crea publicidad', text: 'Diseña imágenes, prepara videos y llévalos a las plataformas de anuncios.' },
  { icon: Sparkles, title: 'Asistente de negocio', text: 'Pregunta “¿cuánto vendí este mes?” y obtén la respuesta calculada con tus propios datos.' },
];

const plans = [
  { name: 'Gratuito', price: '$0', items: ['1 usuario', '100 productos', '200 ventas al mes', 'Reportes CSV'] },
  { name: 'Básico', price: '$39.900', items: ['3 usuarios', '1.000 productos', '2.000 ventas al mes', 'Reportes Excel'] },
  { name: 'Profesional', price: '$99.900', items: ['10 usuarios', '10.000 productos', 'Ventas ilimitadas', 'Reportes PDF'], featured: true },
  { name: 'Empresarial', price: '$299.900', items: ['Usuarios ilimitados', 'Sucursales y bodegas', 'API e integraciones', 'Soporte prioritario'] },
];

export default function Landing() {
  return (
    <div className="min-h-screen bg-sand-50">
      <header className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
        <Logo />
        <nav className="flex items-center gap-2">
          <Link href="/ingresar" className="btn-ghost">Ingresar</Link>
          <Link href="/registro" className="btn-primary">Crear cuenta</Link>
        </nav>
      </header>

      <section className="max-w-6xl mx-auto px-4 sm:px-6 pt-14 sm:pt-20 pb-16 grid lg:grid-cols-[1.05fr_.95fr] gap-10 lg:gap-12 items-center">
        <div>
          <span className="chip bg-sand-200 text-sand-600">Hecho para pequeños y medianos negocios</span>
          <h1 className="font-display text-5xl sm:text-6xl leading-[1.02] font-semibold mt-5 text-ink">
            Crece con orden.<br />Vende con confianza.
          </h1>
          <p className="mt-5 text-lg text-ink-muted max-w-xl">
            DREAMS reúne ventas, inventario, clientes, finanzas y tienda en línea para que tengas más claridad sobre tu negocio y más tiempo para atender a tus clientes.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link href="/registro" className="btn-primary h-12 px-6 text-[15px]">Empieza gratis <ArrowRight className="h-4 w-4" /></Link>
            <a href="#proposito" className="btn-secondary h-12 px-6 text-[15px]">Conoce DREAMS</a>
          </div>
          <p className="mt-4 text-xs text-ink-faint">Herramientas prácticas para organizar tu negocio, a tu propio ritmo.</p>
        </div>
        <div className="relative">
          <div className="absolute -inset-4 bg-sand-200 rounded-[32px] rotate-2" aria-hidden />
          <div className="relative overflow-hidden rounded-[28px] bg-ink shadow-pop aspect-[4/3]">
            <video
              className="absolute inset-0 h-full w-full object-cover"
              autoPlay muted loop playsInline controls preload="metadata"
              poster="/dream-small-business-poster.jpg"
              aria-label="Dos emprendedoras organizan su pequeña tienda en línea"
            >
              <source src="/dream-small-business.mp4" type="video/mp4" />
            </video>
            <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/65 via-transparent to-black/10" aria-hidden />
            <div className="pointer-events-none absolute bottom-12 left-5 right-5 text-white sm:bottom-14 sm:left-7">
              <p className="text-xs uppercase tracking-[0.18em] text-white/75">Cada negocio tiene una historia</p>
              <p className="font-display text-2xl sm:text-3xl font-semibold mt-1">DREAMS te ayuda a hacerla crecer.</p>
            </div>
          </div>
          <p className="mt-3 text-right text-[10px] text-ink-faint">Video: <a className="underline underline-offset-2 hover:text-ink" href="https://www.pexels.com/video/business-partners-starting-an-online-store-7856115/" target="_blank" rel="noreferrer">Kampus Production · Pexels</a></p>
        </div>
      </section>

      <section id="proposito" className="bg-ink text-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-14 sm:py-20 grid lg:grid-cols-[.8fr_1.2fr] gap-8 lg:gap-16 items-start">
          <div>
            <span className="text-xs uppercase tracking-[0.2em] text-sand-300">Nuestro propósito</span>
            <h2 className="font-display text-3xl sm:text-4xl font-semibold mt-3">Que puedas dedicar más tiempo a lo que sabes hacer.</h2>
          </div>
          <div>
            <p className="text-base sm:text-lg text-white/80 leading-relaxed">
              DREAMS es una plataforma para pequeños y medianos comerciantes que quieren organizar su operación y vender en más lugares sin perder el control. Reúne herramientas para registrar ventas, encontrar productos, conocer a sus clientes y recibir pedidos desde su tienda web.
            </p>
            <p className="text-sm text-white/65 leading-relaxed mt-4">
              Nuestro propósito es acompañar a cada negocio con tecnología práctica y fácil de usar: ayudarle a entender cómo va, atender mejor a sus compradores y tomar decisiones con información clara, a su propio ritmo.
            </p>
            <div className="mt-7 grid sm:grid-cols-3 gap-3">
              {[
                ['Más claridad', 'Revisa ventas, productos y gastos desde un solo lugar.'],
                ['Menos tareas repetidas', 'Mantén pedidos, clientes e inventario mejor organizados.'],
                ['Crecimiento a tu ritmo', 'Empieza con lo que necesitas y suma herramientas cuando estés listo.'],
              ].map(([title, text]) => (
                <div key={title} className="rounded-2xl border border-white/15 bg-white/5 p-4">
                  <p className="text-sm font-semibold text-sand-300">{title}</p>
                  <p className="text-xs leading-relaxed text-white/65 mt-2">{text}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="bg-white border-y border-line">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-16">
          <h2 className="font-display text-4xl font-semibold">Lo que necesitas, nada que te sobre.</h2>
          <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {features.map((f) => (
              <div key={f.title} className="rounded-2xl border border-line p-6 bg-sand-50/50">
                <f.icon className="h-5 w-5 text-sand-600" />
                <h3 className="font-semibold mt-4">{f.title}</h3>
                <p className="text-sm text-ink-muted mt-1.5 leading-relaxed">{f.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-4 sm:px-6 py-16">
        <h2 className="font-display text-4xl font-semibold">Planes que crecen contigo</h2>
        <p className="text-ink-muted mt-2">Precios mensuales de referencia en pesos colombianos.</p>
        <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {plans.map((p) => (
            <div key={p.name} className={`rounded-2xl p-6 border ${p.featured ? 'bg-ink text-white border-ink' : 'bg-white border-line'}`}>
              <p className={`text-sm font-medium ${p.featured ? 'text-sand-300' : 'text-ink-muted'}`}>{p.name}</p>
              <p className="text-3xl font-semibold mt-2">{p.price}<span className="text-sm font-normal opacity-60"> /mes</span></p>
              <ul className="mt-5 space-y-2 text-sm">
                {p.items.map((i) => <li key={i} className="flex gap-2"><span className={p.featured ? 'text-sand-300' : 'text-sand-500'}>—</span>{i}</li>)}
              </ul>
            </div>
          ))}
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-4 sm:px-6 pb-20">
        <div className="rounded-3xl bg-sand-200 p-8 sm:p-12 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          <div className="flex gap-4 items-start">
            <ShieldCheck className="h-6 w-6 text-sand-600 shrink-0 mt-1" />
            <div>
              <p className="font-semibold">Seguridad desde el primer día</p>
              <p className="text-sm text-ink-soft mt-1 max-w-xl">Contraseñas cifradas, verificación en dos pasos, permisos por rol y registro de actividad. Nunca te pediremos la contraseña de tu banco.</p>
            </div>
          </div>
          <Link href="/registro" className="btn-primary h-12 px-6">Crear mi cuenta</Link>
        </div>
      </section>

      <footer className="border-t border-line">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8 flex flex-col sm:flex-row justify-between gap-4 text-xs text-ink-muted">
          <Logo />
          <p>La contabilidad de DREAMS es gerencial y no reemplaza la asesoría de un contador público.</p>
        </div>
      </footer>
    </div>
  );
}
