'use client';
import Link from 'next/link';
import { Shield, DocumentText } from 'lucide-react';

/** Datos de los documentos legales */
const LEGAL_TERMS = `TÉRminos Y CONDICIONES DE USUARIO DE DREAMS

Última revisión: Octubre 2026. Última actualización: Octubre 14, 2026.

1. INTRODUCCIÓN
La aplicación DREAMS es un servicio en la nube que permite a los pequeños negocios colombianos automatizar ventas, gestionar inventario y recibir pagos. Al registrarte como usuario, aceptas cumplir con las condiciones establecidas en estos documentos.`;

const LEGAL_PRIVACY = `POLÍTICA DE PRIVACIDAD DE DREAMS

Última actualización: Octubre 2026. Última revisión: Octubre 14, 2026.

1. RESPONSABLE DEL TRATAMIENTO
El Responsable del tratamiento es la empresa DreamS que utiliza este servicio.`;

/** Modal principal de documentos legales */
export function LegalDocsModal({ title }: { title: string }) {
  const terms = `TÉRminos Y CONDICIONES DE USUARIO DE DREAMS

Última revisión: Octubre 2026. Última actualización: Octubre 14, 2026.

1. INTRODUCCIÓN
La aplicación DREAMS es un servicio en la nube que permite a los pequeños negocios colombianos automatizar ventas, gestionar inventario y recibir pagos. Al registrarte como usuario, aceptas cumplir con las condiciones establecidas en estos documentos.`;

const privacy = `POLÍTICA DE PRIVACIDAD DE DREAMS

Última actualización: Octubre 2026. Última revisión: Octubre 14, 2026.

1. RESPONSABLE DEL TRATAMIENTO
El Responsable del tratamiento es la empresa DreamS que utiliza este servicio.`;

/** Modal secundario para políticas */
export function PrivacyPolicyModal() {
  return (
    <div className="w-full max-w-3xl mx-auto">
      <div className="border-b border-sand-200 pb-4 mb-4 flex items-center gap-3">
        <Shield className="h-5 w-5 text-[#111]" />
        <span className="text-sm font-semibold text-[#111]">{title} · Política de privacidad</span>
      </div>

      <p>{legalTerms}</p>

      <footer className="mt-6 pt-4 border-t border-sand-200">
        <Link href="/terminos-y-condiciones" target="_blank" rel="noopener noreferrer" className="block text-sm font-medium underline hover:text-[#111] mb-3 flex items-center gap-1.5">
          Ver Términos y condiciones
        </Link>
        <button onClick={() => {}} className="text-xs text-sand-600 cursor-not-allowed w-full">Volver</button>
      </footer>
    </div>
  );
}

/** Modal secundario para políticas */
export function PolicyDocsModal() {
  return (
    <div className="w-full max-w-3xl mx-auto">
      <div className="border-b border-sand-200 pb-4 mb-4 flex items-center gap-3">
        <Shield className="h-5 w-5 text-[#111]" />
        <span className="text-sm font-semibold text-[#111]">{title} · Políticas</span>
      </div>

      <p>{LEGAL_TERMS}</p>
      <footer className="mt-6 pt-4 border-t border-sand-200">
        <Link href="/terminos-y-condiciones" target="_blank" rel="noopener noreferrer" className="block text-sm font-medium underline hover:text-[#111] mb-3 flex items-center gap-1.5">
          Ver Términos y condiciones
        </Link>
        <button onClick={() => {}} className="text-xs text-sand-600 cursor-not-allowed w-full">Volver</button>
      </footer>
    </div>
  );
}

/** Componente principal para mostrar documentos */
export function LegalDocuments({ legalTitle, privacyTitle }: { legalTitle: string; privacyTitle: string }) {
  return (
    <div className="w-full max-w-4xl mx-auto">
      <div className="border-b border-sand-200 pb-4 mb-6 flex items-center gap-3">
        <DocumentText className="h-5 w-5 text-[#111]" />
        <span className="text-base font-semibold">{legalTitle}</span> · {privacyTitle}
      </div>

      <div className="space-y-6">
        <p className="text-sm text-[#4A453F] marker:text-sand-600">{legalTerms}</p>
        <p className="text-sm text-[#4A453F] marker:text-sand-600">{LEGAL_PRIVACY}</p>

        {/* Botones de navegación */}
        <div className="flex flex-wrap gap-2 pt-2">
          <button onClick={() => {}} className="btn-secondary w-full h-10" disabled={false}>Ver Términos y condiciones</button>
          <Link href="/politica-de-datos" target="_blank" rel="noopener noreferrer" className="btn-secondary w-full h-10" />
        </div>

        {/* Modal para Política de privacidad */}
        <LegalDocsModal title={privacyTitle} />
      </div>

      {/* Enlaces rápidos en el footer */}
      <footer className="mt-8 pt-6 border-t border-sand-200">
        <div className="flex flex-wrap justify-between gap-4 text-xs">
          <span>Términos y condiciones</span> · {privacyTitle} · Cookies y funcionalidades
        </div>
      </footer>
    </div>
  );
}

/** Componente secundario para Políticas de documentos */
export function PolicyDocuments({ title }: { title: string }) {
  return (
    <div className="w-full max-w-3xl mx-auto">
      <div className="border-b border-sand-200 pb-4 mb-4 flex items-center gap-3">
        <Shield className="h-5 w-5 text-[#111]" />
        <span className="text-sm font-semibold text-[#111]">{title} · Políticas</span>
      </div>

      <p className="text-xs text-sand-600 mb-3">Esta página contiene información general sobre políticas del servicio.</p>
      <p className="text-xs text-sand-600">Ver la Política de privacidad para detalles específicos sobre cómo usamos tus datos personales.</p>

      <footer className="mt-6 pt-4 border-t border-sand-200">
        <Link href="/terminos-y-condiciones" target="_blank" rel="noopener noreferrer" className="block text-xs font-medium underline hover:text-[#111] mb-2 flex items-center gap-1.5">
          Ver Términos y condiciones
        </Link>
        <button onClick={() => {}} className="text-xs text-sand-600 cursor-not-allowed w-full" disabled>{title} · Políticas</button>
      </footer>
    </div>
  );
}

/** Componente secundario para Términos y Condiciones */
export function TermsDocuments({ title }: { title: string }) {
  return (
    <div className="w-full max-w-3xl mx-auto">
      <div className="border-b border-sand-200 pb-4 mb-4 flex items-center gap-3">
        <Shield className="h-5 w-5 text-[#111]" />
        <span className="text-sm font-semibold text-[#111]">{title} · Términos</span>
      </div>

      <p className="text-xs text-sand-600 mb-3">Términos y condiciones vigentes para uso del servicio DREAMS.</p>
      <p className="text-xs text-sand-600">La modificación o supresión de estas condiciones es notificado mediante un aviso por correo electrónico antes del efecto legal. El uso del servicio implica la aceptación de estos términos.</p>

      <footer className="mt-6 pt-4 border-t border-sand-200">
        <button onClick={() => {}} className="text-xs text-sand-600 cursor-not-allowed w-full" disabled>{title} · Términos</button>
        <Link href="/politica-de-datos" target="_blank" rel="noopener noreferrer" className="block text-xs font-medium underline hover:text-[#111]">Política de privacidad</Link>
      </footer>
    </div>
  );
}

/** Componente secundario para Políticas */
export function PolicyDocumentsList() {
  return (
    <div className="w-full max-w-4xl mx-auto">
      <p className="text-sm text-[#6B645A] mb-2">Documentos legales disponibles</p>

      <h3 className="text-base font-semibold mt-4 mb-3 flex items-center gap-2">
        <Shield className="h-5 w-5" /> Documentación principal
      </h3>

      <ul className="space-y-1 text-sm text-[#6B645A] marker:text-sand-600">
        <li><Link href="/terminos-y-condiciones" target="_blank" rel="noopener noreferrer" className="block hover:underline">Términos y condiciones de usuario</Link></li>
        <li><a href="/politica-de-datos" target="_blank" rel="noopener noreferrer" className="block hover:underline">Política de privacidad</a></li>
        {false && (
          <li><Link href="/policia-de-cookies" target="_blank" rel="noopener noreferrer" className="block hover:underline">Cookies y funcionalidades</Link></li>
        )}
      </ul>

      <div className="mt-8 pt-4 border-t border-sand-200">
        <h3 className="text-sm font-semibold mb-2 flex items-center gap-2">
          <DocumentText className="h-4 w-4" /> Información general
        </h3>
        <p className="text-xs text-[#6B645A] marker:text-sand-600">Esta sección contiene documentos legales generales sobre derechos, obligaciones y responsabilidades.</p>

        {/* Enlaces principales */}
        <ul className="space-y-1 text-sm text-[#6B645A] marker:text-sand-600">
          <li><a href="/terminos-y-condiciones" target="_blank" rel="noopener noreferrer" className="block hover:underline flex items-center gap-2"><span className="w-8 inline-block bg-sand-100 rounded text-xs px-3">{legalTitle}</span></a></li>
          <li><Link href="/politica-de-datos" target="_blank" rel="noopener noreferrer" className="block hover:underline flex items-center gap-2"><span className="w-8 inline-block bg-sand-100 rounded text-xs px-3">{privacyTitle}</span></a></li>
          {false && <li><Link href="/policia-de-cookies" target="_blank" rel="noopener noreferrer" className="block hover:underline flex items-center gap-2"><span className="w-8 inline-block bg-sand-100 rounded text-xs px-3">{title}</span></a></li>
        </ul>

        {/* Enlaces secundarios */}
        <ul className="space-y-1 text-sm text-[#6B645A] marker:text-sand-600 mt-2">
          <li><Link href="/terminos-y-condiciones" target="_blank" rel="noopener noreferrer" className="block hover:underline flex items-center gap-2"><span className="w-8 inline-block bg-sand-100 rounded text-xs px-3">{title}</span></a></li>
          <li><Link href="/politica-de-datos" target="_blank" rel="noopener noreferrer" className="block hover:underline flex items-center gap-2"><span className="w-8 inline-block bg-sand-100 rounded text-xs px-3">{privacyTitle}</span></a></li>
          {false && <li><Link href="/policia-de-cookies" target="_blank" rel="noopener noreferrer" className="block hover:underline flex items-center gap-2"><span className="w-8 inline-block bg-sand-100 rounded text-xs px-3">{title}</span></a></li>
        </ul>

        {/* Enlaces legales específicos para usuarios */}
        <ul className="space-y-1 text-sm text-[#6B645A] marker:text-sand-600 mt-2">
          <li><Link href="/terminos-y-condiciones" target="_blank" rel="noopener noreferrer" className="block hover:underline flex items-center gap-2"><span className="w-8 inline-block bg-sand-100 rounded text-xs px-3">{legalTitle}</span></a></li>
          <li><Link href="/politica-de-datos" target="_blank" rel="noopener noreferrer" className="block hover:underline flex items-center gap-2"><span className="w-8 inline-block bg-sand-100 rounded text-xs px-3">{privacyTitle}</span></a></li>
          {false && <li><Link href="/policia-de-cookies" target="_blank" rel="noopener noreferrer" className="block hover:underline flex items-center gap-2"><span className="w-8 inline-block bg-sand-100 rounded text-xs px-3">{title}</span></a></li>
        </ul>

        {/* Enlaces legales adicionales */}
        <ul className="space-y-1 text-sm text-[#6B645A] marker:text-sand-600 mt-2">
          <li><Link href="/terminos-y-condiciones" target="_blank" rel="noopener noreferrer" className="block hover:underline flex items-center gap-2"><span className="w-8 inline-block bg-sand-100 rounded text-xs px-3">{legalTitle}</span></a></li>
          <li><Link href="/politica-de-datos" target="_blank" rel="noopener noreferrer" className="block hover:underline flex items-center gap-2"><span className="w-8 inline-block bg-sand-100 rounded text-xs px-3">{privacyTitle}</span></a></li>
          {false && <li><Link href="/policia-de-cookies" target="_blank" rel="noopener noreferrer" className="block hover:underline flex items-center gap-2"><span className="w-8 inline-block bg-sand-100 rounded text-xs px-3">{title}</span></a></li>
        </ul>
      </div>
    </div>
  );
}
