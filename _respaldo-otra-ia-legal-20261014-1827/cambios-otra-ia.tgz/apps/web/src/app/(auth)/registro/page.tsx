'use client';
import Link from 'next/link';
import { Gift, Users } from 'lucide-react';
import { ErrorBox, Field, Loading, Modal, Spinner, cn } from '@/components/ui';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/auth';

interface FormData {
  fullName: string;
  email: string;
  phone?: string;
  password: string;
  terms: boolean; // acepta términos y condiciones
  privacy: boolean; // acepta política de privacidad
}

const defaultForm: Partial<FormData> = {
  fullName: '',
  email: '',
  phone: undefined,
  password: '',
  terms: false,
  privacy: false,
};

export default function RegisterPage() {
  const { login } = useAuth();
  const router = useRouter();
  const [f, setF] = useState<FormData>(defaultForm);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const set = (k: keyof FormData) => (e: React.ChangeEvent<HTMLInputElement>) => {
    setF((x) => ({ ...x, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value }));
  };

  // Enlace de referido: /registro?ref=CODIGO → se guarda para enviarlo al crear el negocio.
  useEffect(() => {
    let code = new URLSearchParams(window.location.search).get('ref');
    try { if (code) localStorage.setItem('dream.ref', code); else code = localStorage.getItem('dream.ref'); } catch { /* sin almacenamiento */ }
    if (!code) return;
    api<any>(`/growth/referrals/check/${encodeURIComponent(code)}`, { noBusiness: true }).then((r) => { if (r.valid) setRef(r); else try { localStorage.removeItem('dream.ref'); } catch { /* */ } }).catch(() => null);
  }, []);

  const strong = f.password.length >= 8 && /[A-Za-z]/.test(f.password) && /\d/.test(f.password);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true); setError(null);

    // Verificar terminos y privacidad (si está desmarcado, mostrar mensaje de advertencia)
    if (!f.terms && !f.privacy) {
      const warning = 'Si no aceptas las políticas actuales, el registro te bloqueará. Puedes aceptarlas luego en la página de "Políticas";'.trim();
      setError(warning);
      setBusy(false);
      return;
    }

    try {
      const data: any = {
        ...f,
        phone: f.phone || undefined,
      };
      const r = await api<{ accessToken: string }>('/auth/register', { body: data });
      if (r) await login(r.accessToken);
      router.replace('/bienvenida');
    } catch (err) {
      setError((err as Error).message);
      setBusy(false);
    }
  }

  const strong = f.password.length >= 8 && /[A-Za-z]/.test(f.password) && /\d/.test(f.password);

  return (
    <form onSubmit={submit} className="space-y-6">
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-4">
          <Users className="h-6 w-6 text-[#111]" />
          <h1 className="font-display text-3xl font-semibold">Crea tu cuenta</h1>
        </div>
        <p className="text-sm text-ink-muted mt-1">Empieza gratis. Luego registramos tu negocio.</p>
      </div>

      {/* Enlace de referido */}
      {f.fullName && (
        <p className="flex items-center gap-2 rounded-xl bg-sand-50 border border-sand-200 px-3 py-2 text-sm">
          <Gift className="h-4 w-4 text-sand-600 shrink-0" /> Te invitó <b>{f.fullName}</b>. ¡Bienvenido!
        </p>
      )}

      {error && <ErrorBox message={error} />}

      <div className="grid lg:grid-cols-3 gap-5">
        {/* Nombre completo */}
        <div className="lg:col-span-2">
          <Field label="Nombre completo" hint="Escribe el nombre con apellidos completos del dueño del negocio">
            <input type="text" required autoComplete="name" value={f.fullName} onChange={set('fullName')} />
          </Field>
        </div>

        {/* Correo electrónico */}
        <div>
          <Field label="Correo electrónico" hint="Para recibir avisos del servicio">
            <input type="email" required autoComplete="email" value={f.email} onChange={set('email')} />
          </Field>
        </div>

        {/* Teléfono (opcional) */}
        <div className="lg:col-span-1">
          <Field label="Teléfono" hint="Para confirmaciones de cobro">
            <input type="tel" autoComplete="tel" value={f.phone} onChange={set('phone')} />
          </Field>
        </div>

        {/* Contraseña */}
        <div className="lg:col-span-2">
          <Field label="Contraseña" hint={<span className={strong ? 'text-ok' : ''}>Mínimo 8 caracteres: una mayúscula, un número y otra letra.</span)}>
            <input type="password" required autoComplete="new-password" value={f.password} onChange={set('password')} />
          </Field>
        </div>

        {/* Checkbox Términos y Condiciones */}
        <div className="lg:col-span-3">
          <label className="flex items-start gap-2 text-xs text-ink-muted mb-2">
            <input type="checkbox" className="mt-0.5 accent-ink" checked={f.terms} onChange={set('terms')} required />
            <span>Acepto los términos y condiciones de DREAMS para la creación de mi cuenta. Estos documentos explican mis responsabilidades, políticas, límites y obligaciones cuando accedo al servicio. Al aceptar, entiendo que puedo ser suspendido sin notificación si no cumpla. La violación de estos términos afecta mi uso del servicio y podría afectar su funcionamiento.</span>
          </label>

          {/* Checkbox Política de Privacidad */}
          <label className="flex items-start gap-2 text-xs text-ink-muted mb-3">
            <input type="checkbox" className="mt-0.5 accent-ink" checked={f.privacy} onChange={set('privacy')} required />
            <span>Acepto la política de privacidad de DREAMS. Esta política explica cómo recopilo, uso y protejo tus datos personales cuando accedo al servicio. Acepto que DreamS pueda usar tu información (nombre, email, teléfono, datos de navegación) para proveer el servicio y mejorar la experiencia.</span>
          </label>

          {/* Checkbox Opcional: Acepto cookies */}
          <label className="flex items-start gap-2 text-xs text-ink-muted mb-3">
            <input type="checkbox" className="mt-0.5 accent-ink" checked={f.cookies} onChange={set('cookies')} />
            <span>Acepto que las páginas de cookies y analytics del servicio me recopilen datos de mi navegación por DreamS para mejorar tu experiencia. Puedes desactivar o borrar cualquier cookie en tu navegador.</span>
          </label>

          <p className="text-[11px] text-sand-600 mt-3">
            Los términos y condiciones son obligatorios. Si aceptas, te comprometes a cumplir todos los requisitos de DREAMS: no utilizar el servicio de forma que afecte otros derechos, reportar comportamientos problemáticos sin autorización, respetar todas las políticas. La violación afecta tu uso del servicio.
          </p>

          {error && (
            <p className="text-sm text-amber-800 mt-3 font-medium">{error}</p>
          )}

          <button className="btn-primary w-full h-11 mt-4" disabled={busy || !strong || !f.terms || !f.privacy}>{busy && <Spinner />} Crear cuenta</button>
        </div>
      </div>

      <p className="text-sm text-center text-ink-muted">¿Ya tienes cuenta? <Link href="/ingresar" className="text-ink font-medium hover:underline">Ingresa</Link></p>

      {/* Enlaces legales */}
      <footer className="text-xs text-[#6B645A] border-t border-sand-200 pt-4 mt-6">
        <div className="flex flex-wrap justify-between gap-4">
          <a href="/terminos-y-condiciones" target="_blank" rel="noopener noreferrer" className="underline hover:text-[#111]">Términos y condiciones</a>
          <a href="/politica-de-datos" target="_blank" rel="noopener noreferrer" className="underline hover:text-[#111]">Política de privacidad</a>
          <a href="/policia-de-cookies" target="_blank" rel="noopener noreferrer" className="underline hover:text-[#111]">Cookies y funcionalidades</a>
          <Link href="/registro" className="font-medium underline decoration-sand-400 underline-offset-2">Regístrate por invitación: 15 días gratis por cada negocio que pague un plan</Link>
        </div>
      </footer>
    </form>
  );
}
