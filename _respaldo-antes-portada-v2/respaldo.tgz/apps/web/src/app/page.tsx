import Link from 'next/link';
import {
  ArrowRight, BarChart3, Boxes, Check, FileText, Gavel, Landmark, MessageCircle, Scissors, ShieldCheck, ShoppingBasket, Sparkles, Store, Truck, Users, UtensilsCrossed, Wrench, Zap,
} from 'lucide-react';
import { HeroMontage } from '@/components/hero-montage';
import { CLIPS } from '@/lib/hero-clips';
import { Logo } from '@/components/ui';
import { HELP_BRAND } from '@/lib/help-brand';

const sectors = [
  { icon: ShoppingBasket, title: 'Tiendas y plazas de mercado', text: 'Ventas del día, fiado, inventario y pedidos por WhatsApp.', bg: 'bg-amber-100', fg: 'text-amber-700' },
  { icon: Truck, title: 'Proveedores y distribuidores', text: 'Clientes mayoristas, cuentas por cobrar, bodegas y entregas.', bg: 'bg-sky-100', fg: 'text-sky-700' },
  { icon: UtensilsCrossed, title: 'Restaurantes y comidas', text: 'Pedidos, domicilios, insumos y lo que te deja cada plato.', bg: 'bg-orange-100', fg: 'text-orange-700' },
  { icon: Scissors, title: 'Belleza y confección', text: 'Agenda de citas, servicios, clientes frecuentes y recordatorios.', bg: 'bg-pink-100', fg: 'text-pink-700' },
  { icon: Wrench, title: 'Talleres y técnicos', text: 'Órdenes de servicio, repuestos, garantías y seguimiento para el cliente.', bg: 'bg-emerald-100', fg: 'text-emerald-700' },
  { icon: Gavel, title: 'Abogados y profesionales', text: 'Casos, términos, seguimiento de procesos y honorarios.', bg: 'bg-indigo-100', fg: 'text-indigo-700' },
];

const features = [
  { icon: BarChart3, title: 'Ventas y tablero', text: 'Registra cada venta en segundos y mira cómo vas hoy, esta semana y este mes.', c: 'from-fuchsia-500 to-pink-500' },
  { icon: Boxes, title: 'Inventario al día', text: 'El stock se descuenta solo al vender y te avisamos antes de que algo se agote.', c: 'from-amber-500 to-orange-500' },
  { icon: Users, title: 'Clientes que vuelven', text: 'Historial, canal por el que llegaron y quiénes son tus mejores clientes.', c: 'from-sky-500 to-cyan-500' },
  { icon: Store, title: 'Tu tienda en línea', text: 'Una página con tus productos y servicios para recibir pedidos y reservas.', c: 'from-emerald-500 to-teal-500' },
  { icon: FileText, title: 'Facturas y comprobantes', text: 'Con tu logo, en PDF, guardadas para garantías y lista para la DIAN.', c: 'from-violet-500 to-indigo-500' },
  { icon: Landmark, title: 'Finanzas claras', text: 'Gastos, utilidad, flujo de caja y conciliación con tus bancos.', c: 'from-rose-500 to-red-500' },
  { icon: MessageCircle, title: 'Redes y WhatsApp', text: 'Mide qué canal te vende más: Instagram, WhatsApp, Facebook, TikTok o tienda física.', c: 'from-green-500 to-emerald-600' },
  { icon: Sparkles, title: 'Asistente de negocio', text: 'Pregunta «¿cuánto vendí este mes?» y te responde con tus propios datos.', c: 'from-yellow-500 to-amber-500' },
];

const plans = [
  { name: 'Gratis', price: '$0', note: 'para siempre', tagline: 'Para empezar a ordenar tu negocio.', cta: 'Empezar gratis',
    items: ['1 usuario', 'Hasta 100 productos o servicios', '150 ventas al mes', 'Tablero, clientes e inventario', 'Facturas y tienda en línea', 'Reportes en CSV'] },
  { name: 'Emprendedor', price: '$19.900', note: 'al mes', tagline: 'Menos de lo que cuesta un almuerzo a la semana.', cta: 'Elegir Emprendedor', featured: true,
    items: ['Todo lo del plan Gratis', '2 usuarios', '1.000 productos o servicios', 'Ventas ilimitadas', 'Avisos por WhatsApp', '3 redes conectadas', 'Reportes en Excel'] },
  { name: 'Negocio', price: '$44.900', note: 'al mes', tagline: 'Para negocios con equipo y más movimiento.', cta: 'Elegir Negocio',
    items: ['Todo lo del plan Emprendedor', '5 usuarios', '5.000 productos o servicios', '3 cuentas bancarias', '6 redes conectadas', 'Reportes en PDF'] },
  { name: 'Empresa', price: '$99.900', note: 'al mes', tagline: 'Para crecer sin límites.', cta: 'Elegir Empresa',
    items: ['Todo lo del plan Negocio', 'Usuarios ilimitados', 'Productos ilimitados', 'Cuentas bancarias y redes ilimitadas', 'Soporte prioritario'] },
];

export default function Landing() {
  return (
    <div className="min-h-screen bg-white text-slate-900">
      {/* Encabezado */}
      <header className="sticky top-0 z-30 bg-white/85 backdrop-blur border-b border-slate-100">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <Logo />
          <nav className="flex items-center gap-1 sm:gap-2">
            <a href="#planes" className="hidden sm:inline-flex btn-ghost">Planes</a>
            <Link href="/ayuda" className="hidden md:inline-flex btn-ghost">{HELP_BRAND.name}</Link>
            <Link href="/ingresar" className="btn-ghost">Ingresar</Link>
            <Link href="/registro" className="inline-flex items-center gap-1.5 h-10 px-4 rounded-full bg-gradient-to-r from-fuchsia-600 to-orange-500 text-white text-sm font-semibold shadow-lg shadow-fuchsia-500/25 hover:brightness-110">Crear cuenta</Link>
          </nav>
        </div>
      </header>

      {/* Portada */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_left,_#fde68a_0%,_transparent_45%),radial-gradient(ellipse_at_bottom_right,_#f9a8d4_0%,_transparent_45%),radial-gradient(ellipse_at_top_right,_#a5f3fc_0%,_transparent_40%)]" aria-hidden />
        <div className="relative max-w-6xl mx-auto px-4 sm:px-6 pt-12 sm:pt-16 pb-16 grid lg:grid-cols-[1.05fr_.95fr] gap-10 lg:gap-12 items-center">
          <div>
            <span className="inline-flex items-center gap-1.5 rounded-full bg-white/80 border border-fuchsia-200 px-3 py-1 text-xs font-semibold text-fuchsia-700 shadow-sm">
              <Zap className="h-3.5 w-3.5" /> Hecho en Colombia para emprendedores
            </span>
            <h1 className="text-[2.6rem] sm:text-6xl leading-[1.02] font-extrabold tracking-tight mt-5">
              Tu negocio,{' '}
              <span className="bg-gradient-to-r from-fuchsia-600 via-rose-500 to-orange-500 bg-clip-text text-transparent">ordenado</span>{' '}
              y vendiendo{' '}
              <span className="bg-gradient-to-r from-sky-500 to-emerald-500 bg-clip-text text-transparent">más</span>.
            </h1>
            <p className="mt-5 text-lg text-slate-600 max-w-xl">
              Ventas, inventario, clientes, facturas, tienda en línea y finanzas en un solo lugar. Para tiendas, proveedores, restaurantes, peluquerías, talleres, profesionales y todo el que se le mide a emprender.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href="/registro" className="inline-flex items-center gap-2 h-13 px-7 py-3.5 rounded-full bg-gradient-to-r from-fuchsia-600 to-orange-500 text-white text-base font-bold shadow-xl shadow-orange-500/30 hover:brightness-110">
                Empieza gratis <ArrowRight className="h-5 w-5" />
              </Link>
              <a href="#planes" className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full bg-white border-2 border-slate-200 text-slate-800 text-base font-semibold hover:border-slate-300">Ver planes desde $0</a>
            </div>
            <ul className="mt-6 flex flex-wrap gap-x-5 gap-y-2 text-sm text-slate-600">
              {['Sin tarjeta de crédito', 'Funciona en el celular', 'Cancela cuando quieras'].map((t) => (
                <li key={t} className="flex items-center gap-1.5"><Check className="h-4 w-4 text-emerald-600" />{t}</li>
              ))}
            </ul>
          </div>
          <div className="relative">
            <div className="absolute -inset-3 rounded-[36px] bg-gradient-to-br from-fuchsia-500 via-orange-400 to-yellow-300 rotate-2 opacity-80" aria-hidden />
            <div className="absolute -inset-3 rounded-[36px] bg-gradient-to-tr from-sky-400 to-emerald-400 -rotate-2 opacity-40" aria-hidden />
            <div className="relative"><HeroMontage /></div>
          </div>
        </div>
      </section>

      {/* Para quién */}
      <section className="bg-slate-50 border-y border-slate-100">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-16">
          <p className="text-sm font-bold uppercase tracking-widest text-fuchsia-600">Para todo tipo de negocio</p>
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight mt-2">Se adapta a lo que tú haces</h2>
          <p className="text-slate-600 mt-2 max-w-2xl">Al crear tu cuenta eliges tu tipo de negocio y DREAMS te muestra las herramientas que necesitas, con las palabras de tu oficio.</p>
          <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {sectors.map((s) => (
              <div key={s.title} className="rounded-3xl bg-white p-6 shadow-sm border border-slate-100 hover:-translate-y-0.5 hover:shadow-md transition">
                <span className={`inline-flex h-12 w-12 items-center justify-center rounded-2xl ${s.bg} ${s.fg}`}><s.icon className="h-6 w-6" /></span>
                <h3 className="font-bold text-lg mt-4">{s.title}</h3>
                <p className="text-sm text-slate-600 mt-1.5">{s.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Funciones */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 py-16">
        <p className="text-sm font-bold uppercase tracking-widest text-orange-600">Todo en un solo lugar</p>
        <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight mt-2">Lo que necesitas, nada que te sobre</h2>
        <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {features.map((f) => (
            <div key={f.title} className="rounded-3xl border border-slate-100 p-6 bg-white shadow-sm">
              <span className={`inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br ${f.c} text-white shadow-md`}><f.icon className="h-5 w-5" /></span>
              <h3 className="font-bold mt-4">{f.title}</h3>
              <p className="text-sm text-slate-600 mt-1.5 leading-relaxed">{f.text}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Propósito */}
      <section className="relative overflow-hidden bg-gradient-to-br from-fuchsia-700 via-rose-600 to-orange-500 text-white">
        <div className="absolute -right-24 -top-24 h-72 w-72 rounded-full bg-yellow-300/30 blur-3xl" aria-hidden />
        <div className="absolute -left-24 -bottom-24 h-72 w-72 rounded-full bg-sky-400/30 blur-3xl" aria-hidden />
        <div className="relative max-w-6xl mx-auto px-4 sm:px-6 py-16 grid lg:grid-cols-[.9fr_1.1fr] gap-10 items-center">
          <div>
            <p className="text-sm font-bold uppercase tracking-widest text-yellow-200">Nuestro propósito</p>
            <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight mt-2">Que dediques tu tiempo a lo que sabes hacer.</h2>
            <p className="mt-4 text-white/90 text-lg">Tecnología sencilla y a un precio justo para que el pequeño negocio colombiano crezca con orden, venda en más lugares y tome decisiones con información clara.</p>
          </div>
          <div className="grid sm:grid-cols-3 gap-3">
            {[
              ['Más claridad', 'Ventas, productos y gastos desde un solo lugar.'],
              ['Menos tareas repetidas', 'Pedidos, clientes e inventario organizados.'],
              ['Crece a tu ritmo', 'Empieza gratis y suma herramientas cuando estés listo.'],
            ].map(([title, text]) => (
              <div key={title} className="rounded-3xl bg-white/15 backdrop-blur p-5 border border-white/20">
                <p className="font-bold text-yellow-100">{title}</p>
                <p className="text-sm text-white/85 mt-2">{text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Planes */}
      <section id="planes" className="max-w-6xl mx-auto px-4 sm:px-6 py-16 scroll-mt-16">
        <p className="text-sm font-bold uppercase tracking-widest text-emerald-600">Planes</p>
        <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight mt-2">Precios pensados para emprendedores</h2>
        <p className="text-slate-600 mt-2">Empieza gratis y cambia de plan cuando tu negocio lo pida. Precios mensuales en pesos colombianos.</p>
        <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-4 gap-4 items-stretch">
          {plans.map((p) => (
            <div key={p.name} className={`relative rounded-3xl p-6 flex flex-col ${p.featured ? 'bg-gradient-to-br from-fuchsia-600 to-orange-500 text-white shadow-2xl shadow-fuchsia-500/30 lg:-translate-y-2' : 'bg-white border-2 border-slate-100'}`}>
              {p.featured && <span className="absolute -top-3 left-6 rounded-full bg-yellow-300 text-slate-900 text-xs font-bold px-3 py-1 shadow">El más elegido</span>}
              <p className={`text-sm font-bold uppercase tracking-wide ${p.featured ? 'text-yellow-100' : 'text-slate-500'}`}>{p.name}</p>
              <p className="mt-2"><span className="text-4xl font-extrabold">{p.price}</span><span className={`text-sm ${p.featured ? 'text-white/80' : 'text-slate-500'}`}> {p.note}</span></p>
              <p className={`text-sm mt-2 ${p.featured ? 'text-white/90' : 'text-slate-600'}`}>{p.tagline}</p>
              <ul className="mt-5 space-y-2 text-sm flex-1">
                {p.items.map((i) => <li key={i} className="flex gap-2"><Check className={`h-4 w-4 mt-0.5 shrink-0 ${p.featured ? 'text-yellow-200' : 'text-emerald-600'}`} />{i}</li>)}
              </ul>
              <Link href="/registro" className={`mt-6 inline-flex justify-center items-center h-11 rounded-full text-sm font-bold ${p.featured ? 'bg-white text-fuchsia-700 hover:bg-yellow-50' : 'bg-slate-900 text-white hover:bg-slate-700'}`}>{p.cta}</Link>
            </div>
          ))}
        </div>
        <p className="text-xs text-slate-500 mt-4">Abogados y profesionales: casos, términos y calculadora de honorarios en todos los planes; seguimiento de procesos: 5 en Gratis, 30 en Emprendedor, 150 en Negocio e ilimitado en Empresa.</p>
      </section>

      {/* Micro app ciudadana */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 pb-16">
        <div className="rounded-3xl bg-gradient-to-r from-sky-600 to-indigo-700 text-white p-8 sm:p-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div>
            <p className="text-sm font-bold uppercase tracking-widest text-sky-200">Orientación legal gratuita</p>
            <p className="text-2xl sm:text-3xl font-extrabold mt-1">¿Tienes un problema legal? Entra a «{HELP_BRAND.name}»</p>
            <p className="text-white/85 mt-2 max-w-2xl">Te decimos en palabras sencillas qué puedes hacer, dónde acudir en tu municipio y si tienes un plazo corriendo. Si quieres, abogados verificados te envían propuestas.</p>
          </div>
          <Link href="/ayuda" className="inline-flex items-center gap-2 h-12 px-6 rounded-full bg-yellow-300 text-slate-900 font-bold shrink-0 hover:bg-yellow-200">Abrir {HELP_BRAND.name} <ArrowRight className="h-4 w-4" /></Link>
        </div>
      </section>

      {/* Seguridad y llamado final */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 pb-20">
        <div className="rounded-3xl bg-slate-900 text-white p-8 sm:p-12 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          <div className="flex gap-4 items-start">
            <span className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-500/20 text-emerald-300 shrink-0"><ShieldCheck className="h-6 w-6" /></span>
            <div>
              <p className="text-xl font-bold">Seguridad desde el primer día</p>
              <p className="text-sm text-white/75 mt-1 max-w-xl">Contraseñas cifradas, verificación en dos pasos, permisos por rol y registro de actividad. Nunca te pediremos la contraseña de tu banco.</p>
            </div>
          </div>
          <Link href="/registro" className="inline-flex items-center gap-2 h-12 px-6 rounded-full bg-gradient-to-r from-fuchsia-600 to-orange-500 font-bold shrink-0 hover:brightness-110">Crear mi cuenta gratis <ArrowRight className="h-4 w-4" /></Link>
        </div>
      </section>

      <footer className="border-t border-slate-100">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8 space-y-3 text-xs text-slate-500">
          <div className="flex flex-col sm:flex-row justify-between gap-4">
            <Logo />
            <p>La contabilidad de DREAMS es gerencial y no reemplaza la asesoría de un contador público.</p>
          </div>
          <p>Videos de la portada: Pexels — {CLIPS.map((c, k) => <span key={c.id}>{k > 0 && ', '}<a className="underline underline-offset-2 hover:text-slate-800" href={`https://www.pexels.com/video/${c.id}/`} target="_blank" rel="noreferrer">{c.credit}</a></span>)}.</p>
        </div>
      </footer>
    </div>
  );
}
