'use client';
import { ArrowUp, Bot, Sparkles } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { Disclaimer, PageHeader, Spinner } from '@/components/ui';
import { api } from '@/lib/api';

const SUGGESTIONS = [
  '¿Cuánto vendí este mes?', '¿Cuál fue mi producto más vendido?', '¿Cuál es mi margen de utilidad?', '¿Cuánto gasté en publicidad?',
  '¿Qué productos están próximos a agotarse?', '¿Qué clientes compran más?', '¿Qué canal genera más ventas?',
  '¿Estoy gastando más que el mes pasado?', '¿Cuánto necesito vender para alcanzar 15 millones?', '¿Cuál fue mi mejor día de ventas?',
];

type Msg = { role: 'user' | 'assistant'; text: string; suggestions?: string[] };

export default function AssistantPage() {
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [q, setQ] = useState('');
  const [busy, setBusy] = useState(false);
  const end = useRef<HTMLDivElement>(null);
  useEffect(() => { end.current?.scrollIntoView({ behavior: 'smooth' }); }, [msgs]);

  const ask = async (question: string) => {
    if (!question.trim() || busy) return;
    setMsgs((m) => [...m, { role: 'user', text: question }]);
    setQ(''); setBusy(true);
    try {
      const r = await api<{ answer: string; intent: string; data?: any }>('/assistant/ask', { body: { question } });
      setMsgs((m) => [...m, { role: 'assistant', text: r.answer, suggestions: r.intent === 'unknown' ? r.data : undefined }]);
    } catch (e) {
      setMsgs((m) => [...m, { role: 'assistant', text: (e as Error).message }]);
    } finally { setBusy(false); }
  };

  return (
    <>
      <PageHeader title="Asistente de Negocio" subtitle="Pregunta en tus palabras. Las respuestas se calculan con los datos de tu negocio." />
      <div className="card flex flex-col h-[calc(100vh-240px)] min-h-[460px]">
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          {msgs.length === 0 && (
            <div className="max-w-2xl mx-auto text-center pt-6">
              <div className="h-12 w-12 rounded-2xl bg-primary text-on-primary/70 mx-auto flex items-center justify-center"><Sparkles className="h-5 w-5" /></div>
              <p className="font-display text-2xl font-semibold mt-4">¿Qué quieres saber hoy?</p>
              <div className="mt-6 flex flex-wrap justify-center gap-2">
                {SUGGESTIONS.map((s) => <button key={s} className="chip bg-sand-100 hover:bg-sand-200 text-ink text-xs px-3 py-1.5" onClick={() => ask(s)}>{s}</button>)}
              </div>
            </div>
          )}
          {msgs.map((m, i) => (
            <div key={i} className={`flex gap-3 ${m.role === 'user' ? 'justify-end' : ''}`}>
              {m.role === 'assistant' && <span className="h-8 w-8 rounded-lg bg-primary text-on-primary/70 flex items-center justify-center shrink-0"><Bot className="h-4 w-4" /></span>}
              <div className={`max-w-[80%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${m.role === 'user' ? 'bg-primary text-on-primary rounded-br-md' : 'bg-sand-100 text-ink rounded-bl-md'}`}>
                {m.text}
                {m.suggestions && <div className="mt-3 flex flex-wrap gap-1.5">{m.suggestions.map((s) => <button key={s} className="chip bg-white hover:bg-sand-50 text-ink" onClick={() => ask(s)}>{s}</button>)}</div>}
              </div>
            </div>
          ))}
          {busy && <div className="flex gap-3"><span className="h-8 w-8 rounded-lg bg-primary text-on-primary/70 flex items-center justify-center"><Spinner /></span></div>}
          <div ref={end} />
        </div>
        <form className="border-t border-line p-3 flex gap-2" onSubmit={(e) => { e.preventDefault(); ask(q); }}>
          <input className="input h-11" placeholder="Ej. ¿Qué canal genera más ventas este mes?" value={q} onChange={(e) => setQ(e.target.value)} maxLength={500} />
          <button className="btn-primary h-11 w-11 !px-0" disabled={!q.trim() || busy} aria-label="Preguntar"><ArrowUp className="h-4 w-4" /></button>
        </form>
      </div>
      <div className="mt-4"><Disclaimer>El asistente solo usa los datos del negocio activo y respeta los permisos de tu rol. Las cifras financieras son estimaciones gerenciales y no reemplazan a un contador.</Disclaimer></div>
    </>
  );
}
