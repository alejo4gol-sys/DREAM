import { Body, Controller, Injectable, Module, Post } from '@nestjs/common';
import { IsString, Length } from 'class-validator';
import { and, desc, eq, gte, isNull, lt, sql } from 'drizzle-orm';
import { Ctx, RequestContext, RequirePermissions } from '../common/auth.guard';
import { RangeKey, rangeFor } from '../common/dates';
import { num } from '../common/money';
import { Db, InjectDb } from '../db/db';
import { businesses, customers, expenses, inventoryLevels, products, saleItems, sales } from '../db/schema';
import { AccountingService, EXPENSE_LABELS } from '../finance/accounting.service';
import { FinanceModule } from '../finance/finance.module';

class AskDto { @IsString() @Length(2, 500) question: string; }

const cop = (n: number) => n.toLocaleString('es-CO', { style: 'currency', currency: 'COP', maximumFractionDigits: 0 });
const CHANNEL_ES: Record<string, string> = {
  INSTAGRAM: 'Instagram', FACEBOOK: 'Facebook', WHATSAPP: 'WhatsApp', TIKTOK: 'TikTok', WEBSITE: 'Página web',
  PHYSICAL_STORE: 'Tienda física', MARKETPLACE: 'Marketplace', OTHER: 'Otros',
};
const PERIOD_ES: Record<RangeKey, string> = { today: 'hoy', week: 'esta semana', month: 'este mes', quarter: 'los últimos 3 meses', year: 'este año' };

export const SUGGESTIONS = [
  '¿Cuánto vendí este mes?', '¿Cuál fue mi producto más vendido?', '¿Cuál es mi margen de utilidad?',
  '¿Cuánto gasté en publicidad?', '¿Qué productos están próximos a agotarse?', '¿Qué clientes compran más?',
  '¿Qué canal genera más ventas?', '¿Estoy gastando más que el mes pasado?',
  '¿Cuánto necesito vender para alcanzar 10.000.000?', '¿Cuál fue mi mejor día de ventas?',
];

/** Normaliza texto: minúsculas y sin tildes. */
export const norm = (s: string) => s.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');

export function detectPeriod(q: string): RangeKey | 'lastMonth' {
  if (/mes pasado|mes anterior/.test(q)) return 'lastMonth';
  if (/\bhoy\b/.test(q)) return 'today';
  if (/semana/.test(q)) return 'week';
  if (/trimestre|3 meses|tres meses/.test(q)) return 'quarter';
  if (/\bano\b|anual/.test(q)) return 'year';
  return 'month';
}

/** Extrae una meta en pesos: "10 millones", "10.000.000", "$2.5M", "500 mil". */
export function parseGoal(q: string): number | null {
  const m = q.match(/(\d+(?:[.,]\d+)*)\s*(millones|millon|m\b|mil|k\b)?/);
  if (!m) return null;
  let raw = m[1];
  const unit = m[2];
  if (unit) raw = raw.replace(',', '.');
  else raw = raw.replace(/[.,]/g, '');
  let n = Number(raw);
  if (!isFinite(n)) return null;
  if (unit === 'mil' || unit === 'k') n *= 1_000;
  else if (unit) n *= 1_000_000;
  return n > 0 ? n : null;
}

type Answer = { answer: string; data?: unknown; intent: string };

/**
 * Asistente de Negocio (modo reglas): responde con cálculos exactos sobre los datos
 * del negocio activo. Solo usa datos del businessId validado por el guard.
 * Para lenguaje libre, se puede conectar un modelo (ANTHROPIC_API_KEY) enviándole
 * únicamente agregados de este negocio — nunca datos de otros negocios.
 */
@Injectable()
export class AssistantService {
  constructor(@InjectDb() private db: Db, private acc: AccountingService) {}

  private period(ctx: RequestContext, key: RangeKey | 'lastMonth') {
    if (key === 'lastMonth') {
      const r = rangeFor('month', ctx.timezone);
      return { from: r.prevFrom, to: r.from, label: 'el mes pasado' };
    }
    const r = rangeFor(key, ctx.timezone);
    return { from: r.from, to: r.to, label: PERIOD_ES[key] };
  }

  private salesWhere(b: string, from: Date, to: Date) {
    return and(eq(sales.businessId, b), gte(sales.date, from), lt(sales.date, to), isNull(sales.cancelledAt));
  }

  async ask(ctx: RequestContext, question: string): Promise<Answer> {
    const q = norm(question);
    const b = ctx.businessId;
    const finance = ctx.permissions.has('finance:read');
    const noFinance: Answer = { intent: 'forbidden', answer: 'Tu rol no tiene acceso a la información financiera necesaria para responder esto.' };
    const per = this.period(ctx, detectPeriod(q));

    // Meta de ventas
    if (/meta|alcanzar|necesito vender|para llegar/.test(q)) {
      const goalFromText = parseGoal(q.replace(/\b(19|20)\d{2}\b/, ''));
      const biz = await this.db.query.businesses.findFirst({ where: eq(businesses.id, b), columns: { monthlyGoal: true } });
      const goal = goalFromText ?? (biz?.monthlyGoal ? Number(biz.monthlyGoal) : null);
      if (!goal) return { intent: 'goal', answer: 'Dime la meta, por ejemplo: "¿Cuánto necesito vender para alcanzar 10 millones este mes?". También puedes definir una meta mensual en Configuración.' };
      const m = this.period(ctx, 'month');
      const s = await this.acc.salesTotals(b, m.from, m.to);
      const sold = num(s.total);
      const missing = Math.max(0, goal - sold);
      const now = new Date();
      const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
      const daysLeft = Math.max(1, daysInMonth - now.getDate() + 1);
      const avg = s.count ? sold / s.count : 0;
      const answer = missing === 0
        ? `¡Ya alcanzaste la meta de ${cop(goal)}! Llevas ${cop(sold)} este mes.`
        : `Llevas ${cop(sold)} este mes. Te faltan ${cop(missing)} para la meta de ${cop(goal)}: unas ${cop(missing / daysLeft)} por día durante los ${daysLeft} días que quedan` +
          (avg ? `, o cerca de ${Math.ceil(missing / avg)} ventas más con tu ticket promedio de ${cop(avg)}.` : '.');
      return { intent: 'goal', answer, data: { goal, sold, missing, daysLeft } };
    }

    // Productos por agotarse
    if (/agot|inventario bajo|poco inventario|stock|reponer/.test(q)) {
      const stock = sql<number>`coalesce(sum(${inventoryLevels.quantity}),0)::int`;
      const rows = await this.db.select({ name: products.name, stock, minStock: products.minStock }).from(products)
        .leftJoin(inventoryLevels, eq(inventoryLevels.productId, products.id))
        .where(and(eq(products.businessId, b), eq(products.isActive, true))).groupBy(products.id)
        .having(sql`${stock} <= ${products.minStock}`).orderBy(stock).limit(10);
      if (!rows.length) return { intent: 'low_stock', answer: 'Ningún producto está en o por debajo de su stock mínimo.' };
      return { intent: 'low_stock', answer: `Hay ${rows.length} producto(s) en o bajo el mínimo: ${rows.map((r) => `${r.name} (${r.stock}/${r.minStock})`).join(', ')}.`, data: rows };
    }

    // Producto más vendido
    if (/producto/.test(q) && /(mas vendido|vend[io] mas|top|mejor)/.test(q)) {
      const rows = await this.db.select({ name: saleItems.description, units: sql<number>`sum(${saleItems.quantity})::int`, revenue: sql<string>`sum(${saleItems.lineTotal})` })
        .from(saleItems).innerJoin(sales, eq(sales.id, saleItems.saleId)).where(this.salesWhere(b, per.from, per.to))
        .groupBy(saleItems.description).orderBy(desc(sql`sum(${saleItems.quantity})`)).limit(5);
      if (!rows.length) return { intent: 'top_product', answer: `No hay ventas registradas ${per.label}.` };
      return { intent: 'top_product', answer: `Tu producto más vendido ${per.label} es ${rows[0].name}: ${rows[0].units} unidades por ${cop(num(rows[0].revenue))}.` + (rows.length > 1 ? ` Le siguen ${rows.slice(1, 3).map((r) => `${r.name} (${r.units})`).join(' y ')}.` : ''), data: rows };
    }

    // Clientes que más compran
    if (/cliente/.test(q)) {
      const rows = await this.db.select({ name: customers.name, total: customers.totalSpent, purchases: customers.purchaseCount })
        .from(customers).where(and(eq(customers.businessId, b), sql`${customers.purchaseCount} > 0`)).orderBy(desc(customers.totalSpent)).limit(5);
      if (!rows.length) return { intent: 'top_customers', answer: 'Aún no hay clientes con compras registradas.' };
      return { intent: 'top_customers', answer: `Tus clientes que más compran: ${rows.map((r, i) => `${i + 1}. ${r.name} — ${cop(num(r.total))} en ${r.purchases} compra(s)`).join('; ')}.`, data: rows };
    }

    // Canal
    if (/canal|red social|redes|instagram|whatsapp|facebook/.test(q)) {
      const rows = await this.db.select({ channel: sales.channel, total: sql<string>`sum(${sales.total})`, orders: sql<number>`count(*)::int` })
        .from(sales).where(this.salesWhere(b, per.from, per.to)).groupBy(sales.channel).orderBy(desc(sql`sum(${sales.total})`));
      if (!rows.length) return { intent: 'top_channel', answer: `No hay ventas registradas ${per.label}.` };
      const total = rows.reduce((a, r) => a + num(r.total), 0);
      return { intent: 'top_channel', answer: `${CHANNEL_ES[rows[0].channel]} es tu mejor canal ${per.label}: ${cop(num(rows[0].total))} (${Math.round((num(rows[0].total) / total) * 100)}% de las ventas, ${rows[0].orders} pedidos).`, data: rows };
    }

    // Mejor día
    if (/mejor dia|dia (con mas|de mas)|dia que mas/.test(q)) {
      const r = this.period(ctx, detectPeriod(q) === 'month' && !/mes/.test(q) ? 'year' : detectPeriod(q));
      const rows = await this.db.select({ day: sql<string>`to_char(${sales.date} at time zone ${ctx.timezone}, 'YYYY-MM-DD')`, total: sql<string>`sum(${sales.total})`, orders: sql<number>`count(*)::int` })
        .from(sales).where(this.salesWhere(b, r.from, r.to)).groupBy(sql`1`).orderBy(desc(sql`sum(${sales.total})`)).limit(1);
      if (!rows.length) return { intent: 'best_day', answer: `No hay ventas registradas ${r.label}.` };
      const d = new Date(`${rows[0].day}T12:00:00`);
      return { intent: 'best_day', answer: `Tu mejor día de ventas ${r.label} fue el ${d.toLocaleDateString('es-CO', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}, con ${cop(num(rows[0].total))} en ${rows[0].orders} venta(s).`, data: rows[0] };
    }

    // Gastando más que el mes pasado
    if (/gast/.test(q) && /(mas que|menos que|compar|mes pasado|anterior)/.test(q)) {
      if (!finance) return noFinance;
      const r = rangeFor('month', ctx.timezone);
      const cur = await this.acc.expensesByCategory(b, r.from, r.to);
      const prevSame = await this.acc.expensesByCategory(b, r.prevFrom, r.prevTo);
      const t = (x: { total: number }[]) => x.reduce((a, e) => a + e.total, 0);
      const c = t(cur); const p = t(prevSame);
      const diff = c - p;
      const pct = p ? Math.round((diff / p) * 100) : null;
      return {
        intent: 'expense_compare',
        answer: diff > 0
          ? `Sí: llevas ${cop(c)} en gastos este mes, ${cop(diff)} más que a esta misma altura del mes pasado (${cop(p)})${pct !== null ? `, un ${pct}% más` : ''}.`
          : `No: llevas ${cop(c)} en gastos este mes, ${cop(-diff)} menos que a esta misma altura del mes pasado (${cop(p)}).`,
        data: { current: c, previous: p },
      };
    }

    // Gasto en una categoría
    if (/gast|pague|invert/.test(q)) {
      if (!finance) return noFinance;
      const map: [RegExp, string][] = [[/publicidad|pauta|anuncio|marketing/, 'ADVERTISING'], [/arriendo|alquiler/, 'RENT'], [/servicio/, 'UTILITIES'],
        [/nomina|salario|sueldo/, 'PAYROLL'], [/transporte|envio|domicilio/, 'TRANSPORT'], [/mercancia|inventario|compra/, 'MERCHANDISE'],
        [/comision|banc/, 'BANK_FEES'], [/impuesto/, 'TAXES']];
      const cat = map.find(([re]) => re.test(q))?.[1];
      const rows = await this.acc.expensesByCategory(b, per.from, per.to);
      if (cat) {
        const v = rows.find((r) => r.category === cat)?.total ?? 0;
        return { intent: 'expense_category', answer: `Gastaste ${cop(v)} en ${EXPENSE_LABELS[cat].toLowerCase()} ${per.label}.`, data: { category: cat, total: v } };
      }
      const total = rows.reduce((a, r) => a + r.total, 0);
      return { intent: 'expenses', answer: `Tus gastos ${per.label} suman ${cop(total)}.` + (rows[0] ? ` El rubro más alto es ${rows[0].label} con ${cop(rows[0].total)}.` : ''), data: rows };
    }

    // Margen / utilidad
    if (/margen|utilidad|ganancia|gane|rentab/.test(q)) {
      if (!finance) return noFinance;
      const s = await this.acc.incomeStatement(b, per.from, per.to);
      return {
        intent: 'margin',
        answer: `${per.label[0].toUpperCase() + per.label.slice(1)}: ventas netas ${cop(s.netSales)}, utilidad bruta ${cop(s.grossProfit)} (margen bruto ${s.grossMargin}%) y utilidad neta estimada ${cop(s.netProfit)} (margen neto ${s.netMargin}%). Es un cálculo gerencial, no reemplaza a tu contador.`,
        data: s,
      };
    }

    // Ventas del período
    if (/vend|venta|factur|ingres/.test(q)) {
      const s = await this.acc.salesTotals(b, per.from, per.to);
      return { intent: 'sales_total', answer: `Vendiste ${cop(num(s.total))} ${per.label} en ${s.count} venta(s).` + (s.count ? ` Ticket promedio: ${cop(num(s.total) / s.count)}.` : ''), data: s };
    }

    return { intent: 'unknown', answer: 'Aún no sé responder esa pregunta. Prueba con alguna de estas:', data: SUGGESTIONS };
  }
}

@Controller('assistant')
export class AssistantController {
  constructor(private service: AssistantService) {}

  @Post('ask') @RequirePermissions('assistant:use')
  ask(@Ctx() ctx: RequestContext, @Body() dto: AskDto) {
    return this.service.ask(ctx, dto.question);
  }
}

@Module({ imports: [FinanceModule], controllers: [AssistantController], providers: [AssistantService] })
export class AssistantModule {}
