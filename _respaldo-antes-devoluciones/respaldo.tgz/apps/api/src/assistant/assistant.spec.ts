import { detectPeriod, norm, parseGoal } from './assistant.module';

describe('asistente: interpretación de preguntas', () => {
  it('detecta períodos', () => {
    expect(detectPeriod(norm('¿Cuánto vendí hoy?'))).toBe('today');
    expect(detectPeriod(norm('ventas de esta semana'))).toBe('week');
    expect(detectPeriod(norm('¿Cuánto vendí el mes pasado?'))).toBe('lastMonth');
    expect(detectPeriod(norm('mejor día del año'))).toBe('year');
    expect(detectPeriod(norm('¿Cuánto vendí?'))).toBe('month');
  });

  it('interpreta metas en pesos', () => {
    expect(parseGoal('alcanzar 10 millones')).toBe(10_000_000);
    expect(parseGoal('alcanzar 10.000.000')).toBe(10_000_000);
    expect(parseGoal('meta de 2,5 millones')).toBe(2_500_000);
    expect(parseGoal('meta de 500 mil')).toBe(500_000);
    expect(parseGoal('sin numero')).toBeNull();
  });
});
