/**
 * DREAMS — modelo de datos (Drizzle ORM · PostgreSQL)
 * - Multi-tenant: toda tabla de negocio lleva businessId.
 * - Dinero: numeric(14,2) (se maneja como string + decimal.js; nunca float).
 * - Columnas en snake_case en la BD (casing: 'snake_case').
 */
import {
  pgTable, pgEnum, uuid, text, varchar, boolean, integer, numeric, timestamp, jsonb,
  primaryKey, uniqueIndex, index,
} from 'drizzle-orm/pg-core';
import { relations } from 'drizzle-orm';

const money = () => numeric({ precision: 14, scale: 2 });
const ts = () => timestamp({ withTimezone: true, mode: 'date' });
const id = () => uuid().primaryKey().defaultRandom();
const createdAt = () => ts().notNull().defaultNow();

export type StorePaymentMethod = {
  name: string; instructions: string; enabled: boolean;
  kind?: string; accountHolder?: string; accountNumber?: string; bank?: string; accountType?: string;
  documentId?: string; link?: string; qrImage?: string;
};
export type StoreSiteConfig = Record<string, any> & { paymentMethods?: StorePaymentMethod[] };

// ───────────── Enums ─────────────
export const planCode = pgEnum('plan_code', ['FREE', 'BASIC', 'PRO', 'ENTERPRISE']);
export const subscriptionStatus = pgEnum('subscription_status', ['ACTIVE', 'TRIALING', 'PAST_DUE', 'CANCELLED']);
export const membershipStatus = pgEnum('membership_status', ['ACTIVE', 'SUSPENDED']);
export const saleStatus = pgEnum('sale_status', ['PENDING', 'PARTIALLY_PAID', 'PAID', 'CANCELLED']);
export const paymentMethod = pgEnum('payment_method', [
  'CASH', 'BANK_TRANSFER', 'DEBIT_CARD', 'CREDIT_CARD', 'PSE', 'NEQUI', 'DAVIPLATA', 'OTHER',
]);
export const salesChannel = pgEnum('sales_channel', [
  'INSTAGRAM', 'FACEBOOK', 'WHATSAPP', 'TIKTOK', 'WEBSITE', 'PHYSICAL_STORE', 'MARKETPLACE', 'OTHER',
]);
export const expenseCategory = pgEnum('expense_category', [
  'RENT', 'UTILITIES', 'PAYROLL', 'TRANSPORT', 'ADVERTISING', 'MERCHANDISE', 'BANK_FEES', 'TAXES', 'OTHER',
]);
export const payableStatus = pgEnum('payable_status', ['PAID', 'PENDING']);
export const purchaseStatus = pgEnum('purchase_status', ['PENDING', 'PARTIALLY_PAID', 'PAID']);
export const movementType = pgEnum('movement_type', ['INITIAL', 'PURCHASE', 'SALE', 'SALE_CANCEL', 'ADJUSTMENT', 'ORDER_RESERVE', 'ORDER_RELEASE', 'RETURN']);
export const storeOrderStatus = pgEnum('store_order_status', ['RECEIVED', 'CONFIRMED', 'SHIPPED', 'DELIVERED', 'CANCELLED']);
export const bankProvider = pgEnum('bank_provider', ['MANUAL', 'SANDBOX']);
export const bankTxType = pgEnum('bank_tx_type', ['CREDIT', 'DEBIT']);
export const bankTxStatus = pgEnum('bank_tx_status', ['UNMATCHED', 'MATCHED', 'IGNORED']);
export const reconciliationStatus = pgEnum('reconciliation_status', ['SUGGESTED', 'ACCEPTED', 'REJECTED']);
export const socialPlatform = pgEnum('social_platform', ['INSTAGRAM', 'FACEBOOK', 'WHATSAPP', 'TIKTOK', 'YOUTUBE', 'X']);
export const socialAccountStatus = pgEnum('social_account_status', ['CONNECTED', 'EXPIRED', 'REVOKED']);

// ───────────── Identidad y acceso ─────────────
export const users = pgTable('users', {
  id: id(),
  email: varchar({ length: 255 }).notNull().unique(),
  passwordHash: text().notNull(),
  fullName: varchar({ length: 160 }).notNull(),
  phone: varchar({ length: 40 }),
  emailVerifiedAt: ts(),
  twoFactorEnabled: boolean().notNull().default(false),
  twoFactorSecretEnc: text(),
  failedLoginCount: integer().notNull().default(0),
  lockedUntil: ts(),
  acceptedPolicyAt: ts(),
  /** Redes sociales personales del usuario (instagram, tiktok, linkedin…). */
  socialLinks: jsonb().$type<Record<string, string>>().notNull().default({}),
  createdAt: createdAt(),
  updatedAt: ts().notNull().defaultNow().$onUpdate(() => new Date()),
});

export const sessions = pgTable('sessions', {
  id: id(),
  userId: uuid().notNull().references(() => users.id, { onDelete: 'cascade' }),
  refreshTokenHash: text().notNull(),
  userAgent: text(),
  ip: varchar({ length: 64 }),
  createdAt: createdAt(),
  lastUsedAt: ts().notNull().defaultNow(),
  expiresAt: ts().notNull(),
  revokedAt: ts(),
}, (t) => [index().on(t.userId)]);

export const passwordResetTokens = pgTable('password_reset_tokens', {
  id: id(),
  userId: uuid().notNull().references(() => users.id, { onDelete: 'cascade' }),
  tokenHash: text().notNull().unique(),
  expiresAt: ts().notNull(),
  usedAt: ts(),
  createdAt: createdAt(),
});

// ───────────── Negocio ─────────────
export const businesses = pgTable('businesses', {
  id: id(),
  ownerId: uuid().notNull().references(() => users.id),
  tradeName: varchar({ length: 160 }).notNull(),
  legalName: varchar({ length: 200 }),
  taxId: varchar({ length: 40 }),
  phone: varchar({ length: 40 }),
  email: varchar({ length: 255 }),
  address: varchar({ length: 255 }),
  city: varchar({ length: 120 }),
  country: varchar({ length: 2 }).notNull().default('CO'),
  currency: varchar({ length: 3 }).notNull().default('COP'),
  timezone: varchar({ length: 64 }).notNull().default('America/Bogota'),
  businessType: varchar({ length: 80 }),
  category: varchar({ length: 80 }),
  logoUrl: text(),
  socialLinks: jsonb().$type<Record<string, string>>().notNull().default({}),
  /** Paleta de marca elegida por el negocio: colores en hex (#RRGGBB). */
  brandColors: jsonb().$type<{ primary: string; accent: string; paletteId?: string }>(),
  storeSlug: varchar({ length: 80 }).unique(),
  storeEnabled: boolean().notNull().default(false),
  /** Configuración del sitio web público (diseño, secciones, medios de pago…). Ver store.module.ts. */
  storeConfig: jsonb().$type<StoreSiteConfig>().notNull().default({}),
  wompiPublicKey: varchar({ length: 120 }),
  wompiPrivateKeyEnc: text(),
  wompiIntegritySecretEnc: text(),
  wompiEventSecretEnc: text(),
  monthlyGoal: money(),
  nextSaleNumber: integer().notNull().default(1),
  createdAt: createdAt(),
  updatedAt: ts().notNull().defaultNow().$onUpdate(() => new Date()),
});

export const roles = pgTable('roles', {
  id: id(),
  businessId: uuid().references(() => businesses.id, { onDelete: 'cascade' }), // null = rol del sistema
  key: varchar({ length: 40 }).notNull(),
  name: varchar({ length: 80 }).notNull(),
  isSystem: boolean().notNull().default(false),
}, (t) => [uniqueIndex().on(t.businessId, t.key)]);

export const rolePermissions = pgTable('role_permissions', {
  roleId: uuid().notNull().references(() => roles.id, { onDelete: 'cascade' }),
  permission: varchar({ length: 60 }).notNull(),
}, (t) => [primaryKey({ columns: [t.roleId, t.permission] })]);

export const memberships = pgTable('memberships', {
  id: id(),
  userId: uuid().notNull().references(() => users.id, { onDelete: 'cascade' }),
  businessId: uuid().notNull().references(() => businesses.id, { onDelete: 'cascade' }),
  roleId: uuid().notNull().references(() => roles.id),
  status: membershipStatus().notNull().default('ACTIVE'),
  createdAt: createdAt(),
}, (t) => [uniqueIndex().on(t.userId, t.businessId)]);

export const plans = pgTable('plans', {
  code: planCode().primaryKey(),
  name: varchar({ length: 60 }).notNull(),
  priceMonthly: money().notNull(),
  currency: varchar({ length: 3 }).notNull().default('COP'),
  limits: jsonb().$type<PlanLimits>().notNull(),
});

export type PlanLimits = {
  users: number | null; products: number | null; salesPerMonth: number | null;
  bankAccounts: number | null; socialAccounts: number | null;
  assistant: boolean; reportFormats: string[];
};

export const subscriptions = pgTable('subscriptions', {
  id: id(),
  businessId: uuid().notNull().unique().references(() => businesses.id, { onDelete: 'cascade' }),
  planCode: planCode().notNull().default('FREE').references(() => plans.code),
  status: subscriptionStatus().notNull().default('ACTIVE'),
  currentPeriodEnd: ts(),
  provider: varchar({ length: 40 }),
  providerRef: varchar({ length: 120 }),
  createdAt: createdAt(),
});

export const payments = pgTable('payments', {
  id: id(),
  subscriptionId: uuid().notNull().references(() => subscriptions.id, { onDelete: 'cascade' }),
  amount: money().notNull(),
  currency: varchar({ length: 3 }).notNull().default('COP'),
  status: varchar({ length: 30 }).notNull(),
  provider: varchar({ length: 40 }).notNull(),
  targetPlanCode: planCode(),
  providerRef: varchar({ length: 120 }),
  transactionId: varchar({ length: 120 }),
  paymentMethod: varchar({ length: 40 }),
  paidAt: ts(),
  createdAt: createdAt(),
});

// ───────────── Catálogo e inventario ─────────────
export const categories = pgTable('categories', {
  id: id(),
  businessId: uuid().notNull().references(() => businesses.id, { onDelete: 'cascade' }),
  name: varchar({ length: 80 }).notNull(),
}, (t) => [uniqueIndex().on(t.businessId, t.name)]);

export const suppliers = pgTable('suppliers', {
  id: id(),
  businessId: uuid().notNull().references(() => businesses.id, { onDelete: 'cascade' }),
  name: varchar({ length: 160 }).notNull(),
  company: varchar({ length: 160 }),
  taxId: varchar({ length: 40 }),
  phone: varchar({ length: 40 }),
  email: varchar({ length: 255 }),
  notes: text(),
  createdAt: createdAt(),
}, (t) => [index().on(t.businessId)]);

export const products = pgTable('products', {
  id: id(),
  businessId: uuid().notNull().references(() => businesses.id, { onDelete: 'cascade' }),
  sku: varchar({ length: 60 }).notNull(),
  barcode: varchar({ length: 60 }),
  name: varchar({ length: 200 }).notNull(),
  description: text(),
  categoryId: uuid().references(() => categories.id, { onDelete: 'set null' }),
  supplierId: uuid().references(() => suppliers.id, { onDelete: 'set null' }),
  costPrice: money().notNull(),
  salePrice: money().notNull(),
  taxRate: numeric({ precision: 5, scale: 2 }).notNull().default('0'),
  minStock: integer().notNull().default(0),
  storeOptions: jsonb().$type<{ name: string; type: 'select' | 'multi' | 'text' | 'date' | 'time'; required: boolean; choices?: { label: string; priceDelta?: string }[] }[]>().notNull().default([]),
  preparationMinutes: integer(),
  depositPercent: integer().notNull().default(0),
  appointmentSchedule: jsonb().$type<{ weekdays: number[]; startTime: string; endTime: string; intervalMinutes: number; durationMinutes: number } | null>(),
  imageUrl: text(),
  isActive: boolean().notNull().default(true),
  createdAt: createdAt(),
  updatedAt: ts().notNull().defaultNow().$onUpdate(() => new Date()),
}, (t) => [uniqueIndex().on(t.businessId, t.sku), index().on(t.businessId, t.name)]);

export const productVariants = pgTable('product_variants', {
  id: id(),
  businessId: uuid().notNull().references(() => businesses.id, { onDelete: 'cascade' }),
  productId: uuid().notNull().references(() => products.id, { onDelete: 'cascade' }),
  sku: varchar({ length: 80 }).notNull(),
  options: jsonb().$type<Record<string, string>>().notNull(),
  stock: integer().notNull().default(0),
  minStock: integer().notNull().default(0),
  isActive: boolean().notNull().default(true),
  createdAt: createdAt(),
  updatedAt: ts().notNull().defaultNow().$onUpdate(() => new Date()),
}, (t) => [uniqueIndex().on(t.businessId, t.sku), index().on(t.productId)]);

export const storeOrders = pgTable('store_orders', {
  id: id(),
  businessId: uuid().notNull().references(() => businesses.id, { onDelete: 'cascade' }),
  customerId: uuid().references(() => customers.id, { onDelete: 'set null' }),
  customerPurchaseCountedAt: ts(),
  status: storeOrderStatus().notNull().default('RECEIVED'),
  customerName: varchar({ length: 160 }).notNull(),
  customerPhone: varchar({ length: 40 }).notNull(),
  address: varchar({ length: 255 }).notNull(),
  city: varchar({ length: 120 }).notNull(),
  paymentMethod: varchar({ length: 80 }).notNull(),
  shippingFee: money().notNull().default('0'),
  attributionSource: varchar({ length: 80 }),
  attributionMedium: varchar({ length: 80 }),
  attributionCampaign: varchar({ length: 160 }),
  attributionContent: varchar({ length: 160 }),
  deliveryMethod: varchar({ length: 20 }).notNull().default('DELIVERY'),
  couponCode: varchar({ length: 40 }),
  discount: money().notNull().default('0'),
  notes: varchar({ length: 500 }),
  marketingOptIn: boolean().notNull().default(false),
  saleId: uuid().references(() => sales.id, { onDelete: 'set null' }),
  paymentStatus: varchar({ length: 20 }).notNull().default('PENDING'),
  paymentProvider: varchar({ length: 30 }),
  paymentTransactionId: varchar({ length: 120 }),
  shippingCarrier: varchar({ length: 40 }),
  pickupDate: varchar({ length: 10 }),
  pickupWindow: varchar({ length: 40 }),
  pickupConfirmation: varchar({ length: 100 }),
  trackingNumber: varchar({ length: 80 }),
  trackingUrl: text(),
  paidAt: ts(),
  dataUseAcceptedAt: ts().notNull(),
  total: money().notNull(),
  paymentDue: money().notNull(),
  createdAt: createdAt(),
  updatedAt: ts().notNull().defaultNow().$onUpdate(() => new Date()),
  confirmedAt: ts(),
  shippedAt: ts(),
  deliveredAt: ts(),
  cancelledAt: ts(),
}, (t) => [index().on(t.businessId, t.createdAt), index().on(t.businessId, t.status)]);

export const storeOrderItems = pgTable('store_order_items', {
  id: id(),
  orderId: uuid().notNull().references(() => storeOrders.id, { onDelete: 'cascade' }),
  productId: uuid().notNull().references(() => products.id),
  variantId: uuid().references(() => productVariants.id, { onDelete: 'set null' }),
  productName: varchar({ length: 200 }).notNull(),
  quantity: integer().notNull(),
  unitPrice: money().notNull(),
  selectedOptions: jsonb().$type<Record<string, string | string[]>>().notNull().default({}),
  preparationMinutes: integer(),
  depositPercent: integer().notNull().default(0),
  appointmentSchedule: jsonb().$type<{ weekdays: number[]; startTime: string; endTime: string; intervalMinutes: number; durationMinutes: number } | null>(),
  createdAt: createdAt(),
}, (t) => [index().on(t.orderId)]);

export const storeCoupons = pgTable('store_coupons', {
  id: id(),
  businessId: uuid().notNull().references(() => businesses.id, { onDelete: 'cascade' }),
  code: varchar({ length: 40 }).notNull(),
  description: varchar({ length: 160 }),
  kind: varchar({ length: 10 }).notNull().default('PERCENT'), // PERCENT | FIXED | SHIPPING
  value: money().notNull(),
  minSubtotal: money().notNull().default('0'),
  maxUses: integer(),
  usedCount: integer().notNull().default(0),
  campaign: varchar({ length: 160 }),
  startsAt: ts(),
  expiresAt: ts(),
  isActive: boolean().notNull().default(true),
  createdAt: createdAt(),
}, (t) => [uniqueIndex().on(t.businessId, t.code)]);

/** Carritos que el comprador dejó sin terminar, guardados SOLO si autorizó que lo contacten. */
export const storeCarts = pgTable('store_carts', {
  id: uuid().primaryKey(),
  businessId: uuid().notNull().references(() => businesses.id, { onDelete: 'cascade' }),
  customerName: varchar({ length: 160 }).notNull(),
  customerPhone: varchar({ length: 40 }).notNull(),
  items: jsonb().$type<{ productId: string; name: string; quantity: number; unitPrice: string }[]>().notNull(),
  subtotal: money().notNull(),
  consentAt: ts().notNull(),
  remindedAt: ts(),
  dismissedAt: ts(),
  convertedOrderId: uuid().references(() => storeOrders.id, { onDelete: 'set null' }),
  createdAt: createdAt(),
  updatedAt: ts().notNull().defaultNow().$onUpdate(() => new Date()),
}, (t) => [index().on(t.businessId, t.updatedAt)]);

export type ReturnItem = { productId: string; variantId?: string | null; name: string; quantity: number; unitPrice: string; restock?: boolean };
/** Devoluciones y cambios. source: STORE_ORDER (pedido de la página web) o SALE (venta registrada en el panel). */
export const returns = pgTable('returns', {
  id: id(),
  businessId: uuid().notNull().references(() => businesses.id, { onDelete: 'cascade' }),
  number: integer().notNull(),
  source: varchar({ length: 20 }).notNull(),
  storeOrderId: uuid().references(() => storeOrders.id, { onDelete: 'set null' }),
  saleId: uuid().references(() => sales.id, { onDelete: 'set null' }),
  customerId: uuid().references(() => customers.id, { onDelete: 'set null' }),
  customerName: varchar({ length: 160 }).notNull(),
  customerPhone: varchar({ length: 40 }),
  reason: varchar({ length: 30 }).notNull(),
  details: varchar({ length: 1000 }),
  resolution: varchar({ length: 20 }).notNull().default('REFUND'), // REFUND | EXCHANGE
  status: varchar({ length: 20 }).notNull().default('REQUESTED'), // REQUESTED | APPROVED | REJECTED | RECEIVED | REFUNDED | EXCHANGED
  items: jsonb().$type<ReturnItem[]>().notNull(),
  refundAmount: money().notNull().default('0'),
  refundMethod: varchar({ length: 20 }),
  refundReference: varchar({ length: 120 }),
  restockedCost: money().notNull().default('0'),
  responseNote: varchar({ length: 1000 }),
  createdById: uuid(),
  requestedAt: ts().notNull().defaultNow(),
  approvedAt: ts(),
  receivedAt: ts(),
  resolvedAt: ts(),
  updatedAt: ts().notNull().defaultNow().$onUpdate(() => new Date()),
}, (t) => [uniqueIndex().on(t.businessId, t.number), index().on(t.businessId, t.status), index().on(t.businessId, t.resolvedAt)]);

/** Lo que el asistente sabe del negocio: guías de uso de servicios, cuidados, garantías, respuestas frecuentes. */
export const knowledgeEntries = pgTable('knowledge_entries', {
  id: id(),
  businessId: uuid().notNull().references(() => businesses.id, { onDelete: 'cascade' }),
  title: varchar({ length: 160 }).notNull(),
  content: text().notNull(),
  category: varchar({ length: 40 }).notNull().default('GENERAL'),
  productId: uuid().references(() => products.id, { onDelete: 'set null' }),
  createdAt: createdAt(),
  updatedAt: ts().notNull().defaultNow().$onUpdate(() => new Date()),
}, (t) => [index().on(t.businessId)]);

export const marketingCampaigns = pgTable('marketing_campaigns', {
  id: id(),
  businessId: uuid().notNull().references(() => businesses.id, { onDelete: 'cascade' }),
  name: varchar({ length: 160 }).notNull(),
  source: varchar({ length: 80 }).notNull(),
  campaignKey: varchar({ length: 160 }).notNull(),
  spend: money().notNull().default('0'),
  couponCode: varchar({ length: 40 }),
  startsOn: varchar({ length: 10 }),
  endsOn: varchar({ length: 10 }),
  createdAt: createdAt(),
}, (t) => [uniqueIndex().on(t.businessId, t.campaignKey)]);

export const warehouses = pgTable('warehouses', {
  id: id(),
  businessId: uuid().notNull().references(() => businesses.id, { onDelete: 'cascade' }),
  name: varchar({ length: 80 }).notNull(),
  isDefault: boolean().notNull().default(false),
});

export const inventoryLevels = pgTable('inventory_levels', {
  productId: uuid().notNull().references(() => products.id, { onDelete: 'cascade' }),
  warehouseId: uuid().notNull().references(() => warehouses.id, { onDelete: 'cascade' }),
  quantity: integer().notNull().default(0),
}, (t) => [primaryKey({ columns: [t.productId, t.warehouseId] })]);

export const inventoryMovements = pgTable('inventory_movements', {
  id: id(),
  businessId: uuid().notNull().references(() => businesses.id, { onDelete: 'cascade' }),
  productId: uuid().notNull().references(() => products.id, { onDelete: 'cascade' }),
  warehouseId: uuid().notNull().references(() => warehouses.id, { onDelete: 'cascade' }),
  type: movementType().notNull(),
  quantity: integer().notNull(), // con signo
  unitCost: money(),
  referenceType: varchar({ length: 30 }),
  referenceId: uuid(),
  note: text(),
  userId: uuid(),
  createdAt: createdAt(),
}, (t) => [index().on(t.businessId, t.createdAt), index().on(t.productId)]);

// ───────────── Clientes y ventas ─────────────
export const customers = pgTable('customers', {
  id: id(),
  businessId: uuid().notNull().references(() => businesses.id, { onDelete: 'cascade' }),
  name: varchar({ length: 160 }).notNull(),
  phone: varchar({ length: 40 }),
  email: varchar({ length: 255 }),
  city: varchar({ length: 120 }),
  taxId: varchar({ length: 40 }),
  channel: salesChannel(),
  notes: text(),
  /** Redes sociales del cliente (para identificarlo en Instagram, TikTok, WhatsApp…). */
  socialLinks: jsonb().$type<Record<string, string>>().notNull().default({}),
  totalSpent: money().notNull().default('0'),
  purchaseCount: integer().notNull().default(0),
  firstPurchaseAt: ts(),
  lastPurchaseAt: ts(),
  /** Autorización expresa para recibir promociones (Ley 1581): se puede retirar en cualquier momento. */
  marketingOptIn: boolean().notNull().default(false),
  marketingOptInAt: ts(),
  marketingOptOutAt: ts(),
  createdAt: createdAt(),
}, (t) => [index().on(t.businessId, t.name)]);

export const sales = pgTable('sales', {
  id: id(),
  businessId: uuid().notNull().references(() => businesses.id, { onDelete: 'cascade' }),
  number: integer().notNull(),
  customerId: uuid().references(() => customers.id, { onDelete: 'set null' }),
  date: ts().notNull().defaultNow(),
  channel: salesChannel().notNull(),
  paymentMethod: paymentMethod().notNull(),
  status: saleStatus().notNull(),
  subtotal: money().notNull(),
  discountTotal: money().notNull(),
  taxTotal: money().notNull(),
  total: money().notNull(),
  amountPaid: money().notNull(),
  costTotal: money().notNull(),
  notes: text(),
  createdById: uuid(),
  cancelledAt: ts(),
  // Reservado para facturación electrónica (DIAN) futura
  einvoiceStatus: varchar({ length: 30 }),
  einvoiceRef: varchar({ length: 120 }),
  createdAt: createdAt(),
}, (t) => [uniqueIndex().on(t.businessId, t.number), index().on(t.businessId, t.date)]);

export const saleItems = pgTable('sale_items', {
  id: id(),
  saleId: uuid().notNull().references(() => sales.id, { onDelete: 'cascade' }),
  productId: uuid().notNull().references(() => products.id),
  description: varchar({ length: 200 }).notNull(),
  quantity: integer().notNull(),
  unitPrice: money().notNull(),
  unitCost: money().notNull(),
  discount: money().notNull().default('0'),
  taxRate: numeric({ precision: 5, scale: 2 }).notNull().default('0'),
  lineTax: money().notNull(),
  lineTotal: money().notNull(),
}, (t) => [index().on(t.saleId), index().on(t.productId)]);

export const salePayments = pgTable('sale_payments', {
  id: id(),
  saleId: uuid().notNull().references(() => sales.id, { onDelete: 'cascade' }),
  amount: money().notNull(),
  method: paymentMethod().notNull(),
  reference: varchar({ length: 120 }),
  paidAt: ts().notNull().defaultNow(),
}, (t) => [index().on(t.saleId)]);

// ───────────── Compras, gastos, ingresos ─────────────
export const purchases = pgTable('purchases', {
  id: id(),
  businessId: uuid().notNull().references(() => businesses.id, { onDelete: 'cascade' }),
  supplierId: uuid().notNull().references(() => suppliers.id),
  date: ts().notNull().defaultNow(),
  total: money().notNull(),
  amountPaid: money().notNull(),
  status: purchaseStatus().notNull(),
  notes: text(),
  createdAt: createdAt(),
}, (t) => [index().on(t.businessId, t.date)]);

export const purchaseItems = pgTable('purchase_items', {
  id: id(),
  purchaseId: uuid().notNull().references(() => purchases.id, { onDelete: 'cascade' }),
  productId: uuid().notNull().references(() => products.id),
  quantity: integer().notNull(),
  unitCost: money().notNull(),
  lineTotal: money().notNull(),
});

export const purchasePayments = pgTable('purchase_payments', {
  id: id(),
  purchaseId: uuid().notNull().references(() => purchases.id, { onDelete: 'cascade' }),
  amount: money().notNull(),
  method: paymentMethod().notNull(),
  paidAt: ts().notNull().defaultNow(),
});

export const expenses = pgTable('expenses', {
  id: id(),
  businessId: uuid().notNull().references(() => businesses.id, { onDelete: 'cascade' }),
  category: expenseCategory().notNull(),
  description: varchar({ length: 255 }).notNull(),
  amount: money().notNull(),
  date: ts().notNull(),
  paymentMethod: paymentMethod(),
  status: payableStatus().notNull().default('PAID'),
  dueDate: ts(),
  supplierId: uuid().references(() => suppliers.id, { onDelete: 'set null' }),
  createdAt: createdAt(),
}, (t) => [index().on(t.businessId, t.date)]);

export const incomes = pgTable('incomes', {
  id: id(),
  businessId: uuid().notNull().references(() => businesses.id, { onDelete: 'cascade' }),
  category: varchar({ length: 60 }).notNull(),
  description: varchar({ length: 255 }).notNull(),
  amount: money().notNull(),
  date: ts().notNull(),
  paymentMethod: paymentMethod(),
  createdAt: createdAt(),
}, (t) => [index().on(t.businessId, t.date)]);

// ───────────── Bancos ─────────────
export const bankAccounts = pgTable('bank_accounts', {
  id: id(),
  businessId: uuid().notNull().references(() => businesses.id, { onDelete: 'cascade' }),
  bankName: varchar({ length: 80 }).notNull(),
  accountType: varchar({ length: 20 }).notNull(), // AHORROS | CORRIENTE | BILLETERA
  accountNumberEnc: text(),
  last4: varchar({ length: 4 }),
  currency: varchar({ length: 3 }).notNull().default('COP'),
  provider: bankProvider().notNull().default('MANUAL'),
  providerAccountId: varchar({ length: 120 }),
  accessTokenEnc: text(),
  balance: money().notNull().default('0'),
  lastSyncedAt: ts(),
  createdAt: createdAt(),
});

export const bankTransactions = pgTable('bank_transactions', {
  id: id(),
  businessId: uuid().notNull().references(() => businesses.id, { onDelete: 'cascade' }),
  bankAccountId: uuid().notNull().references(() => bankAccounts.id, { onDelete: 'cascade' }),
  date: ts().notNull(),
  amount: money().notNull(), // siempre positivo
  type: bankTxType().notNull(),
  description: varchar({ length: 255 }).notNull(),
  reference: varchar({ length: 120 }),
  externalId: varchar({ length: 120 }),
  category: varchar({ length: 60 }),
  status: bankTxStatus().notNull().default('UNMATCHED'),
  isSimulated: boolean().notNull().default(false),
  createdAt: createdAt(),
}, (t) => [uniqueIndex().on(t.bankAccountId, t.externalId), index().on(t.businessId, t.date)]);

export const reconciliations = pgTable('reconciliations', {
  id: id(),
  businessId: uuid().notNull().references(() => businesses.id, { onDelete: 'cascade' }),
  bankTransactionId: uuid().notNull().references(() => bankTransactions.id, { onDelete: 'cascade' }),
  saleId: uuid().references(() => sales.id, { onDelete: 'cascade' }),
  expenseId: uuid().references(() => expenses.id, { onDelete: 'cascade' }),
  status: reconciliationStatus().notNull().default('SUGGESTED'),
  score: integer().notNull(),
  decidedAt: ts(),
  decidedById: uuid(),
  createdAt: createdAt(),
}, (t) => [
  uniqueIndex().on(t.bankTransactionId, t.saleId),
  uniqueIndex().on(t.bankTransactionId, t.expenseId),
  index().on(t.businessId, t.status),
]);

// ───────────── Redes sociales ─────────────
export const socialAccounts = pgTable('social_accounts', {
  id: id(),
  businessId: uuid().notNull().references(() => businesses.id, { onDelete: 'cascade' }),
  platform: socialPlatform().notNull(),
  externalId: varchar({ length: 120 }).notNull(),
  name: varchar({ length: 160 }).notNull(),
  accessTokenEnc: text(),
  scopes: text().array().notNull().default([]),
  status: socialAccountStatus().notNull().default('CONNECTED'),
  tokenExpiresAt: ts(),
  connectedAt: createdAt(),
}, (t) => [uniqueIndex().on(t.businessId, t.platform, t.externalId)]);

export const socialPosts = pgTable('social_posts', {
  id: id(),
  socialAccountId: uuid().notNull().references(() => socialAccounts.id, { onDelete: 'cascade' }),
  externalId: varchar({ length: 120 }),
  content: text(),
  mediaUrl: text(),
  scheduledAt: ts(),
  publishedAt: ts(),
  metrics: jsonb().notNull().default({}),
});

export const socialMessages = pgTable('social_messages', {
  id: id(),
  socialAccountId: uuid().notNull().references(() => socialAccounts.id, { onDelete: 'cascade' }),
  externalId: varchar({ length: 120 }).notNull(),
  threadId: varchar({ length: 120 }),
  fromName: varchar({ length: 160 }),
  body: text().notNull(),
  direction: varchar({ length: 3 }).notNull(), // IN | OUT
  receivedAt: ts().notNull(),
  customerId: uuid(),
}, (t) => [uniqueIndex().on(t.socialAccountId, t.externalId)]);

// ───────────── Notificaciones, reportes, auditoría ─────────────
export const notifications = pgTable('notifications', {
  id: id(),
  businessId: uuid().notNull().references(() => businesses.id, { onDelete: 'cascade' }),
  userId: uuid(), // null = para todos los miembros con permiso
  type: varchar({ length: 40 }).notNull(),
  title: varchar({ length: 160 }).notNull(),
  body: text().notNull(),
  data: jsonb().notNull().default({}),
  readAt: ts(),
  createdAt: createdAt(),
}, (t) => [index().on(t.businessId, t.createdAt)]);

export const notificationPreferences = pgTable('notification_preferences', {
  userId: uuid().notNull().references(() => users.id, { onDelete: 'cascade' }),
  businessId: uuid().notNull().references(() => businesses.id, { onDelete: 'cascade' }),
  type: varchar({ length: 40 }).notNull(),
  enabled: boolean().notNull().default(true),
}, (t) => [primaryKey({ columns: [t.userId, t.businessId, t.type] })]);

export const reports = pgTable('reports', {
  id: id(),
  businessId: uuid().notNull().references(() => businesses.id, { onDelete: 'cascade' }),
  type: varchar({ length: 40 }).notNull(),
  format: varchar({ length: 10 }).notNull(),
  params: jsonb().notNull().default({}),
  createdById: uuid(),
  createdAt: createdAt(),
});

export const auditLogs = pgTable('audit_logs', {
  id: id(),
  businessId: uuid().references(() => businesses.id, { onDelete: 'cascade' }),
  userId: uuid(),
  action: varchar({ length: 20 }).notNull(),
  entity: varchar({ length: 80 }).notNull(),
  entityId: varchar({ length: 80 }),
  ip: varchar({ length: 64 }),
  userAgent: text(),
  metadata: jsonb().notNull().default({}),
  createdAt: createdAt(),
}, (t) => [index().on(t.businessId, t.createdAt)]);

// ───────────── Relaciones (para consultas anidadas) ─────────────
export const usersRelations = relations(users, ({ many }) => ({ memberships: many(memberships), sessions: many(sessions) }));
export const businessesRelations = relations(businesses, ({ many, one }) => ({
  memberships: many(memberships),
  subscription: one(subscriptions, { fields: [businesses.id], references: [subscriptions.businessId] }),
}));
export const rolesRelations = relations(roles, ({ many }) => ({ permissions: many(rolePermissions) }));
export const rolePermissionsRelations = relations(rolePermissions, ({ one }) => ({ role: one(roles, { fields: [rolePermissions.roleId], references: [roles.id] }) }));
export const membershipsRelations = relations(memberships, ({ one }) => ({
  user: one(users, { fields: [memberships.userId], references: [users.id] }),
  business: one(businesses, { fields: [memberships.businessId], references: [businesses.id] }),
  role: one(roles, { fields: [memberships.roleId], references: [roles.id] }),
}));
export const subscriptionsRelations = relations(subscriptions, ({ one }) => ({
  plan: one(plans, { fields: [subscriptions.planCode], references: [plans.code] }),
}));
export const productsRelations = relations(products, ({ one, many }) => ({
  category: one(categories, { fields: [products.categoryId], references: [categories.id] }),
  supplier: one(suppliers, { fields: [products.supplierId], references: [suppliers.id] }),
  levels: many(inventoryLevels),
}));
export const inventoryLevelsRelations = relations(inventoryLevels, ({ one }) => ({
  product: one(products, { fields: [inventoryLevels.productId], references: [products.id] }),
}));
export const salesRelations = relations(sales, ({ one, many }) => ({
  customer: one(customers, { fields: [sales.customerId], references: [customers.id] }),
  items: many(saleItems),
  payments: many(salePayments),
}));
export const saleItemsRelations = relations(saleItems, ({ one }) => ({
  sale: one(sales, { fields: [saleItems.saleId], references: [sales.id] }),
  product: one(products, { fields: [saleItems.productId], references: [products.id] }),
}));
export const salePaymentsRelations = relations(salePayments, ({ one }) => ({ sale: one(sales, { fields: [salePayments.saleId], references: [sales.id] }) }));
export const customersRelations = relations(customers, ({ many }) => ({ sales: many(sales) }));
export const purchasesRelations = relations(purchases, ({ one, many }) => ({
  supplier: one(suppliers, { fields: [purchases.supplierId], references: [suppliers.id] }),
  items: many(purchaseItems),
  payments: many(purchasePayments),
}));
export const purchaseItemsRelations = relations(purchaseItems, ({ one }) => ({
  purchase: one(purchases, { fields: [purchaseItems.purchaseId], references: [purchases.id] }),
  product: one(products, { fields: [purchaseItems.productId], references: [products.id] }),
}));
export const purchasePaymentsRelations = relations(purchasePayments, ({ one }) => ({ purchase: one(purchases, { fields: [purchasePayments.purchaseId], references: [purchases.id] }) }));
export const suppliersRelations = relations(suppliers, ({ many }) => ({ purchases: many(purchases), products: many(products) }));
export const bankAccountsRelations = relations(bankAccounts, ({ many }) => ({ transactions: many(bankTransactions) }));
export const bankTransactionsRelations = relations(bankTransactions, ({ one, many }) => ({
  bankAccount: one(bankAccounts, { fields: [bankTransactions.bankAccountId], references: [bankAccounts.id] }),
  reconciliations: many(reconciliations),
}));
export const reconciliationsRelations = relations(reconciliations, ({ one }) => ({
  bankTransaction: one(bankTransactions, { fields: [reconciliations.bankTransactionId], references: [bankTransactions.id] }),
  sale: one(sales, { fields: [reconciliations.saleId], references: [sales.id] }),
  expense: one(expenses, { fields: [reconciliations.expenseId], references: [expenses.id] }),
}));
