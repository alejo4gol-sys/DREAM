import type { Metadata, Viewport } from 'next';

export const metadata: Metadata = {
  title: { absolute: 'Tu Derecho — orientación jurídica gratuita' },
  description: 'Cuéntanos tu problema legal y te orientamos gratis, en lenguaje sencillo. Si quieres, abogados verificados te envían propuestas.',
  manifest: '/tu-derecho.webmanifest',
  icons: { icon: '/tu-derecho-icon.svg', apple: '/tu-derecho-icon.svg' },
  openGraph: { title: 'Tu Derecho', description: 'Orientación jurídica gratuita y sin registrarte.' },
};
export const viewport: Viewport = { themeColor: '#0F3D5E', width: 'device-width', initialScale: 1 };

export default function TuDerechoLayout({ children }: { children: React.ReactNode }) {
  return <div className="min-h-screen bg-[#F7F5F0] text-[#13202B]">{children}</div>;
}
